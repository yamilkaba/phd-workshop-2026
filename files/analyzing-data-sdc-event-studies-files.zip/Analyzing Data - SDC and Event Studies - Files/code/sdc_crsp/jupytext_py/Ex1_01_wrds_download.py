# %%
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
import time
from datetime import datetime

# %%
#root folder: each table is saved in p_path/<schema>/<table>.parquet (table name exactly as in wrds), mirroring the schema structure on wrds. change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
#wrds username, change accordingly
v_username="user"
v_chunksize=500000 #rows held in memory at a time. smaller = less memory
v_compression='zstd' #files are 20-30% smaller than snappy (the pandas default) at similar speed. change to 'snappy' if you need compatibility with old tools

# %%
#tables to download: change accordingly (Ex2_99_wrds_libraries lists the schema.table you have access to)
#columns: '*' = all columns, only the ones needed are listed so the download is faster and the files are smaller. where: '' = whole table. the file keeps the wrds table name even when columns or rows were filtered
#the daily stock file keeps dlyprc (the daily closing price, used to compare the first-day close with the sdc close at first trade). stkshares is shares outstanding with its start and end dates (shrstartdt, shrenddt, shrout), downloaded whole on its own
#the daily index file has many series: only the two needed are kept (indno 1000080 = crsp nyse/amex/nasdaq value-weighted, 1000081 = equal-weighted, 1000503 = nasdaq composite, price return only, added 2026-11-10 for the quiet period replication). factors_daily is the 3-factor file with momentum (smb is built differently from the one in fivefactors_daily). stksecurityinfohist is downloaded whole (all columns, with its start and end dates): firms are matched from sdc to permno by cusip with it. the stock filters (share type, exchange, ...) are not applied here, they are done in the process step. ccmxpf_lnkhist is the crsp/compustat link table (linkprim P or C marks the primary security when a firm has more than one)
#time of each table in the run of 2026-11-09 (seconds, rows, mb of the parquet file; the run took about 15 minutes in all):
#stkdlysecuritydata 892 s, 110,245,749 rows, 697.5 mb | stksecurityinfohist 6 s, 191,048 rows, 7.3 mb | stkshares 23 s, 3,087,489 rows, 13.7 mb | inddlyseriesdata_ind 2 s, 52,602 rows, 2.8 mb | fivefactors_daily 1 s, 15,918 rows, 0.3 mb | factors_daily 1 s, 26,338 rows, 0.4 mb | ccmxpf_lnkhist 1 s, 123,388 rows, 1.3 mb
df_dl_list = pd.DataFrame({
    'schema': ['crsp_a_stock', 'crsp_a_stock', 'crsp_a_stock', 'crsp_a_indexes', 'ff_all', 'ff_all', 'crsp_a_ccm',],
    'table': ['stkdlysecuritydata', 'stksecurityinfohist', 'stkshares', 'inddlyseriesdata_ind', 'fivefactors_daily', 'factors_daily', 'ccmxpf_lnkhist',],
    'columns': ['permno, dlycaldt, dlyret, dlyprc',
                '*',
                '*',
                '*',
                '*',
                '*',
                '*',],
    'where': ['', '', '', 'indno IN (1000080, 1000081, 1000503)', '', '', '',],
})

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
#streams each table straight to parquet, one chunk at a time, so memory never holds the whole table
#chunks go through the same raw_sql conversions as a normal download (nullable dtypes, dates), so the file matches df.to_parquet(index=False)
#the file is written as .part and renamed only when complete, so an interrupted download never looks finished
#the daily stock file is the big one (it was most of the ~12 minutes of the Ex8 download), the other two are small
#the seconds of each table are printed below and added to wrds_download_times.parquet in every run
l_times = []
for v_schema, v_table, v_columns, v_where in df_dl_list[['schema', 'table', 'columns', 'where']].itertuples(index=False):
    v_t0 = time.time()
    p_out = p_path / v_schema / f"{v_table}.parquet"
    p_part = p_out.with_name(p_out.name + '.part')
    p_out.parent.mkdir(parents=True, exist_ok=True)

    #date columns come from the table definition
    df_cols = conn.raw_sql(f"SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = '{v_schema}' AND table_name = '{v_table}'")
    l_date_cols = df_cols.loc[df_cols['data_type'].str.contains('date|timestamp', case=False, na=False), 'column_name'].tolist()
    if v_columns != '*':
        l_selected = [c.strip().lower() for c in v_columns.split(',')]
        l_date_cols = [c for c in l_date_cols if c.lower() in l_selected]

    #server-side cursor: wrds sends the rows in chunks instead of all at once. postgres only allows it inside a transaction, so autocommit is switched off meanwhile
    conn.connection.rollback()
    conn.connection.execution_options(isolation_level="READ COMMITTED", stream_results=True)
    v_filter = f" WHERE {v_where}" if v_where else ""
    it_chunks = conn.raw_sql(f"SELECT {v_columns} FROM {v_schema}.{v_table}{v_filter}", date_cols=l_date_cols, chunksize=v_chunksize, return_iter=True)

    writer = None
    v_rows = 0
    for df_chunk in it_chunks:
        t_chunk = pa.Table.from_pandas(df_chunk, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(p_part, t_chunk.schema, compression=v_compression)
        writer.write_table(t_chunk)
        v_rows += len(df_chunk)
    conn.connection.rollback()
    conn.connection.execution_options(isolation_level="AUTOCOMMIT", stream_results=False)

    if writer is None:
        print(f"{v_schema}.{v_table}: no rows, nothing saved")
        continue
    writer.close()
    p_part.replace(p_out)
    v_secs = time.time() - v_t0
    l_times.append({'run_time': datetime.now().isoformat(timespec='seconds'), 'schema': v_schema, 'table': v_table, 'rows': v_rows, 'seconds': round(v_secs, 1), 'mb': round(p_out.stat().st_size / 1e6, 1)})
    print(f"{v_schema}.{v_table}: {v_rows} rows -> {p_out} | {v_secs:.0f} seconds")

# %%
#seconds and size of each table in this run. one row per table. each run is added to the file, so the times of the runs can be compared
df_times1 = pd.DataFrame(l_times)
p_times = p_path / 'wrds_download_times.parquet'
if p_times.exists():
    df_times1 = pd.concat([pd.read_parquet(p_times), df_times1], ignore_index=True)
df_times1.to_parquet(p_times, index=False)
print(df_times1.tail(len(l_times)).to_string(index=False))

# %%
conn.close()
