# %%
import pandas as pd
import re
import time
from pathlib import Path

# %%
#folders and files: change accordingly. the sdc excel file is the download of 2026-11-04 (header on row 3). the csv has the syntax code of every sdc item. nothing here depends on another program
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
p_xlsx=Path(r'D:\Users\user\Downloads\sdc_ipo_download_20261104.xlsx')
p_syntax=Path(r'D:\Box\workshop\PhDWorkshop\2026\T03_EventStudy_SDC\guides\SDC data items needed by the program (mandatory and optional).csv')
v_outputfile='20261104' #day of the sdc download. the output is sdc_ipo_raw_<v_outputfile>.parquet in p_path/sdc

# %%
#import the excel file. row 1 is the source line and the column names are on row 3. reading took 37 seconds on 2026-11-09 (59,381 deals, 59 columns; 35 seconds in an earlier test)
v_t0 = time.time()
df_sdc1 = pd.read_excel(p_xlsx, header=2)
print(f"{df_sdc1.shape} read in {time.time() - v_t0:.0f} seconds")

# %%
#every column gets its syntax code with the . replaced by an underscore (TR.NIIssueDate -> TR_NIIssueDate). the excel names have the options in other words than the csv names (Offer Price (USD) and Offer Price (Curn=USD, PrintFormat=True)), so both are matched with everything in parentheses taken out
df_syntax1 = pd.read_csv(p_syntax)
f_norm = lambda v: re.sub(r'\s+', ' ', re.sub(r'\([^)]*\)', '', v)).strip().lower()
d_syntax = {f_norm(v_n): v_s.replace('.', '_') for v_n, v_s in zip(df_syntax1['sdc_name'], df_syntax1['sdc_syntax'])}
d_rename = {v_c: d_syntax[f_norm(v_c)] for v_c in df_sdc1.columns if f_norm(v_c) in d_syntax}
l_no_code = [v_c for v_c in df_sdc1.columns if v_c not in d_rename]
print(f"columns renamed {len(d_rename)} of {df_sdc1.shape[1]} | no syntax code in the csv: {l_no_code}")
df_sdc2 = df_sdc1.rename(columns=d_rename)
df_sdc2 = df_sdc2.rename(columns={'Issue Type': 'issue_type'}) #the issue type has no syntax code in the project files (it is IPO exactly on the deals with Original IPO Flag True)
print(f"deal numbers unique: {df_sdc2['TR_NISdcDealNumber'].is_unique}")

# %%
#a column with mixed types cannot be saved as parquet: those columns are saved as text, empty cells stay empty. no filter and no other change, all deals are saved
df_sdc3 = df_sdc2.copy()
for v_col in df_sdc3.columns[df_sdc3.dtypes == 'object']:
    df_sdc3[v_col] = df_sdc3[v_col].map(lambda v: v if pd.isna(v) else str(v))
(p_path / 'sdc').mkdir(parents=True, exist_ok=True)
df_sdc3.to_parquet(p_path / 'sdc' / f"sdc_ipo_raw_{v_outputfile}.parquet", index=False)
print(f"saved {df_sdc3.shape}")
