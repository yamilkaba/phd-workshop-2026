# %%
import duckdb
import pandas as pd
from pathlib import Path

# %%
#folders and files: change accordingly. the step 0 and step 1 tables are the output of Ex1_02_merge_sdc_crsp, the crsp tables are the output of Ex1_01_wrds_download. ipo_permno_exceptions.parquet is made by hand (deals whose permno was checked by hand and found wrong or missing in step 1)
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download. the outputs are sdc_ipo_step2_before_fixes_<v_outputfile>.parquet, sdc_ipo_step2_<v_outputfile>.parquet and sdc_ipo_step2_removed_<v_outputfile>.parquet in p_path/sdc
p_exceptions=p_path / 'sdc' / 'ipo_permno_exceptions.parquet'
p_stock=p_path / 'crsp_a_stock' / 'stkdlysecuritydata.parquet'
p_secinfo=p_path / 'crsp_a_stock' / 'stksecurityinfohist.parquet'
v_close_pct=0.01 #the sdc close at first trade equals the crsp close when they are within 1 cent or within this share of the crsp close
v_sibling_days=7 #a deal with no permno is dropped when a deal of the same issuer with a permno is within this many days
l_permno_cols=['crsp_first_trading_date', 'sdc_minus_crsp_days', 'name_score'] #columns of the table that belong to the permno: a hand fix gives the row a new permno, so they are emptied (the two dates are calculated again at the end)

# %%
#step 1 table: one row per deal and permno, a deal no way found is one row with an empty permno. every row moves between the tables below with all its columns, so a new column in step 1 needs no change in this program
df_step1_1 = pd.read_parquet(p_path / 'sdc' / f"sdc_ipo_step1_{v_outputfile}.parquet")
print(df_step1_1.shape, df_step1_1['deal_no'].nunique())

# %%
#columns of the step 0 deals that the rules use, and the crsp close of the first day with a price for each permno. these are only used to decide, they are not added to the table
df_att1 = pd.read_parquet(p_path / 'sdc' / f"sdc_ipo_step0_{v_outputfile}.parquet", columns=['TR_NISdcDealNumber', 'TR_NIIsMainTranche', 'TR_NIIssuerStkPriceAtCloseOfFirstTrade', 'TR_NITargetMarket', 'TR_NIProspectusStatus', 'TR_NIMasterFilingDatePrint', 'TR_NIProceedsAmtThisMkt', 'TR_NIIssuerCusip9', 'TR_NIIssuerSDCCusip', 'TR_NIIssuer', 'TR_NIIssueDate'])
df_att1 = df_att1.rename(columns={'TR_NISdcDealNumber': 'deal_no', 'TR_NIIsMainTranche': 'main', 'TR_NIIssuerStkPriceAtCloseOfFirstTrade': 'sdc_close', 'TR_NITargetMarket': 'target', 'TR_NIProspectusStatus': 'prosp', 'TR_NIMasterFilingDatePrint': 'filing', 'TR_NIProceedsAmtThisMkt': 'proceeds', 'TR_NIIssuerCusip9': 'cusip9', 'TR_NIIssuerSDCCusip': 'cusip6', 'TR_NIIssuer': 'name', 'TR_NIIssueDate': 'issue_date'})
t_target = df_att1['target'].fillna('')
df_att1['main'] = df_att1['main'].astype(str).str.lower() == 'true'
df_att1['us_alone'] = t_target.str.startswith('United States Of America') & ~t_target.str.contains(';') #the target market is the united states alone
df_att1['completed'] = df_att1['prosp'] == 'Completed'
df_att1['e002'] = df_att1['deal_no'].astype(str).str.endswith('002')
df_close1 = duckdb.query(f"SELECT permno, ARG_MIN(dlyprc, dlycaldt) AS crsp_close FROM read_parquet('{p_stock}') WHERE dlyprc IS NOT NULL GROUP BY permno").df()
print(df_att1.shape, df_close1.shape)

# %%
#the three tables of this step. keep = rows with a permno, unmatched = deals with no permno, removed = every row that leaves, with removed_by (the rule) and lost_to (the deal that prevailed, empty when none)
df_keep1 = df_step1_1[df_step1_1['permno'].notna()].copy()
df_unmatched1 = df_step1_1[df_step1_1['permno'].isna()].copy()
l_removed = []
print(len(df_keep1), len(df_unmatched1))

# %%
#cell (a). one permno for each deal. a deal with two or more permnos keeps the permno or permnos whose first crsp trading date is closest to the sdc issue date, in days either way. a tie keeps both. a permno with no first trading date is kept
s_abs = df_keep1['sdc_minus_crsp_days'].abs()
s_n = df_keep1.groupby('deal_no')['permno'].transform('nunique')
s_min = s_abs.groupby(df_keep1['deal_no']).transform('min')
f_a = (s_n == 1) | (s_abs == s_min) | s_abs.isna()
df_keep2 = df_keep1[f_a].copy()
l_removed.append(df_keep1[~f_a].assign(removed_by='closest date', lost_to=pd.NA))
print(f"deals with 2 or more permnos {df_keep1.loc[s_n > 1, 'deal_no'].nunique()} | rows removed {(~f_a).sum()} | deals still with 2 or more permnos (ties) {(df_keep2.groupby('deal_no')['permno'].nunique() > 1).sum()}")

# %%
#cell (b). one deal for each permno. only the permnos with more than one deal are changed. among the deals of a permno the main tranche deals compete (all deals when none is main). if more than two compete the same steps apply to all: a step that only some of the deals meet keeps those
#1 the sdc close at first trade equals the crsp close | 2 the target market is the united states alone | 3 prospectus status is Completed | 4 only the deals that end in 002 stay, none = drop all, if several the earlier filing date, then the larger proceeds, then the lower deal number
#a removed row is saved with the deal that prevailed on its permno (lost_to)
df_b1 = df_keep2[['deal_no', 'permno']].merge(df_att1, on='deal_no').merge(df_close1, on='permno', how='left')
v_diff = (df_b1['sdc_close'] - df_b1['crsp_close'].abs()).abs()
df_b1['close_ok'] = (v_diff <= 0.01) | (v_diff <= v_close_pct * df_b1['crsp_close'].abs())
l_win = []
d_winner = {}
d_stage = {}
for v_permno, df_g in df_b1.groupby('permno'):
    if len(df_g) == 1:
        l_win.append(df_g[['deal_no', 'permno']])
        continue
    df_c = df_g[df_g['main']] if df_g['main'].any() else df_g
    v_stage = 'one main' if len(df_c) == 1 else None
    for v_name, v_col in (('1 close', 'close_ok'), ('2 domestic', 'us_alone'), ('3 completed', 'completed')):
        if len(df_c) == 1:
            break
        df_k = df_c[df_c[v_col]]
        if 0 < len(df_k) < len(df_c):
            df_c = df_k
            v_stage = v_name
    if len(df_c) > 1:
        df_k = df_c[df_c['e002']]
        if len(df_k) == 0:
            v_stage = '4 drop all'
            df_c = df_c.iloc[0:0]
        else:
            df_c = df_k.sort_values(['filing', 'proceeds', 'deal_no'], ascending=[True, False, True]).iloc[:1]
            v_stage = '4 002 or tie'
    d_stage[v_stage] = d_stage.get(v_stage, 0) + 1
    l_win.append(df_c[['deal_no', 'permno']])
    d_winner[v_permno] = df_c['deal_no'].iloc[0] if len(df_c) > 0 else pd.NA
df_win1 = pd.concat(l_win)
f_b = df_keep2.merge(df_win1.assign(_won=1), on=['deal_no', 'permno'], how='left')['_won'].eq(1).values
df_keep3 = df_keep2[f_b].copy()
df_lost1 = df_keep2[~f_b].copy()
df_lost1['removed_by'] = 'one deal per permno'
df_lost1['lost_to'] = df_lost1['permno'].map(d_winner).astype('Int64')
l_removed.append(df_lost1)
s_deals_per_permno = df_keep3.groupby('permno')['deal_no'].nunique()
print(f"permnos before {df_keep2['permno'].nunique()} | after {df_keep3['permno'].nunique()} | decided by {d_stage}")
print(f"permnos with more than 1 deal {(s_deals_per_permno > 1).sum()} | deals with a permno {df_keep3['deal_no'].nunique()} | deals ruled out (lost every permno) {len(set(df_keep2['deal_no']) - set(df_keep3['deal_no']))}")

# %%
#cell (c). drop the deals with no permno whose offering has a deal with a permno. a deal with no permno is dropped when a kept deal with a permno of the same issuer has an issue date within 7 days. same issuer = the same first 6 characters of the sdc cusip (the 9 digit one, or the 6 digit one when there is none) or the same name written in lowercase letters and digits only
df_c1 = df_unmatched1[['deal_no']].merge(df_att1, on='deal_no')
df_c2 = df_att1[df_att1['deal_no'].isin(df_keep3['deal_no'])].copy()
for df_x in (df_c1, df_c2):
    df_x['key6'] = df_x['cusip9'].str[:6].fillna(df_x['cusip6'])
    df_x['name_key'] = df_x['name'].str.lower().str.replace(r'[^a-z0-9]', '', regex=True)
df_c3 = df_c1[['deal_no', 'key6', 'issue_date']].merge(df_c2[['deal_no', 'key6', 'issue_date']], on='key6', suffixes=('', '_k'))
df_c3 = df_c3[df_c3['key6'].notna() & ((df_c3['issue_date'] - df_c3['issue_date_k']).abs() <= pd.Timedelta(days=v_sibling_days))]
df_c4 = df_c1[['deal_no', 'name_key', 'issue_date']].merge(df_c2[['deal_no', 'name_key', 'issue_date']], on='name_key', suffixes=('', '_k'))
df_c4 = df_c4[(df_c4['issue_date'] - df_c4['issue_date_k']).abs() <= pd.Timedelta(days=v_sibling_days)]
d_sibling = pd.concat([df_c3[['deal_no', 'deal_no_k']], df_c4[['deal_no', 'deal_no_k']]]).drop_duplicates('deal_no').set_index('deal_no')['deal_no_k'].to_dict()
f_c = df_unmatched1['deal_no'].isin(d_sibling.keys())
l_removed.append(df_unmatched1[f_c].assign(removed_by='same issuer has a deal with a permno', lost_to=lambda x: x['deal_no'].map(d_sibling).astype('Int64')))
df_unmatched2 = df_unmatched1[~f_c].copy()
print(f"deals with no permno {len(df_unmatched1)} | dropped, same issuer with a permno within 7 days {f_c.sum()} | left {len(df_unmatched2)}")

# %%
#table before the hand fixes, and the removed rows so far
df_before1 = pd.concat([df_keep3, df_unmatched2], ignore_index=True)
df_removed1 = pd.concat(l_removed, ignore_index=True)
df_removed1['lost_to'] = df_removed1['lost_to'].astype('Int64')
print(f"table before the hand fixes: rows {len(df_before1)} | deals {df_before1['deal_no'].nunique()} | deals with a permno {df_keep3['deal_no'].nunique()} | removed rows {len(df_removed1)}")
print(df_removed1.groupby('removed_by').size().to_string())
df_before1.to_parquet(p_path / 'sdc' / f"sdc_ipo_step2_before_fixes_{v_outputfile}.parquet", index=False)

# %%
#hand fixes, last. for each deal in the file:
#1 its rows with another permno leave the table (they go to removed, removed_by hand fix) and its row with no permno, if it has one, is replaced
#2 the rows that lost a permno to it (lost_to is the fixed deal) come back from removed
#3 its row with the permno of the file is taken from the step 1 table (the columns of the permno are emptied) and its earlier rows leave removed. the deal is added again even if the rules ruled it out
df_exc1 = pd.read_parquet(p_exceptions)
d_fix = dict(zip(df_exc1['deal_no'], df_exc1['permno'].astype('int64')))
df_keep4 = df_keep3.copy()
df_unmatched3 = df_unmatched2[~df_unmatched2['deal_no'].isin(d_fix.keys())].copy()
df_removed2 = df_removed1.copy()
v_fix_permno = df_keep4['deal_no'].map(d_fix)
f_old = v_fix_permno.notna() & (v_fix_permno != df_keep4['permno'])
df_leaves = df_keep4[f_old].assign(removed_by='hand fix', lost_to=pd.NA)
df_keep4 = df_keep4[~f_old]
f_back = df_removed2['lost_to'].isin(list(d_fix.keys())) & (df_removed2['removed_by'] == 'one deal per permno') & ~df_removed2['deal_no'].isin(d_fix.keys())
df_back = df_removed2[f_back].drop(columns=['removed_by', 'lost_to'])
df_removed2 = df_removed2[~f_back]
df_removed2 = df_removed2[~(df_removed2['deal_no'].isin(d_fix.keys()) & (df_removed2['removed_by'] != 'hand fix'))]
f_have = df_keep4['deal_no'].isin(d_fix.keys())
df_new = df_step1_1.drop_duplicates('deal_no')
df_new = df_new[df_new['deal_no'].isin(d_fix.keys()) & ~df_new['deal_no'].isin(df_keep4.loc[f_have, 'deal_no'])].copy()
df_new['permno'] = df_new['deal_no'].map(d_fix).astype('Int64')
df_new['pass'] = '0 fix list'
df_new[l_permno_cols] = pd.NA
df_removed2 = pd.concat([df_removed2, df_leaves], ignore_index=True)
df_keep4 = pd.concat([df_keep4, df_back, df_new], ignore_index=True)
df_keep4['permno'] = df_keep4['permno'].astype('Int64')
print(f"fix deals {len(d_fix)} | rows that left with another permno {len(df_leaves)} | rows brought back from removed {len(df_back)} | fix rows added {len(df_new)}")
print(f"permnos with more than 1 deal after the fixes {(df_keep4.groupby('permno')['deal_no'].nunique() > 1).sum()}")

# %%
#cell (b) again on the table with the hand fixes: same rules as above. only the permnos with more than one deal change
df_b2 = df_keep4[['deal_no', 'permno']].merge(df_att1, on='deal_no').merge(df_close1, on='permno', how='left')
v_diff = (df_b2['sdc_close'] - df_b2['crsp_close'].abs()).abs()
df_b2['close_ok'] = (v_diff <= 0.01) | (v_diff <= v_close_pct * df_b2['crsp_close'].abs())
l_win = []
d_winner = {}
d_stage = {}
for v_permno, df_g in df_b2.groupby('permno'):
    if len(df_g) == 1:
        l_win.append(df_g[['deal_no', 'permno']])
        continue
    df_c = df_g[df_g['main']] if df_g['main'].any() else df_g
    v_stage = 'one main' if len(df_c) == 1 else None
    for v_name, v_col in (('1 close', 'close_ok'), ('2 domestic', 'us_alone'), ('3 completed', 'completed')):
        if len(df_c) == 1:
            break
        df_k = df_c[df_c[v_col]]
        if 0 < len(df_k) < len(df_c):
            df_c = df_k
            v_stage = v_name
    if len(df_c) > 1:
        df_k = df_c[df_c['e002']]
        if len(df_k) == 0:
            v_stage = '4 drop all'
            df_c = df_c.iloc[0:0]
        else:
            df_c = df_k.sort_values(['filing', 'proceeds', 'deal_no'], ascending=[True, False, True]).iloc[:1]
            v_stage = '4 002 or tie'
    d_stage[v_stage] = d_stage.get(v_stage, 0) + 1
    l_win.append(df_c[['deal_no', 'permno']])
    d_winner[v_permno] = df_c['deal_no'].iloc[0] if len(df_c) > 0 else pd.NA
df_win2 = pd.concat(l_win)
f_b2 = df_keep4.merge(df_win2.assign(_won=1), on=['deal_no', 'permno'], how='left')['_won'].eq(1).values
df_keep5 = df_keep4[f_b2].copy()
df_lost2 = df_keep4[~f_b2].copy()
df_lost2['removed_by'] = 'one deal per permno (after the hand fixes)'
df_lost2['lost_to'] = df_lost2['permno'].map(d_winner).astype('Int64')
df_removed3 = pd.concat([df_removed2, df_lost2], ignore_index=True)
df_removed3['lost_to'] = df_removed3['lost_to'].astype('Int64')
print(f"second run: decided by {d_stage} | rows removed {len(df_lost2)}")

# %%
#final table: the rows with a permno and the deals with no permno that were not dropped. the first crsp trading date and the days to the sdc issue date are calculated again for every row (the fixed permnos were not in step 1)
df_final1 = pd.concat([df_keep5, df_unmatched3], ignore_index=True)
df_first1 = duckdb.query(f"SELECT permno, MIN(secinfostartdt)::DATE AS crsp_first_trading_date FROM read_parquet('{p_secinfo}') GROUP BY permno").df()
df_first1['crsp_first_trading_date'] = pd.to_datetime(df_first1['crsp_first_trading_date'])
df_final2 = df_final1.drop(columns=['crsp_first_trading_date', 'sdc_minus_crsp_days']).merge(df_first1, on='permno', how='left')
#a deal on the fix list can have a first trading date given by hand (column crsp_first_trading_date of the table): the permno is right but its earliest record belongs to an earlier listing of the same permno, for example a second step conversion (Atlantic Coast Financial, permno 90399, listed in 2004 as Atlantic Coast Federal, new shares from 2011-02-04). the hand date replaces the date of the permno for that deal
if 'crsp_first_trading_date' in df_exc1.columns:
    s_hand = df_exc1.dropna(subset=['crsp_first_trading_date']).set_index('deal_no')['crsp_first_trading_date']
    df_final2['crsp_first_trading_date'] = pd.to_datetime(df_final2['deal_no'].map(s_hand)).fillna(df_final2['crsp_first_trading_date'])
    print(f"first trading dates given by hand {len(s_hand)}")
df_final2['sdc_minus_crsp_days'] = (df_final2['sdc_issue_date'] - df_final2['crsp_first_trading_date']).dt.days
df_final2 = df_final2[df_final1.columns].sort_values(['deal_no', 'permno']).reset_index(drop=True)
s_final = df_final2.dropna(subset=['permno']).groupby('permno')['deal_no'].nunique()
print(f"rows {len(df_final2)} | deals {df_final2['deal_no'].nunique()} | deals with a permno {df_final2.loc[df_final2['permno'].notna(), 'deal_no'].nunique()} | deals with no permno {df_final2.loc[df_final2['permno'].isna(), 'deal_no'].nunique()}")
print(f"permnos {len(s_final)} | with more than 1 deal {(s_final > 1).sum()} | deals with more than one permno {(df_final2.dropna(subset=['permno']).groupby('deal_no')['permno'].nunique() > 1).sum()}")
print(df_removed3.groupby('removed_by').size().to_string())
df_final2.to_parquet(p_path / 'sdc' / f"sdc_ipo_step2_{v_outputfile}.parquet", index=False)
df_removed3.to_parquet(p_path / 'sdc' / f"sdc_ipo_step2_removed_{v_outputfile}.parquet", index=False)
