# %%
import os
import sys
import time
import duckdb
import pandas as pd
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
sys.path.append(str(Path.cwd().parent / "shared"))   #run from this folder: the shared name matching file is in ../shared
import Ex1_name_score as ns

# %%
#folders and files: change accordingly. the sdc table is the output of Ex1_01_sdc_import, the crsp table is the output of Ex1_01_wrds_download
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download. the input is sdc_ipo_raw_<v_outputfile>.parquet, the outputs are sdc_ipo_step0_<v_outputfile>.parquet (deals after the filters) and sdc_ipo_step1_<v_outputfile>.parquet (deals and permnos), all in p_path/sdc
p_secinfo=p_path / 'crsp_a_stock' / 'stksecurityinfohist.parquet'
v_ticker_days=30 #ticker way: the crsp ticker must be in use within this many days of the sdc issue date
v_first_trade_days=14 #ticker way: the sdc issue date and the first crsp trading date of the permno must be at most this many days apart
v_min_score=70 #ticker way: minimum name score
v_nw=os.cpu_count() #workers that score the name pairs. 1 = no extra processes
v_reuse_scores=True #True = the name scores saved by an earlier run are read and only the pairs that are not in them are scored. False = everything is scored again (use it after the name matching code changes)
p_scores_permno=p_path / 'sdc' / f"name_scores_permno_{p_secinfo.stat().st_size}_{p_secinfo.stat().st_mtime_ns}.parquet" #saved scores: sdc name and crsp permno (best over its names). the same file is read by Ex1_04_match_ritter. the file name has the size and time of the crsp security info file, so a new crsp download is scored again
p_work=p_path / 'sdc' / 'step3_work' #temporary files of the workers

# %%
if __name__ == '__main__':
    #step 0. the sdc deals as imported (59,381 deals, columns named by their syntax code)
    df_sdc0_1 = pd.read_parquet(p_path / 'sdc' / f"sdc_ipo_raw_{v_outputfile}.parquet")
    os.makedirs(p_work, exist_ok=True)
    print(df_sdc0_1.shape)

# %%
if __name__ == '__main__':
    #step 0, three filters. a deal is dropped only when the value is an explicit No (False) or, for the listing nation, a country other than the united states. blank values stay
    df_sdc0_2 = df_sdc0_1.copy()
    v_n0 = len(df_sdc0_2)
    df_sdc0_2 = df_sdc0_2[df_sdc0_2['TR_NIIsIpo'].astype(str).str.lower() != 'false']
    v_n1 = len(df_sdc0_2)
    df_sdc0_2 = df_sdc0_2[df_sdc0_2['TR_NIIsOriginalIpo'].astype(str).str.lower() != 'false']
    v_n2 = len(df_sdc0_2)
    df_sdc0_2 = df_sdc0_2[(df_sdc0_2['TR_NIPrimaryListingNation'] == 'United States') | df_sdc0_2['TR_NIPrimaryListingNation'].isna()]
    v_n3 = len(df_sdc0_2)
    print(f"deals {v_n0} | IPO Flag not No {v_n1} (dropped {v_n0 - v_n1}) | Original IPO Flag not No {v_n2} (dropped {v_n1 - v_n2}) | listing nation United States or blank {v_n3} (dropped {v_n2 - v_n3})")

# %%
if __name__ == '__main__':
    #step 0, crsp end date: the maximum secinfoenddt of the crsp security info table, turned into the end of its month. deals with an issue date after it are dropped, a deal on that date is kept
    df_sdc0_3 = df_sdc0_2.copy()
    df_sdc0_3['TR_NIIssueDate'] = pd.to_datetime(df_sdc0_3['TR_NIIssueDate']).dt.normalize()
    v_max_end = pd.Timestamp(duckdb.sql(f"SELECT MAX(secinfoenddt) FROM read_parquet('{p_secinfo}')").fetchone()[0])
    v_eom = v_max_end + pd.offsets.MonthEnd(0)
    v_n_after = int((df_sdc0_3['TR_NIIssueDate'] > v_eom).sum())
    v_n_between = int(((df_sdc0_3['TR_NIIssueDate'] > v_max_end) & (df_sdc0_3['TR_NIIssueDate'] <= v_eom)).sum())
    df_sdc0_3 = df_sdc0_3[df_sdc0_3['TR_NIIssueDate'] <= v_eom]
    print(f"crsp maximum secinfoenddt {v_max_end.date()} | end of its month {v_eom.date()} | deals dropped {v_n_after} | deals between the two dates {v_n_between} | deals left {len(df_sdc0_3)}")
    df_sdc0_3.to_parquet(p_path / 'sdc' / f"sdc_ipo_step0_{v_outputfile}.parquet", index=False)

# %%
if __name__ == '__main__':
    #step 1 starts here. the deals with the columns the matching needs, one row per sdc deal number
    df_sdc1 = df_sdc0_3[['TR_NISdcDealNumber', 'TR_NIIssuerCusip9', 'TR_NIIssuerSDCCusip', 'TR_NIIssuerPrimayTickerSymbol', 'TR_NIIssuer', 'TR_NIIssueDate']].rename(columns={'TR_NISdcDealNumber': 'deal_no', 'TR_NIIssuerCusip9': 'sdc_cusip9', 'TR_NIIssuerSDCCusip': 'sdc_cusip6', 'TR_NIIssuerPrimayTickerSymbol': 'sdc_ticker', 'TR_NIIssuer': 'sdc_name', 'TR_NIIssueDate': 'sdc_issue_date'})
    df_sdc1['deal_no'] = df_sdc1['deal_no'].astype('int64')
    df_sdc1['sdc_ticker'] = df_sdc1['sdc_ticker'].str.upper().str.strip()
    print(df_sdc1.shape, df_sdc1['deal_no'].is_unique)

# %%
if __name__ == '__main__':
    #crsp security info history: one row per permno and period, with cusip9, ticker, trading symbol and name
    df_crsp1 = pd.read_parquet(p_secinfo, columns=['permno', 'cusip9', 'ticker', 'tradingsymbol', 'issuernm', 'secinfostartdt', 'secinfoenddt'])
    print(df_crsp1.shape, df_crsp1['permno'].nunique())

# %%
if __name__ == '__main__':
    #pass 1, all 9 characters of the cusip
    df_pass1 = duckdb.query("""
        SELECT DISTINCT s.deal_no, c.permno, '1 cusip9' AS pass
        FROM df_sdc1 s JOIN df_crsp1 c ON s.sdc_cusip9 = c.cusip9
    """).df()
    print(f"pass 1: deals {df_pass1['deal_no'].nunique()} | rows {len(df_pass1)}")

# %%
if __name__ == '__main__':
    #pass 2, first 8 characters (the 9th is a check digit). only for deals pass 1 did not find
    df_pass2 = duckdb.query("""
        SELECT DISTINCT s.deal_no, c.permno, '2 cusip8' AS pass
        FROM df_sdc1 s JOIN df_crsp1 c ON LEFT(s.sdc_cusip9, 8) = LEFT(c.cusip9, 8)
        WHERE s.sdc_cusip9 IS NOT NULL AND s.deal_no NOT IN (SELECT deal_no FROM df_pass1)
    """).df()
    print(f"pass 2: deals {df_pass2['deal_no'].nunique()} | rows {len(df_pass2)}")

# %%
if __name__ == '__main__':
    #pass 3, first 6 characters (the issuer): the first 6 of the 9 digit cusip, or the 6 digit sdc cusip when there is no 9 digit one. only for deals passes 1 and 2 did not find
    df_pass3 = duckdb.query("""
        SELECT DISTINCT s.deal_no, c.permno, '3 cusip6' AS pass
        FROM df_sdc1 s JOIN df_crsp1 c ON COALESCE(LEFT(s.sdc_cusip9, 6), s.sdc_cusip6) = LEFT(c.cusip9, 6)
        WHERE s.deal_no NOT IN (SELECT deal_no FROM df_pass1) AND s.deal_no NOT IN (SELECT deal_no FROM df_pass2)
    """).df()
    print(f"pass 3: deals {df_pass3['deal_no'].nunique()} | rows {len(df_pass3)}")

# %%
if __name__ == '__main__':
    #first crsp trading date of each permno: the start date of its earliest security info record (it is the same date as the first daily return for all 40,518 permnos of the crsp download of 2026-10-27)
    df_first1 = df_crsp1.groupby('permno', as_index=False).agg(crsp_first_trading_date=('secinfostartdt', 'min'))
    df_first1['crsp_first_trading_date'] = pd.to_datetime(df_first1['crsp_first_trading_date']).dt.normalize()
    print(df_first1.shape)

# %%
if __name__ == '__main__':
    #ticker way, candidates. only for deals no cusip pass found. a crsp row is a candidate when the sdc ticker equals the crsp ticker or trading symbol and that period is within 30 days of the sdc issue date. the sdc issue date and the first crsp trading date of the permno must be at most 14 days apart
    df_cusip1 = pd.concat([df_pass1, df_pass2, df_pass3], ignore_index=True)
    df_cand1 = duckdb.query(f"""
        SELECT DISTINCT s.deal_no, s.sdc_name, s.sdc_issue_date, c.permno
        FROM df_sdc1 s JOIN df_crsp1 c ON (s.sdc_ticker = c.ticker OR s.sdc_ticker = c.tradingsymbol)
        JOIN df_first1 f ON f.permno = c.permno
        WHERE s.deal_no NOT IN (SELECT deal_no FROM df_cusip1) AND s.sdc_ticker IS NOT NULL
          AND c.secinfostartdt::DATE <= s.sdc_issue_date::DATE + {v_ticker_days} AND c.secinfoenddt::DATE >= s.sdc_issue_date::DATE - {v_ticker_days}
          AND ABS(s.sdc_issue_date::DATE - f.crsp_first_trading_date::DATE) <= {v_first_trade_days}
    """).df()
    print(f"ticker way: candidates after the ticker and 14 day tests {len(df_cand1)} | deals {df_cand1['deal_no'].nunique()}")

# %%
if __name__ == '__main__':
    #the name matching run, once. every pair of an sdc name and a crsp permno that step 1 needs (the pairs of the cusip passes and the candidates of the ticker way) is scored with the shared algorithm (Ex1_name_score.py, section "Name scoring algorithm" of the document): the sdc name against every name the permno has had, best score. the scores are saved (a run reads the saved scores and scores only the pairs that are not in them) and looked up by join below
    v_t0 = time.time()
    df_pairs1 = pd.concat([df_cusip1[['deal_no', 'permno']].merge(df_sdc1[['deal_no', 'sdc_name']], on='deal_no'), df_cand1[['deal_no', 'permno', 'sdc_name']]])
    df_pairs1 = df_pairs1.loc[df_pairs1['sdc_name'].notna(), ['sdc_name', 'permno']].drop_duplicates().rename(columns={'sdc_name': 'sname'})
    df_pairs1['permno'] = df_pairs1['permno'].astype('int64')
    df_sc_perm = pd.read_parquet(p_scores_permno) if (v_reuse_scores and p_scores_permno.exists()) else pd.DataFrame({'sname': pd.Series(dtype='str'), 'permno': pd.Series(dtype='int64'), 'score': pd.Series(dtype='float64')})
    df_todo1 = df_pairs1.merge(df_sc_perm[['sname', 'permno']], how='left', indicator=True)
    df_todo1 = df_todo1[df_todo1['_merge'] == 'left_only'][['sname', 'permno']]
    ns.load_names(p_secinfo) #the names are also needed here, to estimate the cost of each pair
    ex = ProcessPoolExecutor(max_workers=v_nw, initializer=ns.init_worker, initargs=(p_secinfo,))
    df_sc_perm = pd.concat([df_sc_perm, ns.run_scores(ex, df_todo1, 'permno', v_nw, p_work)], ignore_index=True)
    ex.shutdown()
    df_sc_perm.to_parquet(p_scores_permno, index=False)
    print(f"pairs needed {len(df_pairs1)} | scored now {len(df_todo1)} | saved {len(df_sc_perm)} | {time.time() - v_t0:.0f} seconds")

# %%
if __name__ == '__main__':
    #ticker way, name score minimum 70: the best score of each deal is kept
    df_cand2 = df_cand1.merge(df_sc_perm.rename(columns={'sname': 'sdc_name', 'score': 'name_score'}), on=['sdc_name', 'permno'], how='left')
    df_cand2['name_score'] = df_cand2['name_score'].fillna(0.0)
    df_cand2 = df_cand2[df_cand2['name_score'] >= v_min_score]
    df_cand2 = df_cand2[df_cand2['name_score'] == df_cand2.groupby('deal_no')['name_score'].transform('max')]
    df_ticker1 = df_cand2[['deal_no', 'permno']].assign(pass_='4 ticker').rename(columns={'pass_': 'pass'})
    print(f"ticker way: deals with a permno {df_ticker1['deal_no'].nunique()} | rows {len(df_ticker1)}")

# %%
if __name__ == '__main__':
    #puts the passes together: a deal keeps only the first pass that found it (the ticker way only ran for deals no cusip pass found), one row per deal and permno. a deal no way found stays as one row with an empty permno
    df_step1_1 = pd.concat([df_cusip1, df_ticker1], ignore_index=True).drop_duplicates(['deal_no', 'permno'])
    df_step1_2 = df_sdc1.merge(df_step1_1, on='deal_no', how='left')
    df_step1_2['permno'] = df_step1_2['permno'].astype('Int64')
    print(f"rows {len(df_step1_2)} | deals {df_step1_2['deal_no'].nunique()} | deals with a permno {df_step1_2.loc[df_step1_2['permno'].notna(), 'deal_no'].nunique()} | deals with no permno {df_step1_2.loc[df_step1_2['permno'].isna(), 'deal_no'].nunique()}")
    print(df_step1_2.groupby('pass', dropna=False)['deal_no'].nunique().to_string())

# %%
if __name__ == '__main__':
    #two date columns and the name score on every row, looked up in the saved scores. the cusip passes keep every row whatever the date difference or the score (reference only); the ticker way already enforced 14 days and 70
    df_step1_3 = df_step1_2.merge(df_first1, on='permno', how='left')
    df_step1_3['sdc_minus_crsp_days'] = (df_step1_3['sdc_issue_date'] - df_step1_3['crsp_first_trading_date']).dt.days
    df_step1_3 = df_step1_3.merge(df_sc_perm.rename(columns={'sname': 'sdc_name', 'score': 'name_score'}), on=['sdc_name', 'permno'], how='left')
    print(f"name score of {df_step1_3['name_score'].notna().sum()} rows")

# %%
if __name__ == '__main__':
    #permnos with more than one deal (step 2 leaves one deal for each permno)
    s_deals_per_permno = df_step1_3.dropna(subset=['permno']).groupby('permno')['deal_no'].nunique()
    print(f"permnos {len(s_deals_per_permno)} | with more than 1 deal {(s_deals_per_permno > 1).sum()}")
    df_step1_3.to_parquet(p_path / 'sdc' / f"sdc_ipo_step1_{v_outputfile}.parquet", index=False)
    print(df_step1_3.shape)
