# Parallelization blueprint

## 1. How I like to parallel

**TL;DR (do this):**
1. Find the smallest piece of work that can be done alone (one deal, one permno-month, one file). Write it down first.
2. Start **one** pool of workers (`os.cpu_count()`), once, and keep it for the whole program. One task per worker, and the task carries only the keys of its pieces, never the data.
3. Deal the pieces out so every worker has the same load: pieces of the same size in equal consecutive blocks; pieces of different sizes sorted by cost, largest first, dealt 1 to n then n back to 1 (round trip).
4. Pass data as parquet: the worker reads its own rows from a parquet, writes its own part parquet files, the main program joins the parts. Only counts and status come back through the executor.
5. Inside a worker, work one chunk at a time (read, process, write, free) so memory stays low.
6. Never parallel for requests to an outside site with a rate limit (SEC: 10 requests per second in total). One request at a time with a pause.
7. Every working cell starts with `if __name__ == '__main__':`, and the worker function lives in its own file in the workstream folder (Windows starts each worker from scratch).
8. Test before trusting: time the single process, compare the output with it (same rows, same content), and watch the RAM while it runs.

**What this means (the concept):**
- The CPU should be at about 99% from the first second to the last, with no spikes and no idle tail. Idle time comes from three places, and each rule above removes one: starting pools again and again (rule 2), one worker getting more work than the others (rule 3), and copying dataframes between processes (rule 4).
- The load of a piece is its cost, not its count. A name of 4 words is scored with every order of its words and a name of 1 word is not, so an even split by count can leave one worker with all the long names. Sort by cost and deal in a round trip: the largest to worker 1 ... the n-th to worker n, the next to worker n, back down to worker 1.
- The same code serves every step of a program: one pool, one store of results, and each step adds its tasks to the same pool. A step does not start its own pool.
- The pieces must not need each other. If two pieces need each other, the piece is too small.
- A speedup is only a claim after the single process was timed, and a result is only the same after the comparison with the single process (a gap of about 0.000001 is rounding).

**Where each rule is implemented now** (the rest of this document explains each one with what we tested):

| Program | Piece | Dealing | In and out |
|---|---|---|---|
| `shared/Ex1_name_score.py` (`run_scores`), used by `sdc_crsp/Ex1_02_merge_sdc_crsp` and `ritter/Ex1_04_match_ritter` | one pair of names (SDC name, CRSP permno or Ritter name) | by cost (number of word orders and names of the permno), round trip | parquet of pairs in, one parquet of scores out, saved and reused by the next run |
| `sec/Ex1_05_sec_prospectus_download_worker.py` | one json file of `submissions.zip` (one company) | by file size, round trip | the worker gets the position and size of its files in the zip, writes part parquets |
| `old/event_study/Ex1_worker.py` | one event | equal blocks | parquet in and out |

## 2. The details, step by step

Written 2026-10-28 from the work on the SEC bulk file reader and the existing patterns of T02 Ex8 (`Ex8_03_reg_full.py`, compared with other methods in `archive\old\Ex8\Ex8_03_reg_compare.py`) and T03 event study (`old/event_study/Ex1_02_event_study_preprocess.py`). The first reference implementation of the full pattern, the zip reader, is now `sec/Ex1_05_sec_prospectus_download_worker.py` (the October version is in `old/sdc_sec_oct`: `Ex1_06_sec_read.py` and `Ex1_06_worker.py`; the program names in the tables below are the October names).


### 1. The smallest slice
The smallest unit of work that can be done alone, with no other unit and no result of another unit. Everything else is built from it.

| Program | Smallest slice |
|---|---|
| T02 Ex8 | one permno-month (one regression) |
| T03 Ex1_02 | one event (permno and event date) |
| T03 Ex1_06 | one json file in `submissions.zip` (one company) |
| T03 Ex1_09 (candidate) | the documents of one deal |

Write the slice down before writing code. If two slices need each other, the slice is too small.

### 2. The slices divided by worker
One task per worker, and each task holds **only the keys of its slices** (permno and month, event id, file name), not the data. Workers = logical cores (`v_nproc = os.cpu_count()`, 16 here). Slices are divided so every worker has the same load.

### 3. The order of assignment (so the load is as even as possible)
- **Slices of the same size** (Ex8, Ex1_02): sort them in their natural order and cut the list into `v_nproc` consecutive blocks of the same count.
  `l_bounds = [round(i * len(df) / v_nw) for i in range(v_nw + 1)]`
- **Slices of very different sizes** (Ex1_06): sort the slices by size, largest first, and deal them out in a round trip. The largest to worker 1, the second to worker 2, ... the n-th to worker n, the next one to worker n again, then back down to worker 1, and so on (1 to n, n to 1).

```python
v_pos = df_files.index % (2 * v_nproc)   # 0 to n-1 going up, n to 2n-1 coming back
df_files['worker'] = v_pos.where(v_pos < v_nproc, 2 * v_nproc - 1 - v_pos)
```

The size of each file is in the index of the zip (read in 8 seconds). Tested on the 996,029 files of `submissions.zip`, 16 workers. The load is bytes of json (that time follows the size is an assumption, not tested):

| Division | Busiest worker / average |
|---|---|
| Even split by count in file order (as Ex1_02 does for events) | 4.57 |
| Largest first, dealt 1, 2, 3, ... n, 1, 2, 3 ... | 1.007 |
| Largest first, round trip 1 to n, n to 1 (the one used) | 1.006 |

In the real run every worker got 62,251 or 62,252 files and 359 to 363 MB. Print this table (files and size per worker) at the start of every run.

### 4. Parquet is the way to pass data
- **In:** the task carries the path of the parquet file and the keys. The worker reads **its own rows** from the parquet (duckdb or pyarrow with a filter). No dataframe is copied from the main process to the workers. `Ex8_03_reg_compare.py` runs both ways on the same sample (a method that sends each group's dataframe and a method where each task receives the file path and the permnos and reads its rows) and times them, with a check that the results are the same.
- **Out:** each worker writes its **own part files** as parquet (`entities_3.parquet`, `filings_3.parquet`), never returns the big table through the executor. The main program joins the parts into the final parquet one batch at a time (`ParquetWriter`, `iter_batches`) and deletes them. Only small things (counts, status) come back as return values.
- **Progress:** each worker writes its count to its own small text file (`progress\3.txt`). The main program adds them up every 30 seconds.
- Fixed schema in the workers (`pyarrow` schema), so all parts have the same types.

### 5. The groups inside the worker
A worker does not take its whole block at once. It takes a chunk (`v_chunk` slices, or about `v_chunk_permnos` permnos worth of events), reads what it needs for the chunk, processes it, writes it to its part file, frees it, and takes the next chunk. The chunk is what limits the memory of the worker. Too small a chunk is slow (many small reads); too large a chunk uses memory.

### 6. Testing the right size
Do not guess `v_chunk` or the number of workers. Test on a sample and keep a table:

| Setting | Seconds | Peak memory of all workers (GB) | Same result as the single process? |
|---|---|---|---|
| single process | | | (reference) |
| `v_chunk` small | | | |
| `v_chunk` medium | | | |
| `v_chunk` large | | | |
| fewer workers | | | |

Choose the setting where more memory buys almost no more speed. What the existing programs found (from their own comments, not retested here):
- Ex8: one read per permno-month was about 5 times slower; `v_chunk = 200` permno-months is close to reading the whole block at once and keeps memory low.
- Ex1_02: `v_chunk_permnos = 50` permnos per read.
- Ex1_06: `v_chunk` 20,000 and 2,000 files per chunk used the same memory (about 13.5 GB in all workers). Time for the two settings was not compared.

The **correctness test** goes with every change: save a fingerprint of the current output before the change (row count and a hash of the sorted content of each table), delete the output, run the new program, take the fingerprint again, compare. Ex1_06 matched on rows, content and columns for both tables (990,624 companies and 3,166,599 filings). Check first that no other notebook or program is using the files. `Ex8_03_reg_compare.py` does the same with the maximum absolute difference per column against the single process (0 = identical).

## 3. Files and rules (Windows)

| File | What it holds |
|---|---|
| `Ex1_0X_name.py` / `.ipynb` | parameters, the list of slices, the tasks, the `ProcessPoolExecutor` loop, the join of the part files |
| `Ex1_0X_worker.py` | the function the workers run, in its own file because Windows starts each worker from scratch and must be able to import it |

- `sys.path.append(str(Path.cwd()))` and `import <worker file>`: run the notebook from its own folder.
- Every cell that does work starts with `if __name__ == '__main__':`.
- Run scripts with `python -u` when the output goes to a log, otherwise the progress lines are buffered.
- Numpy and duckdb threads inside each worker are limited to 1 (`v_threads_reg`, `v_threads_duckdb`) when they are used, so processes x threads does not go above the cpu count.

## 4. Where parallel is not allowed: requests to an outside site

`Ex1_08_sec_download.py` stays **sequential**: one request at a time, a pause of 0.5 seconds (2 requests per second). The SEC limit is 10 requests per second in total, so parallel workers would add up to more than the limit (sec.gov webmaster FAQ and privacy page, read 2026-10-28). The header is `user/user@domain.com`. Nothing that sends requests to the SEC is run without a clear yes (`CLAUDE.md`, items 13 and 14).

## 5. What we measured (2026-10-28)

| Program | What it does | Time | Parallel? |
|---|---|---|---|
| Ex1_06 | reads `submissions.zip` into two parquet files | workers done in 51 s with 16 workers (single process never timed) | yes, done |
| Ex1_07 | picks one filing per deal (duckdb joins and name scores) | 107 s | not yet, duckdb already uses threads |
| Ex1_08 | downloads documents | limited by the SEC rate | no, never |
| Ex1_09 | reads the downloaded documents and chooses between tied filings | 162 s | candidate, the slice is one deal |

An earlier version of the zip reader with 8 workers and a plain split took 640 seconds.

## 6. Memory: monitor it, and lower it where it costs little speed

**Note for every parallel run: watch the RAM while it runs, and look for ways to lower high consumption without a significant tradeoff on speed.**

What we saw on Ex1_06 (34 GB of RAM, 16 workers):
- `v_chunk = 20000`: workers at 13.8 GB, then 14.9 GB twenty seconds later; available RAM fell from 7.6 GB to 6.6 GB. Stopped by hand.
- `v_chunk = 2000`: the same, about 13.5 GB in total, 0.85 GB per worker, 77% of the RAM used, 8 GB available. The run finished.
- **Cause, tested (2026-10-28):** one process that only opens `submissions.zip` (`zipfile.ZipFile`) goes from 22 MB to 724 MB, because it loads the list of its 996,030 entries. Reading and parsing the 2,000 largest json files on top of that added about 24 MB. So about 700 MB of each worker's 850 MB is the entry list, and 16 workers hold 16 copies (about 11 GB of the 13.5 GB). That is why the chunk size changed nothing.
- **Fix, done and tested (2026-10-28):** the main program lists the zip once and gives each worker the position and the compressed size of its files; the worker opens the zip as a plain file, reads those bytes and decompresses them (`zlib.decompress(bytes, -15)`), and never loads the list. All 996,029 entries are deflate and none needs zip64, which was checked first.

| Version | Workers done in | Workers memory, all 16 | Largest worker | RAM used (34 GB computer) | Output vs the original |
|---|---|---|---|---|---|
| `zipfile.ZipFile` in each worker | 51 s | 13.5 GB | 0.85 GB | 77% | same |
| plain file, position and size | 33 s | 2.3 to 2.7 GB | 0.15 to 0.18 GB | 46% (includes the main program's own copy of the list) | same (rows, content, columns of both tables) |
- Other options: fewer workers (memory is per worker, time is not), a smaller chunk when the memory is the data and not the overhead.

How to monitor (reads only, no process is touched):

```python
import psutil, time
for i in range(6):
    m = psutil.virtual_memory()
    w = [p.memory_info().rss / 1e9 for p in psutil.process_iter()
         if p.name().lower().startswith('python') and 'spawn_main' in ' '.join(p.cmdline())]
    print(time.strftime('%H:%M:%S'), 'used %', m.percent, '| available GB', round(m.available / 1e9, 1),
          '| workers', len(w), '| workers GB', round(sum(w), 1), '| max one', round(max(w), 2) if w else 0)
    time.sleep(10)
```

Do not stop worker processes by name: other programs' workers look the same (`spawn_main`). Stop the run through the task that started it.

## 7. Open items

- Memory of Ex1_06: test the offset reading, and fill the table of step 6 (time and memory for each setting).
- Ex1_09: a parallel version by deal (slice = the documents of one deal, load = size of the downloaded files).
- Ex1_07: check where the 107 seconds go before changing it (the name score loop is single process).
- When a program is parallelized, time the single process first so the speedup can be stated.
