#functions used by Ex1_06_prospectus_read. they live in their own file because the worker processes (windows starts them from scratch) must be able to import it
#keep this file in the same folder as the main program is run from
#the smallest slice is one document: the reader needs only the text of the first 60,000 characters of that filing. one task per worker, the documents of its share are read and the rows are written to its own part file
import html
import os
import re
import pandas as pd
from datetime import datetime
MON = 'january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec'
NUM = r'\d{1,3}(?:\s?,\d{3})+|\d{4,}'

def text_of(path, n=60000):
    s = open(path, encoding='utf-8', errors='ignore').read(600000)
    s = re.sub(r'(?is)<(script|style).*?</\1>', ' ', s)
    s = re.sub(r'<[^>]+>', ' ', s)
    s = html.unescape(s)
    s = s.replace('\ufffd', '"').replace('\u201c', '"').replace('\u201d', '"').replace('\u2019', "'").replace('\u2018', "'")
    s = s.replace('\xa0', ' ')
    s = re.sub(r'\s+', ' ', s)
    # skip the SGML header of old text filings: start at the form line
    i = s.find('FILE PURSUANT')
    m = re.search(r'(?i)(pursuant to rule 424|registration (no|number|statement no))', s)
    s = fix_numbers(s)
    return s[:n]

def fix_numbers(s):
    def rep(m):
        g = m.group()
        tail = g[len(g.rstrip()):]
        c = re.sub(r'\s', '', g)
        return c + tail if re.fullmatch(r'\d{1,3}(?:,\d{3})+', c) else g
    return re.sub(r'(?<![\d\-\.])(?<!\d\s)\d[\d ]{0,3}(?:\s?,\s?[\d ]{1,4}){1,3}', rep, s)

def to_int(x):
    return int(re.sub(r'[,\s]', '', x))

def to_price(x):
    x = x.strip()
    m = re.match(r'^(\d+)\s+(\d+)/(\d+)$', x)
    if m: return int(m.group(1)) + int(m.group(2)) / int(m.group(3))
    return float(x.replace(',', ''))

PRICE = r'\$\s?(\d{1,4}(?:\.\d{1,4})?(?:\s+\d{1,2}/\d{1,2})?)'

PR = r'\$\s?(\d{1,4}(?:\.\d{1,4})?(?:\s+\d{1,2}/\d{1,2})?)(?![\d,]|\s*(?:million|billion))'

def _ok(x):
    try:
        p = to_price(x)
        return p if 0.01 <= p <= 5000 else None
    except Exception:
        return None

BAD = re.compile(r'(?i)exercis|warrant|discount|commission|sales load|underwrit\w* compensation|per share of common stock,? (?:subject|based)|aggregate|estimated|fees|expenses|up to|rights? to purchase|purchase|exceeds|equals or|redeem|redemption|deferred|non-accountable|conversion')

def find_price_old(t):
    h = t[:30000]
    pats = ((r'(?i)(?:initial public offering|offering) price (?:per (?:share|unit|ads|adr|american depositary share) )?(?:of|is|will be|was)[^$]{0,40}?' + PR, None),
            (r'(?i)each unit (?:that we are offering )?has (?:an offering )?price of ' + PR, None),
            (r'(?i)units (?:are|is) being offered at a price of ' + PR, None),
            (r'(?i)\bper\s+(?:share|ads|adr|american depositary share|common share|ordinary share|depositary share)(?: of [a-z ]{3,30})?[ .:\-_$]{0,80}?' + PR + r'\s+\$?\s?\.?\d', None),
            (r'(?i)\bper\s+unit[ .:\-_$]{0,80}?' + PR + r'\s+\$?\s?\.?\d', None),
            (r'(?i)initial public offering price[^$]{0,80}?' + PR, None),
            (r'(?i)' + PR + r'\s+per\s+unit\b', 5000),
            (r'(?i)\bprice\s+' + PR + r'\s+(?:a|per|each)\s+(?:share|unit|ads|adr)', None),
            (r'(?i)' + PR + r'\s+(?:a|per|each)\s+(?:share|unit|ads|adr|american depositary)', 4000),
            (r'(?i)\bper (?:share|unit|ads)\b[ .:\-_$]{0,80}?' + PR, None),
            (r'(?i)(?:public offering price|price to (?:the )?public)[^$]{0,120}?' + PR, None),
            (r'(?i)offered at (?:a price of )?' + PR, None))
    for i, (pat, span) in enumerate(pats):
        for m in re.finditer(pat, h[:span] if span else h):
            ctx = h[max(0, m.start() - 90):m.start()]
            if i not in (3, 4) and BAD.search(ctx): continue
            p = _ok(m.group(1))
            if p and p >= 0.1: return p
    return None

def cover_start(t):
    ph = list(re.finditer(r'(?i)(?:business|mail) phone:?\s*[\d\-\(\) ]*', t[:12000]))
    if ph: return ph[-1].end()
    m = re.search(r'(?i)(filed pursuant to rule|pursuant to rule 424|rule 424\(b\)|registration (?:no|number|statement no))', t[:12000])
    return max(0, m.start() - 100) if m else 0

def find_total_shares(t):
    UNIT = r'(?:shares|units|ads|adss|american depositary shares|depositary shares|ordinary shares|common shares)'
    c0 = cover_start(t)
    head = t[c0:c0 + 3500]
    for m in re.finditer(r'(?i)(' + NUM + r')\s*(?:[A-Za-z\-\.,\']+\s+){0,3}?' + UNIT + r'\b', head):
        ctx = head[max(0, m.start() - 45):m.start()]
        if re.search(r'(?i)additional|up to|aggregate of|selling|sold by|option|over-?allot|representing|after|outstanding', ctx): continue
        v = to_int(m.group(1))
        if v >= 1000: return v
    for pat in (r'(?i)securities being offered:?\s*(' + NUM + r')', r'(?i)(?:shares|units|ads|adss|securities) offered:?\s*(' + NUM + r')',
                r'(?i)(?:we|the company) (?:are|is) (?:offering|selling)\s+(' + NUM + r')\s+' + UNIT, r'(?i)offering\s+(' + NUM + r')\s+' + UNIT):
        m = re.search(pat, t[:40000])
        if m:
            v = to_int(m.group(1))
            if v >= 1000: return v
    return None

def _split_patterns(head):
    # "Of the 4,000,000 shares offered hereby, 3,000,000 shares are being sold by the Company and 1,000,000 are being sold by ..."
    m = re.search(r'(?i)of the (' + NUM + r')\s+.{0,200}?offered hereby.{0,120}?,\s*(' + NUM + r')\s*(?:[A-Za-z]+\s+)?(?:are|is) being (?:sold|offered) by.{0,250}?\band\s+(' + NUM + r')\s*(?:[A-Za-z]+\s+)?(?:are|is) being (?:sold|offered) by', head)
    if m: return to_int(m.group(2)), to_int(m.group(3))
    prim = sec = None
    for m in re.finditer(r'(?i)(?:is|are) (?:selling|offering) (?:an additional\s+)?(' + NUM + r')', head):
        ctx = head[max(0, m.start() - 130):m.start()]
        if re.search(r'(?i)selling\s+(?:stock|share)holders?|selling securityholders?|certain (?:stock|share)holders|selling shareholders?', ctx[-110:]):
            if sec is None: sec = to_int(m.group(1))
        elif prim is None: prim = to_int(m.group(1))
    return prim, sec

def _sentence_split(head):
    UN = r'(?:shares|adss|ads|american depositary shares|units|common shares|ordinary shares)'
    GAP = r'(?:(?!\d)[^.]){0,60}?'
    prim, sec = _split_patterns(head)
    if prim is not None or sec is not None: return prim, sec
    m = re.search(r'(?i)\b(?:we|the company|us) (?:are|is) (?:selling|offering)\s+(' + NUM + r')\s+' + UN, head)
    if m: prim = to_int(m.group(1))
    m = re.search(r'(?i)(' + NUM + r')\s+' + UN + GAP + r'(?:are|is) (?:being )?(?:sold|offered) by (?:the )?(?:company|us)\b(?!.s parent)', head)
    if m and prim is None: prim = to_int(m.group(1))
    m = re.search(r'(?i)selling (?:stock|share)holders?(?: named[^.]{0,40})? (?:are|is) (?:selling|offering)\s+(?:an aggregate of\s+)?(' + NUM + r')', head)
    if m: sec = to_int(m.group(1))
    if sec is None:
        m = re.search(r'(?i)(' + NUM + r')\s+' + UN + GAP + r'(?:are|is) (?:being )?(?:sold|offered) by (?:the )?(?:selling|company.s parent|parent)', head)
        if m: sec = to_int(m.group(1))
    return prim, sec

def find_split(t, total):
    head = t[:9000]
    prim, sec = _sentence_split(head)
    if prim is not None or sec is not None:
        if prim is not None and total and prim <= total and (sec is None or prim + sec != total) and re.search(r'(?i)selling (?:stock|share)holder|selling securityholder|company.s parent', head): sec = total - prim
        if sec is not None and prim is None and total and sec <= total: prim = total - sec
        return prim, sec
    prim = sec = None
    m = re.search(r'(?i)(?:the )?(?:company|we|us|issuer|[A-Z][\w.&\' ,-]{2,40}?)\s+(?:is|are)\s+offering\s+(' + NUM + r')\s+(?:shares|units|american depositary)', head)
    m2 = re.search(r'(?i)selling (?:stock|share)holders?[^.]{0,80}?(?:is|are)\s+offering\s+(' + NUM + r')', head)
    if re.search(r'(?i)\bwe are offering (' + NUM + r')', head):
        prim = to_int(re.search(r'(?i)\bwe are offering (' + NUM + r')', head).group(1))
    elif m: prim = to_int(m.group(1))
    if m2: sec = to_int(m2.group(1))
    m3 = re.search(r'(?i)(' + NUM + r')\s+shares\s+(?:are|is|will be)\s+(?:being\s+)?(?:offered|sold)\s+by\s+(?:the\s+)?(?:company|us)[^.]{0,80}?(' + NUM + r')\s+shares\s+(?:are|is|will be)\s+(?:being\s+)?(?:offered|sold)\s+by\s+the\s+selling', head)
    if m3 and prim is None: prim, sec = to_int(m3.group(1)), to_int(m3.group(2))
    if prim is None and sec is None and total:
        if re.search(r'(?i)all of the[^.]{0,60}shares[^.]{0,100}(?:are|is) being (?:offered|sold) by the (?:company|issuer)|all of the shares of common stock offered hereby are being (?:offered|sold) by (?:the )?[a-z .,&\'-]{2,50}\(the "?(?:company|offering)', head):
            prim, sec = total, 0
        elif re.search(r'(?i)all of the[^.]{0,100}shares[^.]{0,100}(?:are|is) being (?:offered|sold) by the selling', head):
            prim, sec = 0, total
        elif not re.search(r'(?i)selling\s+(?:stock|share)holders?|selling securityholders?|selling shareholders?', head):
            prim, sec = total, 0
    if prim is None and sec is None:
        m = re.search(r'(?i)(?:company|we)\b[^.]{0,60}?\b(?:hereby\s+)?offer(?:s|ing)?\s*(?:\([^)]{0,30}\)\s*)?(' + NUM + r')\s*(?:shares|units|ads|adss)', head)
        if m: prim = to_int(m.group(1))
    if prim is not None and sec is None and total and prim <= total: sec = total - prim
    if sec is not None and prim is None and total and sec <= total: prim = total - sec
    return prim, sec

def find_us_intl(t):
    head = t[:9000]
    m = re.search(r'(?i)(' + NUM + r')\s+shares[^.]{0,200}?(?:in|inside|within) the united states[^.]{0,120}?(' + NUM + r')\s+shares[^.]{0,120}?(?:outside|in)\s+(?:of\s+)?(?:the\s+)?(?:united states|international)', head)
    if m: return to_int(m.group(1)), to_int(m.group(2))
    m = re.search(r'(?i)(' + NUM + r')\s+shares[^.]{0,100}?(?:are|is) (?:being )?offered (?:initially )?(?:in|inside)[^.]{0,40}?united states[^.]{0,200}?(' + NUM + r')\s+shares[^.]{0,80}?outside', head)
    if m: return to_int(m.group(1)), to_int(m.group(2))
    return None, None

def find_symbol(t):
    m = re.search(r'(?i)(?:under|using) the (?:trading )?(?:ticker )?symbol[s]?\s*(?:of\s*)?["\']?\s*([A-Z][A-Z0-9.\-]{0,6})\b', t[:20000])
    if m: return m.group(1).upper()
    m = re.search(r'(?i)symbol\s+["\']\s*([A-Z][A-Z0-9.\-]{0,6})\s*["\']', t[:20000])
    return m.group(1).upper() if m else None

def find_exchange(t):
    head = t[:20000]
    for name, pat in (('NYSE', r'new york stock exchange|\bnyse\b'), ('Nasdaq', r'nasdaq|national market system|national association of securities dealers automated'),
                      ('AMEX', r'american stock exchange|\bamex\b|nyse american|nyse mkt'), ('Other', r'pacific (?:stock )?exchange|chicago board options|boston stock exchange|cboe|otc bulletin|ots')):
        m = re.search(r'(?i)(?:listed|listing|quot\w+|trad\w+|approved)[^.]{0,120}?(?:' + pat + ')', head)
        if m: return name
    return None

def _pd(x):
    x = re.sub(r'\bSept\b', 'Sep', re.sub(r'\s+', ' ', x).replace('.', '').replace(',', ''))
    for fmt in ('%B %d %Y', '%b %d %Y', '%d %B %Y', '%d %b %Y'):
        try: return datetime.strptime(x, fmt).date()
        except Exception: pass
    return None

def find_date(t):
    from datetime import timedelta
    pats = [r'(?i)prospectus(?: supplement)? dated\s*:?\s*((?:' + MON + r')\.?\s+\d{1,2},?\s+\d{4})',
            r'(?i)the date of this prospectus(?: supplement)? is\s*((?:' + MON + r')\.?\s+\d{1,2},?\s+\d{4})',
            r'(?i)prospectus(?: supplement)? dated\s*:?\s*(\d{1,2}\s+(?:' + MON + r')\.?,?\s+\d{4})']
    for p in pats:
        m = re.search(p, t)
        if m:
            d = _pd(m.group(1))
            if d: return d
    m = re.search(r'(?i)(?:through and including|until)\s+((?:' + MON + r')\.?\s+\d{1,2},?\s+\d{4}),?\s*\((?:the\s+)?(\d{1,3})(?:st|nd|rd|th)?\s+days? after', t)
    if m:
        d = _pd(m.group(1))
        if d: return d - timedelta(days=int(m.group(2)))
    m = re.search(r'(?i)((?:' + MON + r')\.?\s+\d{1,2},?\s+\d{4})\s*(?:\d{1,2}\s+)?(?:\[[^\]]{0,80}\]\s+)?(?:table of contents|inside front cover|prospectus summary|cover of prospectus)', t[:30000])
    if m:
        d = _pd(m.group(1))
        if d: return d
    m = re.search(r'(?i)dated\s*:?\s*((?:' + MON + r')\.?\s+\d{1,2},?\s+\d{4})', t[:6000])
    if m: return _pd(m.group(1))
    return None

def find_cusip(t):
    m = re.search(r'(?i)cusip\s*(?:no\.?|number|#)?\s*:?\s*([0-9A-Z]{6}[0-9A-Z]{0,3}\b)', t[:30000])
    return m.group(1) if m else None

def parse(path):
    t = text_of(path)
    tot = find_total_shares(t)
    prim, sec = find_split(t, tot)
    us, intl = find_us_intl(t)
    return dict(doc_price=find_price(t), doc_total_shares=tot, doc_primary_shares=prim, doc_secondary_shares=sec,
                doc_us_shares=us, doc_intl_shares=intl, doc_symbol_cover=find_symbol(t), doc_exchange=find_exchange(t),
                doc_prospectus_date=find_date(t), doc_cusip=find_cusip(t), doc_chars=len(t))


# ---- stricter price reader (table rows checked by price = discount + proceeds), old logic only as a fallback
NUMX = r'(\d[\d,]*(?:\.\d+)?|\.\d+)'
ROW = re.compile(r'(?i)\bper\s+(share|unit|ads|adr|american depositary share|common share|ordinary share|depositary share|security|trust share|warrant)\b[^$]{0,140}?\$\s?' + NUMX + r'\s+\$?\s?' + NUMX + r'\s+\$?\s?' + NUMX)
BAD2 = re.compile(r'(?i)assumed|midpoint|estimated|\bfee|net income|earnings|per common share data|placement|exercise|warrant|redeem|redemption|purchase|discount|commission')
LAB = re.compile(r'(?i)(?:initial )?public offering price(?:\s*\(\d\))?[ .:\-_]*\$\s?' + NUMX + r'\s+\$\s?' + NUMX)
def f(x):
    try: return float(x.replace(',', ''))
    except Exception: return None
def find_price_new(t):
    h = t[:40000]
    rows = []
    for m in ROW.finditer(h):
        a, b, c = f(m.group(2)), f(m.group(3)), f(m.group(4))
        if None in (a, b, c) or a < 0.1: continue
        if abs(a - b - c) <= max(0.011, 0.003 * a) and m.group(1).lower() != 'warrant':
            rows.append((m.group(1).lower(), a))
    for kind, a in rows:
        if kind != 'unit': return a
    for m in LAB.finditer(h):
        a, tot = f(m.group(1)), f(m.group(2))
        if a and tot and a >= 0.1 and tot >= a: return a
    if rows: return rows[0][1]
    c = h[:15000]
    for pat in (r'(?i)(?:initial public offering|public offering|offering) price (?:per (?:share|unit|ads|adr|american depositary share) )?(?:of|is|will be|was)[^$]{0,40}?' + PR,
                r'(?i)each unit (?:that we are offering )?has (?:an offering )?price of ' + PR,
                r'(?i)units (?:are|is) being offered at a price of ' + PR,
                r'(?i)' + PR + r'\s+per\s+(?:share|unit|ads|adr|american depositary share)\b'):
        for m in re.finditer(pat, c[:6000] if r'per\s+(?:share' in pat else c):
            ctx = c[max(0, m.start() - 100):m.start()]
            if BAD2.search(ctx): continue
            p = _ok(m.group(1))
            if p and p >= 1.0: return p
    return None


def find_price(t):
    p = find_price_new(t)
    return p if p is not None else find_price_old(t)


def read_share(d_task):
    #one task per worker: the documents of its share. the task holds the path of a parquet file with deal_no, accession and the path of each document; the worker writes its rows (the values read from the text, doc_read False when the file could not be read) to its own part file
    df_j = pd.read_parquet(d_task['p_in'])
    l_rows = []
    for v_deal, v_doc in zip(df_j['deal_no'], df_j['p_doc']):
        try:
            d_row = parse(v_doc)
            d_row['doc_read'] = True
        except Exception:
            d_row = {'doc_read': False}
        d_row['deal_no'] = v_deal
        l_rows.append(d_row)
    pd.DataFrame(l_rows).to_parquet(d_task['p_out'], index=False)
    return len(l_rows)
