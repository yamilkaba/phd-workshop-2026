# %%
import duckdb
import numpy as np
import pandas as pd
from pathlib import Path

# %%
#Step 4 table: the final table of Step 3 with the prospectus of each deal. the values the reader found (Ex1_06_prospectus_read) are replaced by the hand fix list, compared with SDC, and the recommended date is chosen
#folders: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download
p_sdc=p_path / 'sdc'
p_secinfo=p_path / 'crsp_a_stock' / 'stksecurityinfohist.parquet'
p_fix=p_sdc / 'ipo_prospectus_fixes.parquet' #hand fix list: one row per deal and item, the value that replaces what the reader found. made by hand (values read from the documents by Haiku agents and from the covers), it is an input, not rebuilt by this program
v_tol_price=0.0105 #a price is the same as the sdc price when it differs by less than this (one cent and rounding)
v_window=3 #days: two dates are the same date when they are this close
v_crsp_start=pd.Timestamp('1972-12-14') #where CRSP's Nasdaq data starts, not a first trade: it never counts as a date
p_ccm=p_path / 'crsp_a_ccm' / 'ccmxpf_lnkhist.parquet' #CRSP-Compustat link table
l_good_links=['LC', 'LU', 'LX'] #link types kept when a permno has more than one gvkey
d_link_rank={'LC': 1, 'LU': 2, 'LX': 3} #link type rank: LC is better than LU, LU better than LX (decided 2026-11-10 by the user)
v_crsp_far=30 #days: the closest-to-CRSP step is used only when the closest date is this near the CRSP first trading date (30 days, as in the other date checks). farther away the CRSP date belongs to an earlier listing of the permno (for example the first listing of a company that converts, Atlantic Coast Financial 2004 and 2011) and says nothing about this deal (decided 2026-11-09)

# %%
#the final table of step 3, the values of the reader, and the sdc values the prospectus is compared with
df_step3 = pd.read_parquet(p_sdc / f"sdc_ipo_step3_{v_outputfile}.parquet")
df_read1 = pd.read_parquet(p_sdc / f"sdc_ipo_prospectus_read_{v_outputfile}.parquet")
df_fix1 = pd.read_parquet(p_fix)
d_sdc_cols = {'TR_NISdcDealNumber': 'deal_no', 'TR_NIOfferPrice': 'sdc_offer_price', 'TR_NITotalSharesOfferedThisMkt': 'sdc_shares_this_market', 'TR_NITotalShrsOfferedAllMkts': 'sdc_shares_all_markets',
              'TR_NIPrimarySharesOfferedThisMkt': 'sdc_primary_this_market', 'TR_NISecondarySharesOfferedThisMkt': 'sdc_secondary_this_market', 'TR_NIPrimaryShrsOfferedAllMkts': 'sdc_primary_all_markets', 'TR_NISecondaryShrsOfferedAllMkts': 'sdc_secondary_all_markets'}
df_sdc1 = pd.read_parquet(p_sdc / f"sdc_ipo_step0_{v_outputfile}.parquet", columns=list(d_sdc_cols)).rename(columns=d_sdc_cols)
df_pro1 = df_step3.merge(df_sdc1, on='deal_no', how='left').merge(df_read1, on='deal_no', how='left')
print(f"deals {len(df_pro1)} | with a filing {df_pro1['prospectus_accession'].notna().sum()} | read {int(df_pro1['doc_read'].fillna(False).sum())} | fix list rows {len(df_fix1)} for {df_fix1['deal_no'].nunique()} deals")

# %%
#the hand fix list is applied last: for a deal and item on the list the fix value replaces what the reader found, whatever the reader found. the value 'blank' means the item is empty in the document
#item on the list -> (column of the reader, column of the table, type)
d_items = {'offer_price': ('doc_price', 'prospectus_price', 'float'), 'total_shares': ('doc_total_shares', 'prospectus_total_shares', 'int'), 'primary_shares': ('doc_primary_shares', 'prospectus_primary_shares', 'int'),
           'secondary_shares': ('doc_secondary_shares', 'prospectus_secondary_shares', 'int'), 'symbol': ('doc_symbol_cover', 'prospectus_symbol', 'text'), 'prospectus_date': ('doc_prospectus_date', 'prospectus_date', 'date')}
df_pro2 = df_pro1.copy()
for v_item, (v_in, v_out, v_type) in d_items.items():
    s_fix = df_fix1[df_fix1['field'] == v_item].set_index('deal_no')['fix_value']
    s_new = df_pro2['deal_no'].map(s_fix)
    s_new = s_new.where(s_new != 'blank')
    if v_type == 'float':
        s_new = pd.to_numeric(s_new, errors='coerce')
    elif v_type == 'int':
        s_new = pd.to_numeric(s_new, errors='coerce').round().astype('Int64')
    elif v_type == 'date':
        s_new = pd.to_datetime(s_new)
    else:
        s_new = s_new.astype('string')
    s_on_list = df_pro2['deal_no'].isin(s_fix.index)
    df_pro2[v_out] = df_pro2[v_in].where(~s_on_list, s_new)
df_pro2['prospectus_exchange'] = df_pro2['doc_exchange']
df_pro2 = df_pro2.rename(columns={'doc_us_shares': 'prospectus_us_shares', 'doc_intl_shares': 'prospectus_intl_shares', 'doc_cusip': 'prospectus_cusip'})
df_pro2 = df_pro2.drop(columns=[v_c for v_c in df_pro2.columns if v_c.startswith('doc_')])
s_fields = df_fix1.groupby('deal_no')['field'].apply(lambda s: '; '.join(sorted(s)))
df_pro2['prospectus_fixed_fields'] = df_pro2['deal_no'].map(s_fields).astype('string')
print(f"deals with a fixed item {df_pro2['prospectus_fixed_fields'].notna().sum()} | items {df_pro2['prospectus_fixed_fields'].dropna().str.count(';').add(1).sum()}")

# %%
#compare with sdc. the prospectus is an independent source, so a difference stays in the table. an agreement is empty (not True or False) when one of the two values is missing
df_pro3 = df_pro2.copy()
df_pro3['prospectus_date_minus_sdc_ipo_days'] = (df_pro3['prospectus_date'] - pd.to_datetime(df_pro3['sdc_ipo_date'])).dt.days
v_ok = df_pro3['prospectus_price'].notna() & df_pro3['sdc_offer_price'].notna()
df_pro3['price_agrees_sdc'] = ((df_pro3['prospectus_price'] - df_pro3['sdc_offer_price']).abs() <= v_tol_price).where(v_ok)
v_ok = df_pro3['prospectus_total_shares'].notna() & df_pro3['sdc_shares_all_markets'].notna()
df_pro3['shares_all_agrees_sdc'] = (df_pro3['prospectus_total_shares'].astype('float') == df_pro3['sdc_shares_all_markets'].astype('float')).where(v_ok)
v_ok = df_pro3['prospectus_total_shares'].notna() & df_pro3['sdc_shares_this_market'].notna()
df_pro3['shares_this_agrees_sdc'] = (df_pro3['prospectus_total_shares'].astype('float') == df_pro3['sdc_shares_this_market'].astype('float')).where(v_ok)
for v_in, v_a, v_b, v_out in [('prospectus_primary_shares', 'sdc_primary_all_markets', 'sdc_primary_this_market', 'primary_agrees_sdc'), ('prospectus_secondary_shares', 'sdc_secondary_all_markets', 'sdc_secondary_this_market', 'secondary_agrees_sdc')]:
    v_ok = df_pro3[v_in].notna() & (df_pro3[v_a].notna() | df_pro3[v_b].notna())
    df_pro3[v_out] = ((df_pro3[v_in].astype('float') == df_pro3[v_a].astype('float')) | (df_pro3[v_in].astype('float') == df_pro3[v_b].astype('float'))).where(v_ok)
v_ok = df_pro3['prospectus_symbol'].notna() & df_pro3['sdc_ticker'].notna()
df_pro3['ticker_agrees_sdc'] = (df_pro3['prospectus_symbol'].str.upper() == df_pro3['sdc_ticker'].str.upper()).where(v_ok)
for v_c in [v_c for v_c in df_pro3.columns if v_c.endswith('_agrees_sdc')]:
    df_pro3[v_c] = df_pro3[v_c].astype('boolean')
    print(f"{v_c}: compared {df_pro3[v_c].notna().sum()} | agree {(df_pro3[v_c] == True).sum()} | differ {(df_pro3[v_c] == False).sum()}")

# %%
#first trading date of a permno: the start date of its earliest record in stksecurityinfohist (the same definition as Step 2). one for the CRSP permno of step 1, one for the Ritter permno and one for the recommended permno
df_first1 = duckdb.query(f"SELECT permno, MIN(secinfostartdt)::DATE AS first_trading_date FROM read_parquet('{p_secinfo}') GROUP BY permno").df()
df_pro4 = df_pro3.copy()
for v_p, v_out in [('crsp_permno', 'crsp_first_trading_date'), ('ritter_permno', 'ritter_first_trading_date'), ('recommended_permno', 'recommended_first_trading_date')]:
    df_pro4[v_out] = pd.to_datetime(df_pro4[v_p].astype('Int64').map(df_first1.set_index('permno')['first_trading_date']))
#the first trading date of the CRSP permno is the one of Step 2 (the table of one deal per permno), which has the dates given by hand on the fix list (a permno whose earliest record belongs to an earlier listing: Atlantic Coast Financial). the recommended permno has the same date when it is the CRSP permno
df_s2 = pd.read_parquet(p_sdc / f"sdc_ipo_step2_{v_outputfile}.parquet", columns=['deal_no', 'permno', 'crsp_first_trading_date']).dropna(subset=['permno']).drop_duplicates('deal_no')
df_pro4['crsp_first_trading_date'] = pd.to_datetime(df_pro4['deal_no'].map(df_s2.set_index('deal_no')['crsp_first_trading_date']))
v_same = df_pro4['recommended_permno'].notna() & (df_pro4['recommended_permno'] == df_pro4['crsp_permno'])
df_pro4['recommended_first_trading_date'] = df_pro4['crsp_first_trading_date'].where(v_same, df_pro4['recommended_first_trading_date'])

# %%
#recommended date (decided 2026-11-08): one of the SDC, Ritter and prospectus dates, and two sources must agree (within v_window days). order:
#1. two of the three agree: that date (the SDC date when SDC is one of them, the prospectus date when only Ritter and the prospectus agree)
#2. no two of the three agree (or the others are not there): the CRSP first trading date counts as the second source: a date within v_window days of it, taking SDC first, then the prospectus, then Ritter
#3. everything differs: the date closest to the CRSP first trading date (SDC on a tie), only when that date is within v_crsp_far days (30) of the CRSP date
#4. CRSP has no usable date, or it is more than v_crsp_far days (30) from every date: the SDC date
df_pro5 = df_pro4.copy()
s_crsp = df_pro5['crsp_first_trading_date'].where(df_pro5['crsp_first_trading_date'] != v_crsp_start)
d_dates = {'sdc': pd.to_datetime(df_pro5['sdc_ipo_date']), 'ritter': pd.to_datetime(df_pro5['ritter_ipo_date']), 'prospectus': df_pro5['prospectus_date']}
near = lambda a, b: ((a - b).dt.days.abs() <= v_window) & a.notna() & b.notna()
s_rec = pd.Series(pd.NaT, index=df_pro5.index, dtype='datetime64[ns]')
v_m = near(d_dates['sdc'], d_dates['ritter']) | near(d_dates['sdc'], d_dates['prospectus'])
s_rec = s_rec.where(s_rec.notna(), d_dates['sdc'].where(v_m))
v_m = s_rec.isna() & near(d_dates['ritter'], d_dates['prospectus'])
s_rec = s_rec.where(s_rec.notna(), d_dates['prospectus'].where(v_m))
v_nobody = s_rec.isna()
s_crsp_vote = pd.Series(False, index=df_pro5.index)
for v_k in ['sdc', 'prospectus', 'ritter']:
    v_m = v_nobody & s_rec.isna() & near(d_dates[v_k], s_crsp)
    s_rec = s_rec.where(s_rec.notna(), d_dates[v_k].where(v_m))
    s_crsp_vote = s_crsp_vote | v_m
df_gap = pd.DataFrame({v_k: (d_dates[v_k] - s_crsp).dt.days.abs() for v_k in ['sdc', 'prospectus', 'ritter']})
s_best = df_gap.fillna(1e9).idxmin(axis=1)
v_ok = s_rec.isna() & df_gap.notna().any(axis=1) & (df_gap.min(axis=1) <= v_crsp_far)
for v_k in ['sdc', 'prospectus', 'ritter']:
    s_rec = s_rec.where(s_rec.notna(), d_dates[v_k].where(v_ok & (s_best == v_k)))
s_rec = s_rec.where(s_rec.notna(), d_dates['sdc'])
d_agree = {v_k: near(d_dates[v_k], s_rec) for v_k in d_dates}
df_pro5['recommended_date'] = s_rec
df_pro5['recommended_date_sources'] = pd.Series(['+'.join([v_k for v_k in ['sdc', 'ritter', 'prospectus'] if d_agree[v_k][v_i]] + (['crsp'] if s_crsp_vote[v_i] else [])) or None for v_i in df_pro5.index], index=df_pro5.index).astype('string')
df_pro5['crsp_matches_recommended_date'] = near(s_rec, s_crsp).astype('boolean')
print(df_pro5['recommended_date_sources'].value_counts(dropna=False).to_string())
print(f"recommended date differs from the sdc date in {(df_pro5['recommended_date'] != d_dates['sdc']).sum()} deals")

# %%
#gvkey of each deal from the CRSP-Compustat link table, for the recommended permno. an IPO is close to the start of its link, so the date of the deal may be outside the link range: the range is not required, only used to choose
#1. one gvkey for the permno: that one. 2. more than one: the gvkeys with a link type in LC, LU, LX. 3. still more than one: the gvkey whose link range is closest to the recommended date (0 days when the date is inside the range); two gvkeys equally close: the better link type (LC, then LU, then LX). a tie or no good link type leaves the gvkey empty, so a permno never has two gvkeys
df_lnk1 = pd.read_parquet(p_ccm)
df_lnk1 = df_lnk1[df_lnk1['lpermno'].notna()].copy()
df_lnk1['lpermno'] = df_lnk1['lpermno'].astype('int64')
df_lnk1['linkenddt_use'] = df_lnk1['linkenddt'].fillna(pd.Timestamp('2200-01-01'))
df_gv1 = df_pro5[['deal_no', 'recommended_permno', 'recommended_date']].dropna(subset=['recommended_permno']).copy()
df_gv1['recommended_permno'] = df_gv1['recommended_permno'].astype('int64')
df_gv2 = df_gv1.merge(df_lnk1, left_on='recommended_permno', right_on='lpermno')
df_gv2['gap_days'] = np.where(df_gv2['recommended_date'] < df_gv2['linkdt'], (df_gv2['linkdt'] - df_gv2['recommended_date']).dt.days, np.where(df_gv2['recommended_date'] > df_gv2['linkenddt_use'], (df_gv2['recommended_date'] - df_gv2['linkenddt_use']).dt.days, 0))
s_n_all = df_gv2.groupby('deal_no')['gvkey'].nunique()
df_gv3 = df_gv2[df_gv2['deal_no'].map(s_n_all) == 1].drop_duplicates('deal_no').assign(gvkey_how='only gvkey')
df_gv4 = df_gv2[df_gv2['deal_no'].map(s_n_all) > 1]
df_gv5 = df_gv4[df_gv4['linktype'].isin(l_good_links)]
s_n_good = df_gv5.groupby('deal_no')['gvkey'].nunique()
df_gv6 = df_gv5[df_gv5['deal_no'].map(s_n_good) == 1].drop_duplicates('deal_no').assign(gvkey_how='link type LC/LU/LX')
df_gv7 = df_gv5[df_gv5['deal_no'].map(s_n_good) > 1].copy()
df_gv7['rk_linktype'] = df_gv7['linktype'].map(d_link_rank)
df_gv7 = df_gv7.sort_values(['deal_no', 'gap_days', 'rk_linktype', 'gvkey'])
s_gap = df_gv7.drop_duplicates(['deal_no', 'gvkey']).reset_index(drop=True) #closest link range of each gvkey; the better link type if two rows are equally close
s_tie = s_gap.groupby('deal_no').apply(lambda g: ((g['gap_days'] == g['gap_days'].min()) & (g['rk_linktype'] == g.loc[g['gap_days'] == g['gap_days'].min(), 'rk_linktype'].min())).sum() > 1)
df_gv8 = s_gap.drop_duplicates('deal_no')
df_gv8 = df_gv8[~df_gv8['deal_no'].map(s_tie)].assign(gvkey_how='closest link range')
df_gv9 = pd.concat([df_gv3, df_gv6, df_gv8])[['deal_no', 'gvkey', 'gvkey_how', 'linktype', 'linkdt', 'linkenddt', 'gap_days']].rename(columns={'linktype': 'gvkey_linktype', 'linkdt': 'gvkey_linkdt', 'linkenddt': 'gvkey_linkenddt', 'gap_days': 'gvkey_gap_days'})
df_gv9['gvkey_n_candidates'] = df_gv9['deal_no'].map(s_n_all)
df_pro6 = df_pro5.merge(df_gv9, on='deal_no', how='left')
df_pro6['gvkey_how'] = df_pro6['gvkey_how'].fillna(pd.Series(np.where(df_pro6['deal_no'].isin(df_gv2['deal_no']), np.where(df_pro6['deal_no'].isin(df_gv4['deal_no']) & ~df_pro6['deal_no'].isin(df_gv5['deal_no']), 'no good link type', 'tie in the link range'), np.where(df_pro6['recommended_permno'].notna(), 'permno not in the link table', 'no permno')), index=df_pro6.index))
df_pro6['gvkey_how'] = df_pro6['gvkey_how'].astype('string')
print(df_pro6['gvkey_how'].value_counts().to_string())
print(f"deals with a gvkey {df_pro6['gvkey'].notna().sum()} | permnos with more than one gvkey {(df_pro6.dropna(subset=['gvkey']).groupby('recommended_permno')['gvkey'].nunique() > 1).sum()} | gvkeys on more than one permno {(df_pro6.dropna(subset=['gvkey']).groupby('gvkey')['recommended_permno'].nunique() > 1).sum()}")

# %
#output: the step 4 table
df_pro6.to_parquet(p_sdc / f"sdc_ipo_step4_{v_outputfile}.parquet", index=False)
print(f"saved {len(df_pro6)} deals, {df_pro6.shape[1]} columns")
