# %%
import os
import shutil
import sys
import time
import pandas as pd
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

# %%
#this program reads the prospectus of each deal (the documents downloaded by Ex1_05_sec_prospectus_download) and takes out of the text: offer price, shares (total, primary, secondary, US and international), symbol, exchange, prospectus date and CUSIP. the values are what the reader finds, the hand fixes are applied in Ex1_07_prospectus_table
#folders: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download
p_sdc=p_path / 'sdc'
p_sec=p_path / 'sec'
p_doc=p_sec / 'documents' #documents of the first search: deal_no_accession.htm
p_doc_extra=p_sec / 'documents_extra' #documents of the filings found for the deals that had none
p_work=p_sec / 'read_work' #temporary files of the workers
v_nproc = os.cpu_count() #number of worker processes

# %%
#Ex1_06_prospectus_read_worker.py (same folder as this notebook) holds the function the worker processes import
sys.path.append(str(Path.cwd()))
import Ex1_06_prospectus_read_worker

# %%
#the filing of each deal (Ex1_05_sec_prospectus_download: one filing per deal, the first run plus the filings found for the deals that had none) and the path of its document on disk
if __name__ == '__main__':
    df_fil1 = pd.read_parquet(p_sec / 'sec_deal_filing_all.parquet', columns=['deal_no', 'accession', 'form', 'filing_date', 'cik', 'file_number', 'sec_name', 'former_names', 'sec_tickers', 'url'])
    df_fil1 = df_fil1.rename(columns={'accession': 'prospectus_accession', 'form': 'prospectus_form', 'filing_date': 'prospectus_filing_date', 'cik': 'sec_cik', 'file_number': 'sec_file_number', 'sec_name': 'sec_company_name', 'former_names': 'sec_former_names', 'url': 'prospectus_url'})
    df_fil1['p_doc'] = [str(p_doc / f"{v_d}_{v_a}.htm") if (p_doc / f"{v_d}_{v_a}.htm").exists() else str(p_doc_extra / f"{v_d}_{v_a}.htm") for v_d, v_a in zip(df_fil1['deal_no'], df_fil1['prospectus_accession'])]
    df_fil1['f_on_disk'] = [Path(v_p).exists() for v_p in df_fil1['p_doc']]
    print(f"deals with a filing {len(df_fil1)} | document on disk {df_fil1['f_on_disk'].sum()} | not on disk {(~df_fil1['f_on_disk']).sum()}")

# %%
#the smallest slice is one document. the size of each file is known, so the documents are sorted from the largest to the smallest and dealt out one by one: the largest to worker 1, ... the n-th to worker n, then the next to worker n again and back to worker 1 (1 to n, n to 1), so every worker gets about the same load
#each worker reads its documents (the first 60,000 characters of each) and writes its rows to its own part file
if __name__ == '__main__':
    if p_work.exists():
        shutil.rmtree(p_work)
    p_work.mkdir(parents=True)
    df_jobs = df_fil1[df_fil1['f_on_disk']][['deal_no', 'p_doc']].copy()
    df_jobs['size'] = [os.path.getsize(v_p) for v_p in df_jobs['p_doc']]
    df_jobs = df_jobs.sort_values('size', ascending=False, kind='stable').reset_index(drop=True)
    s_pos = df_jobs.index % (2 * v_nproc)
    df_jobs['worker'] = s_pos.where(s_pos < v_nproc, 2 * v_nproc - 1 - s_pos)
    s_load = df_jobs.groupby('worker')['size'].sum()
    print(f"documents per worker {df_jobs.groupby('worker').size().min()} to {df_jobs.groupby('worker').size().max()} | bytes of the busiest worker {s_load.max() / s_load.mean():.3f} times the average")
    l_tasks = []
    for v_w, df_w in df_jobs.groupby('worker'):
        p_in = p_work / f"todo_{v_w}.parquet"
        df_w[['deal_no', 'p_doc']].to_parquet(p_in, index=False)
        l_tasks.append({'p_in': str(p_in), 'p_out': str(p_work / f"read_{v_w}.parquet")})
    v_t0 = time.time()
    with ProcessPoolExecutor(v_nproc) as ex:
        l_done = list(ex.map(Ex1_06_prospectus_read_worker.read_share, l_tasks))
    print(f"documents read {sum(l_done)} | {time.time() - v_t0:.0f} seconds")

# %%
#joins the part files of the workers: one row for each deal with the values the reader found (doc_read is False when the file could not be read)
if __name__ == '__main__':
    df_read1 = pd.concat([pd.read_parquet(d['p_out']) for d in l_tasks], ignore_index=True)
    for v_c in ['doc_price', 'doc_total_shares', 'doc_primary_shares', 'doc_secondary_shares', 'doc_us_shares', 'doc_intl_shares', 'doc_chars']:
        df_read1[v_c] = pd.to_numeric(df_read1[v_c], errors='coerce')
    for v_c in ['doc_total_shares', 'doc_primary_shares', 'doc_secondary_shares', 'doc_us_shares', 'doc_intl_shares', 'doc_chars']:
        df_read1[v_c] = df_read1[v_c].round().astype('Int64')
    for v_c in ['doc_symbol_cover', 'doc_exchange', 'doc_cusip']:
        df_read1[v_c] = df_read1[v_c].astype('string')
    df_read1['doc_prospectus_date'] = pd.to_datetime(df_read1['doc_prospectus_date'])
    df_read1['doc_read'] = df_read1['doc_read'].astype('boolean')
    df_read2 = df_fil1.drop(columns=['p_doc']).merge(df_read1.drop(columns=['doc_chars']), on='deal_no', how='left')
    for v_c in ['prospectus_accession', 'prospectus_form', 'sec_file_number', 'sec_company_name', 'sec_former_names', 'sec_tickers', 'prospectus_url']:
        df_read2[v_c] = df_read2[v_c].astype('string')
    df_read2.to_parquet(p_sdc / f"sdc_ipo_prospectus_read_{v_outputfile}.parquet", index=False)
    shutil.rmtree(p_work)
    print(f"deals {len(df_read2)} | read {int(df_read2['doc_read'].fillna(False).sum())}")
    for v_c in ['doc_price', 'doc_total_shares', 'doc_primary_shares', 'doc_secondary_shares', 'doc_us_shares', 'doc_symbol_cover', 'doc_exchange', 'doc_prospectus_date', 'doc_cusip']:
        print(f"{v_c} {int(df_read2[v_c].notna().sum())}")
