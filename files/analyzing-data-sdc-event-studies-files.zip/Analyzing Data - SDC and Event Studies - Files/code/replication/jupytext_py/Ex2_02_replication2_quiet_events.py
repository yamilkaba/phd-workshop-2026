# %%
import duckdb
import numpy as np
import pandas as pd
from pathlib import Path

# %%
#events for the second replication: the quiet period expiration of IPOs, "The Quiet Period Goes Out with a Bang" (Bradley, Jordan and Ritter, Journal of Finance 2003). the event is the end of the quiet period, 25 calendar days after the IPO; the event study (event_study/Ex1_02_event_study_preprocess, run name quiet, model ma, benchmark CRSP value weighted, days -2 to +2) and Ex2_03_replication2_quiet_table follow
#sample of the paper (page 4): SDC US common stock IPOs of 1996-2000 (1,611 companies in Bradley, Jordan, Ritter) and of January 2001 to mid-July 2002 (94 in the update). eliminated: "unit issues, REITs, ADRs, spinoffs, closed-end funds, reverse buyouts, banks, savings and loans, IPOs with original file range midpoints below $8, and firms with missing information from CRSP"
#folders: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download
p_sdc=p_path / 'sdc'
p_es=p_path / 'event_study'
p_secinfo=p_path / 'crsp_a_stock' / 'stksecurityinfohist.parquet'
p_stock=p_path / 'crsp_a_stock' / 'stkdlysecuritydata.parquet'
p_codes=Path(r'D:\Box\workshop\PhDWorkshop\2026\T03_EventStudy_SDC\references\crsp_code_mapping') #the user's table: share codes as the new CRSP fields (shrcd.xlsx)
l_shrcd=[10, 11] #CRSP share codes kept (decision of the user, 2026-11-10): common stock of US companies. the paper gives no share code filter: it says CRSP covers Nasdaq, AMEX and NYSE issues and excludes foreign firms listed on Nasdaq
v_quiet_days=25 #the quiet period lasts this many calendar days after the IPO; the event study takes the first trading day on or after the event date as day 0 (Bradley, Jordan, Ritter 2003: day 0 = the first trading day after the 25th calendar day). from July 2002 the quiet period is 40 days, the sample ends in mid-July 2002: 25 days for all
v_max_first_days=7 #the first CRSP price must come within this many days after the IPO date (the window of the Online Appendix of Lowry, Michaely, Volkova: -1 to +7 days)
v_min_midpoint=8.0 #IPOs with an original file range midpoint below this are eliminated
d_periods={'1996-2000': ('1996-01-01', '2000-12-31', 1611), '2001-Jul2002': ('2001-01-01', '2002-07-15', 94)} #period: first day, last day, number of IPOs in the paper

# %%
#the IPOs: our table (one deal per permno, recommended permno and date) with the SDC fields of the filters, and the SIC code of the permno at its first CRSP record
df_ipo0 = pd.read_parquet(p_sdc / f"sdc_ipo_step4_{v_outputfile}.parquet", columns=['deal_no', 'sdc_name', 'recommended_permno', 'recommended_date', 'sdc_offer_price'])
df_s0 = pd.read_parquet(p_sdc / f"sdc_ipo_step0_{v_outputfile}.parquet", columns=['TR_NISdcDealNumber', 'TR_NIIsUnitIssue', 'TR_NIIssuerREITType', 'TR_NIIsDepositaryIssue', 'TR_NIIsClosedEndFundOrTrustIssuer', 'TR_NIRelatedDealType', 'TR_NIOrigLowFilePrice', 'TR_NIOrigHighFilePrice', 'TR_NIFullHistoryLowFilePrice', 'TR_NIFullHistoryHighFilePrice', 'TR_NITotalShrsOfferedAllMkts', 'TR_NILeadManagersCode', 'TR_NICoManagerCode', 'TR_NIProceedsAmtThisMkt']).rename(columns={'TR_NISdcDealNumber': 'deal_no'})
df_crsp1 = duckdb.query(f"SELECT permno, ARG_MIN(siccd, secinfostartdt) AS siccd0 FROM read_parquet('{p_secinfo}') GROUP BY permno").df()
df_ipo1 = df_ipo0.merge(df_s0, on='deal_no', how='left')
df_ipo1 = df_ipo1[df_ipo1['recommended_permno'].notna()].copy()
df_ipo1['permno'] = df_ipo1['recommended_permno'].astype('int64')
df_ipo1 = df_ipo1.merge(df_crsp1, on='permno', how='left')
df_ipo1['recommended_date'] = pd.to_datetime(df_ipo1['recommended_date'])

# %%
#original file range: SDC original low and high filing price; when empty, the first positive value of the price history (as in the Online Appendix of Lowry, Michaely, Volkova)
for v_side in ['Low', 'High']:
    df_h = pd.to_numeric(df_ipo1[f'TR_NIFullHistory{v_side}FilePrice'].dropna().astype(str).str.split(';').explode(), errors='coerce')
    s_first = df_h[df_h > 0].groupby(level=0).first()
    df_ipo1[f'file_{v_side.lower()}'] = df_ipo1[f'TR_NIOrig{v_side}FilePrice'].where(df_ipo1[f'TR_NIOrig{v_side}FilePrice'] > 0, s_first)
df_ipo1['file_midpoint'] = (df_ipo1['file_low'] + df_ipo1['file_high']) / 2

# %%
#the filters of the paper, one step each, for each period. our fields: units = SDC unit flag; spinoffs = no field in our SDC export, not applied; reverse buyouts = related deal type with LBOIPO (a proxy); banks and S&Ls = CRSP SIC 6000 to 6099 at the first record; file range midpoint below $8 eliminated (a missing range is kept)
l_events = []
l_steps = []
for v_name, (v_first, v_last, v_pub) in d_periods.items():
    df_p = df_ipo1[(df_ipo1['recommended_date'] >= v_first) & (df_ipo1['recommended_date'] <= v_last)]
    d_n = {'period': v_name, 'our table': len(df_p)}
    df_p = df_p[df_p['TR_NIIsUnitIssue'] == False]
    d_n['no unit issues'] = len(df_p)
    df_p = df_p[df_p['TR_NIIssuerREITType'].isna()]
    d_n['no REITs'] = len(df_p)
    df_p = df_p[df_p['TR_NIIsDepositaryIssue'] == False]
    d_n['no ADRs'] = len(df_p)
    df_p = df_p[df_p['TR_NIIsClosedEndFundOrTrustIssuer'] == False]
    d_n['no closed end funds'] = len(df_p)
    df_p = df_p[~df_p['siccd0'].between(6000, 6099)]
    d_n['no banks and S&Ls (SIC 6000-6099)'] = len(df_p)
    df_p = df_p[~df_p['TR_NIRelatedDealType'].astype(str).str.contains('LBOIPO')]
    d_n['no reverse buyouts (LBOIPO)'] = len(df_p)
    df_p = df_p[~(df_p['file_midpoint'] < v_min_midpoint)]
    d_n[f'file range midpoint not below ${v_min_midpoint:.0f}'] = len(df_p)
    d_n['paper'] = v_pub
    l_steps.append(d_n)
    l_events.append(df_p.assign(period=v_name))
print(pd.DataFrame(l_steps).set_index('period').T.to_string())

# %%
#the events file of the event study: one row per IPO, the event date is the end of the quiet period (day 0 of the event study = first trading day on or after it). the filter "missing information from CRSP" is applied by the event study: an IPO without a return on every day of the window has no CAR
df_ev1 = pd.concat(l_events)
df_ev1['ipo_date'] = df_ev1['recommended_date']
#the variables of Table I of the paper. offer amount = shares offered in all markets times the offer price (millions of dollars). initial return = first CRSP closing price (absolute value) over the offer price, minus 1. managing underwriters = lead managers plus co-managers of the SDC codes. lead underwriter market share = the share of the lead in the total proceeds of the IPOs of the year in our table (full credit to each co-lead; the IPO takes the highest share among its leads); the SDC manager codes are not standardized (one bank appears under several codes), so the shares are understated
df_ev1['offer_amount_mil'] = df_ev1['TR_NITotalShrsOfferedAllMkts'] * df_ev1['sdc_offer_price'] / 1e6
#the first CRSP trading day of the IPO: the first daily row with a price on or after one day before the IPO date (not the first row of the permno in all its history: a permno can have traded for years before the IPO). an IPO whose first price is more than v_max_first_days after the IPO date has no CRSP data at the IPO and is eliminated ("missing return data from CRSP")
df_px1 = duckdb.query(f"SELECT e.deal_no, MIN(d.dlycaldt)::DATE AS first_date, ARG_MIN(d.dlyprc, d.dlycaldt) AS first_close FROM df_ev1 e JOIN read_parquet('{p_stock}') d ON d.permno = e.permno AND d.dlycaldt >= e.ipo_date - INTERVAL 1 DAY WHERE d.dlyprc IS NOT NULL GROUP BY e.deal_no").df()
df_ev1 = df_ev1.merge(df_px1, on='deal_no', how='left')
df_ev1['first_date'] = pd.to_datetime(df_ev1['first_date'])
df_far1 = df_ev1[(df_ev1['first_date'] - df_ev1['ipo_date']).dt.days > v_max_first_days]
print(f"IPOs without a CRSP price within {v_max_first_days} days after the IPO date, eliminated: {len(df_far1) + df_ev1['first_date'].isna().sum()}")
df_ev1 = df_ev1[(df_ev1['first_date'] - df_ev1['ipo_date']).dt.days <= v_max_first_days].copy()
#CRSP share codes 10 and 11 on the first trading day: the record of the permno valid on that day (stksecurityinfohist) must be common stock of a US company in the user's table
df_shr1 = pd.read_excel(p_codes / 'shrcd.xlsx')
df_shr1 = df_shr1[df_shr1['shrcd'].isin(l_shrcd)]
df_shr2 = duckdb.query(f"SELECT DISTINCT e.deal_no FROM df_ev1 e JOIN read_parquet('{p_secinfo}') s ON s.permno = e.permno AND e.first_date BETWEEN s.secinfostartdt AND COALESCE(s.secinfoenddt, TIMESTAMP '2100-01-01') JOIN df_shr1 c ON s.sharetype = c.sharetype AND s.securitytype = c.securitytype AND s.securitysubtype = c.securitysubtype AND s.usincflg = c.usincflg AND s.issuertype = c.issuertype").df()
print(f"IPOs eliminated by the CRSP share code filter (share codes {l_shrcd}) by period: {df_ev1[~df_ev1['deal_no'].isin(df_shr2['deal_no'])].groupby('period').size().to_dict()}")
df_ev1 = df_ev1[df_ev1['deal_no'].isin(df_shr2['deal_no'])].copy()
#the quiet period lasts 25 calendar days from the IPO (the paper: 'ends 25 calendar days after the IPO'; day 0 = the first trading day after it). the IPO date is the earlier of the SDC issue date and the first CRSP trading day (the SDC date is the same day as the first CRSP day for 44% of the IPOs, one day earlier for 54%). tested on Table II of the paper: this gives the numbers closest to the published ones, 26 days gives lower returns (decision of the user, 2026-11-10)
df_ev1['first_date'] = pd.to_datetime(df_ev1['first_date'])
df_ev1['event_date'] = df_ev1[['ipo_date', 'first_date']].min(axis=1) + pd.Timedelta(days=v_quiet_days)
df_ev1 = df_ev1[df_ev1['first_date'].notna()].copy()
df_ev1['initial_return_pct'] = 100 * (df_ev1['first_close'].abs() / df_ev1['sdc_offer_price'] - 1)
l_split = lambda v_s: [v_x.strip() for v_x in str(v_s).split(';') if v_x.strip() not in ['', 'nan', 'None', '<NA>']]
df_ev1['n_managers'] = df_ev1['TR_NILeadManagersCode'].map(lambda v_s: len(l_split(v_s))) + df_ev1['TR_NICoManagerCode'].map(lambda v_s: len(l_split(v_s)))
df_all1 = df_ipo1[['deal_no', 'recommended_date', 'TR_NILeadManagersCode', 'TR_NIProceedsAmtThisMkt']].copy()
df_all1['year'] = df_all1['recommended_date'].dt.year
df_lead1 = df_all1.assign(lead=df_all1['TR_NILeadManagersCode'].map(l_split)).explode('lead').dropna(subset=['lead'])
s_lead_share = df_lead1.groupby(['year', 'lead'])['TR_NIProceedsAmtThisMkt'].sum() / df_all1.groupby('year')['TR_NIProceedsAmtThisMkt'].sum()
df_lead2 = df_lead1[df_lead1['deal_no'].isin(df_ev1['deal_no'])].copy()
df_lead2['share'] = [100 * s_lead_share[(v_y, v_l)] for v_y, v_l in zip(df_lead2['year'], df_lead2['lead'])]
df_ev1 = df_ev1.merge(df_lead2.groupby('deal_no')['share'].max().rename('lead_share_pct').reset_index(), on='deal_no', how='left')
df_ev2 = df_ev1[['permno', 'event_date', 'deal_no', 'period', 'ipo_date', 'offer_amount_mil', 'initial_return_pct', 'n_managers', 'lead_share_pct']]
p_es.mkdir(parents=True, exist_ok=True)
df_ev2.to_parquet(p_es / 'events_quiet.parquet', index=False)
print(f"events {len(df_ev2)} | permnos {df_ev2['permno'].nunique()} | saved {p_es / 'events_quiet.parquet'}")
