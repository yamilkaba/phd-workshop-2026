# %%
import duckdb
import numpy as np
import pandas as pd
from pathlib import Path

# %%
#replication of Tables I and II of Bradley, Jordan and Ritter (2003), "The Quiet Period Goes Out with a Bang", Journal of Finance 58(1): descriptive statistics of the IPOs (Table I) and the event study at the end of the quiet period (Table II). the daily table comes from the event study (event_study/Ex1_02_event_study_preprocess, run name quiet, model ma, days -5 to +119, events made by Ex2_02_replication2_quiet_events)
#abnormal return = return minus the market return. the paper uses the Nasdaq Composite; our index file has the CRSP value weighted index (NYSE, AMEX, Nasdaq), the paper says other CRSP indices do not change its conclusions (note 6)
#t-statistic as in the paper (note 7): time-series portfolio approach with a 100 day estimation period that starts on day +20. the portfolio is the average abnormal return of the IPOs on each event day; its standard deviation over the days +20 to +119 is the single variance of the portfolio, t = average abnormal return / that standard deviation (times the square root of the number of days for a window)
#generalized sign z: (positive returns - n * p) / square root(n * p * (1 - p)), p = share of positive returns in the estimation period (for a window, of the estimation period sums of the same length)
#folders: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
p_es=p_path / 'event_study'
v_run_name='quiet'
v_period='1996-2000' #the sample of the paper
p_pub1=Path(r'D:\Box\workshop\PhDWorkshop\2026\T03_EventStudy_SDC\guides\Quiet period JF 2003 Table I as published.csv')
p_pub2=Path(r'D:\Box\workshop\PhDWorkshop\2026\T03_EventStudy_SDC\guides\Quiet period JF 2003 Table II as published.csv')
l_days=list(range(-5, 6)) #days of Panel A
l_windows=[(-2, 2), (-2, -1), (0, 2)] #windows of Panel B
v_est_first=20 #estimation period of the variance: days +20 to +119 (100 days)
v_est_last=119

# %%
#the IPOs of the paper's sample and their daily abnormal returns (in percent), one column per event day
df_model1 = pd.read_parquet(p_es / f"es_{v_run_name}_model.parquet", columns=['event_id', 'permno', 'status', 'deal_no', 'period', 'offer_amount_mil', 'initial_return_pct', 'n_managers', 'lead_share_pct'])
df_model2 = df_model1[df_model1['period'] == v_period]
df_ar1 = pd.read_parquet(p_es / f"es_{v_run_name}_daily.parquet", columns=['event_id', 'day', 'abnormal_return'])
df_ar2 = df_ar1[df_ar1['event_id'].isin(df_model2['event_id'])].pivot(index='event_id', columns='day', values='abnormal_return') * 100
print(f"IPOs of {v_period}: {len(df_model2)} | with daily returns {len(df_ar2)}")

# %%
#Table I: descriptive statistics of the IPOs
l_rows = []
for v_var in ['offer_amount_mil', 'initial_return_pct', 'n_managers', 'lead_share_pct']:
    s_v = df_model2[v_var].dropna()
    l_rows.append({'variable': v_var, 'n': len(s_v), 'mean': s_v.mean(), 'std': s_v.std(), 'min': s_v.min(), 'max': s_v.max()})
df_t1 = pd.DataFrame(l_rows).merge(pd.read_csv(p_pub1).drop(columns=['source']), on='variable', how='left')
l_cols1 = ['n', 'mean', 'std', 'min', 'max']
for v_c in l_cols1:
    df_t1[f'diff_{v_c}'] = df_t1[v_c] - df_t1[f'pub_{v_c}']
df_t1.to_parquet(p_path / 'sdc' / 'quiet_jf2003_table1_20261104.parquet', index=False)
print('Table I: ours, published, difference')
print(df_t1[['variable'] + [v_x for v_c in l_cols1 for v_x in (v_c, f'pub_{v_c}', f'diff_{v_c}')]].round(2).to_string(index=False))

# %%
#Table II: the variance of the portfolio and the share of positive returns in the estimation period
l_est = list(range(v_est_first, v_est_last + 1))
df_est1 = df_ar2[[v_d for v_d in l_est if v_d in df_ar2.columns]]
v_sigma = df_est1.mean().std() #standard deviation of the portfolio average over the estimation days
print(f"estimation period: {df_est1.shape[1]} days | standard deviation of the portfolio average abnormal return {v_sigma:.4f}%")
v_p_day = (df_est1.stack() > 0).mean()

def stats_row(s_x, v_len, v_p, v_label):
    v_n = s_x.notna().sum()
    v_pos = (s_x > 0).sum()
    v_neg = (s_x < 0).sum()
    return {'row': v_label, 'avg_pct': s_x.mean(), 't': s_x.mean() / (v_sigma * np.sqrt(v_len)), 'n': v_n, 'median_pct': s_x.median(), 'pos_neg': v_pos / v_neg, 'gen_sign_z': (v_pos - v_n * v_p) / np.sqrt(v_n * v_p * (1 - v_p))}

l_a = [dict(stats_row(df_ar2[v_d], 1, v_p_day, str(v_d)), panel='A') for v_d in l_days]
l_b = []
for v_s, v_e in l_windows:
    s_cmar = df_ar2[list(range(v_s, v_e + 1))].sum(axis=1, min_count=v_e - v_s + 1)
    v_len = v_e - v_s + 1
    df_roll = pd.concat([df_est1.iloc[:, v_i:v_i + v_len].sum(axis=1, min_count=v_len) for v_i in range(df_est1.shape[1] - v_len + 1)])
    v_p_win = (df_roll.dropna() > 0).mean()
    l_b.append(dict(stats_row(s_cmar, v_len, v_p_win, f"({v_s:+d},{v_e:+d})".replace('(+0', '(0')), panel='B'))
df_t2 = pd.DataFrame(l_a + l_b)
df_pub2 = pd.read_csv(p_pub2).drop(columns=['source'])
df_pub2['row'] = df_pub2['row'].astype(str)
df_t2 = df_t2.merge(df_pub2, on=['panel', 'row'], how='left')
l_cols2 = ['avg_pct', 't', 'n', 'median_pct', 'pos_neg', 'gen_sign_z']
for v_c in l_cols2:
    df_t2[f'diff_{v_c}'] = df_t2[v_c] - df_t2[f'pub_{v_c}']
df_t2.to_parquet(p_path / 'sdc' / 'quiet_jf2003_table2_20261104.parquet', index=False)
for v_panel, v_title in [('A', 'Table II, Panel A: market-adjusted returns by day. ours, published, difference'), ('B', 'Table II, Panel B: cumulative market-adjusted returns. ours, published, difference')]:
    print(v_title)
    print(df_t2[df_t2['panel'] == v_panel][['row'] + [v_x for v_c in l_cols2 for v_x in (v_c, f'pub_{v_c}', f'diff_{v_c}')]].round(2).to_string(index=False))
df_a = df_t2[df_t2['panel'] == 'A']
df_b = df_t2[df_t2['panel'] == 'B']
print(f"Panel A days with the average within 0.25 points of the published one: {(df_a['diff_avg_pct'].abs() <= 0.25).sum()} of {len(df_a)} | Panel B windows: {(df_b['diff_avg_pct'].abs() <= 0.25).sum()} of {len(df_b)}")
