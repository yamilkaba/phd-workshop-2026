# %%
import duckdb
import numpy as np
import pandas as pd
from pathlib import Path

# %%
#replication of Table 1 of Lowry, Michaely and Volkova (2017), "Initial Public Offerings: A synthesis of the literature and directions for future research" (Foundations and Trends in Finance, SSRN 2912354): mean IPO initial returns and average proceeds by year, 1973-2016. the sample steps are the ones of their Online Appendix (guides/Lowry Michaely Volkova 2017 - Online Appendix ...pdf), applied to OUR IPO table (Step 4: recommended permno and recommended date) instead of their own SDC and CRSP matching
#folders: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download
p_sdc=p_path / 'sdc'
p_stock=p_path / 'crsp_a_stock' / 'stkdlysecuritydata.parquet'
p_secinfo=p_path / 'crsp_a_stock' / 'stksecurityinfohist.parquet'
p_codes=Path(r'D:\Box\workshop\PhDWorkshop\2026\T03_EventStudy_SDC\references\crsp_code_mapping') #the user's tables: share codes and exchange codes as the new CRSP fields (shrcd.xlsx, exchcd.xlsx)
l_shrcd=list(range(10, 20)) #share codes of this paper
l_exchcd=[1, 2, 3] #exchange codes of this paper: NYSE, AMEX, Nasdaq (primary exchange N, A, Q with conditional type RW and trading status A)
p_pub=Path(r'D:\Box\workshop\PhDWorkshop\2026\T03_EventStudy_SDC\guides\LMV 2017 Table 1 as published.csv') #the table of the paper, typed from the PDF
p_gdp=p_path / 'gdpdef' / 'GDPDEF.csv' #quarterly GDP deflator from FRED (series GDPDEF, downloaded 2026-11-10 from fred.stlouisfed.org/graph/fredgraph.csv?id=GDPDEF). if the file is not there the real proceeds are not calculated
v_min_price=5.0 #offer price below this is dropped (penny stocks)
l_ex_types=['Units', 'Limited Partnership Interest', 'Master Limited Partnership Common', 'Shares Of Beneficial Interest', 'Limited Liability Company Interest', 'Stock Unit', 'Trust Units', 'Beneficial Interests'] #security types dropped (the list of the appendix, in the names of our SDC export: Units, Ltd Prtnr Int, MLP-Common Shs, Shs Benficl Int, Ltd Liab Int, Stock Unit, Trust Units, Beneficial Ints)
v_days_before=1 #the first CRSP date must be no earlier than this many days before the issue date
v_days_after=7 #and no later than this many days after it

# %%
#the deals: our table (one deal per permno, recommended permno and date) with the SDC fields the sample steps use
df_ipo0 = pd.read_parquet(p_sdc / f"sdc_ipo_step4_{v_outputfile}.parquet", columns=['deal_no', 'sdc_name', 'recommended_permno', 'recommended_date', 'sdc_ipo_date', 'sdc_offer_price'])
df_s0 = pd.read_parquet(p_sdc / f"sdc_ipo_step0_{v_outputfile}.parquet", columns=['TR_NISdcDealNumber', 'TR_NISecurityTypeThisMkt', 'TR_NIIssuerREITType', 'TR_NIIsUnitIssue', 'TR_NIIsDepositaryIssue', 'TR_NIIsClosedEndFundOrTrustIssuer', 'TR_NIProceedsAmtAllMkts', 'TR_NIProceedsAmtThisMkt']).rename(columns={'TR_NISdcDealNumber': 'deal_no'})
df_ipo1 = df_ipo0.merge(df_s0, on='deal_no', how='left')
d_steps = {}
d_steps['deals of our table (Step 0 already drops the non IPO flags and the non US nations)'] = len(df_ipo1)

# %%
#sample steps of the appendix, in their order. every step prints how many deals are left
df_ipo2 = df_ipo1[~df_ipo1['TR_NISecurityTypeThisMkt'].isin(l_ex_types)].copy()
d_steps['common shares: security types of units, partnerships and trusts dropped'] = len(df_ipo2)
df_ipo2 = df_ipo2[df_ipo2['TR_NIIssuerREITType'].isna()]
d_steps['REITs dropped'] = len(df_ipo2)
df_ipo2 = df_ipo2[df_ipo2['TR_NIIsDepositaryIssue'] == False]
d_steps['ADRs dropped'] = len(df_ipo2)
df_ipo2 = df_ipo2[df_ipo2['TR_NIIsClosedEndFundOrTrustIssuer'] == False]
d_steps['closed end funds dropped'] = len(df_ipo2)
df_ipo2 = df_ipo2[df_ipo2['TR_NIIsUnitIssue'] == False]
d_steps['unit offerings dropped'] = len(df_ipo2)
df_ipo2 = df_ipo2[df_ipo2['sdc_offer_price'] >= v_min_price]
d_steps[f'offer price below ${v_min_price:.0f} dropped'] = len(df_ipo2)
df_ipo2 = df_ipo2[df_ipo2['recommended_permno'].notna()].copy()
d_steps['deals with a recommended permno'] = len(df_ipo2)

# %%
#CRSP, as in the appendix: only daily rows of common shares on NYSE, Nasdaq or AMEX with a price count (the appendix keeps SHRCD 10 to 19 and EXCHCD 1 to 3 and drops missing PRC). our CRSP file has no share code and exchange code on the daily rows, so the test is applied on each daily row through the records of stksecurityinfohist: a row counts when the permno has a record valid on that day with share type NS and primary exchange N, A or Q (our mapping of the CRSP codes, set by the user for this paper: the appendix keeps share codes 10 to 19, the whole range, so here share type NS with no security type, issuer type or US incorporation condition; exchange codes 1, 2 and 3 are primary exchange N, A and Q. ADRs, closed end funds and REITs are removed by the SDC flags, as in the appendix. With share codes 10 and 11 only, the sample is 8,300 IPOs against 8,995 published). the first CRSP date is the first such row and the first closing price is its price
df_shr1 = pd.read_excel(p_codes / 'shrcd.xlsx')
df_shr1 = df_shr1[df_shr1['shrcd'].isin(l_shrcd)]
df_exc1 = pd.read_excel(p_codes / 'exchcd.xlsx')
df_exc1 = df_exc1[df_exc1['exchcd'].isin(l_exchcd)]
df_el1 = duckdb.query(f"SELECT s.permno, s.secinfostartdt AS sd, COALESCE(s.secinfoenddt, TIMESTAMP '2100-01-01') AS ed FROM read_parquet('{p_secinfo}') s JOIN df_shr1 c ON s.sharetype = c.sharetype AND s.securitytype = c.securitytype AND s.securitysubtype = c.securitysubtype AND s.usincflg = c.usincflg AND s.issuertype = c.issuertype JOIN df_exc1 e ON s.primaryexch = e.primaryexch AND s.conditionaltype = e.conditionaltype AND s.tradingstatusflg = e.tradingstatusflg").df()
df_first1 = duckdb.query(f"""SELECT d.permno, MIN(d.dlycaldt)::DATE AS first_crsp_date, ARG_MIN(d.dlyprc, d.dlycaldt) AS close_price
    FROM read_parquet('{p_stock}') d JOIN df_el1 e ON d.permno = e.permno AND d.dlycaldt BETWEEN e.sd AND e.ed
    WHERE d.dlyprc IS NOT NULL AND d.permno IN (SELECT DISTINCT recommended_permno FROM df_ipo2) GROUP BY d.permno""").df()
df_first1['first_crsp_date'] = pd.to_datetime(df_first1['first_crsp_date'])
df_ipo3 = df_ipo2.assign(permno=df_ipo2['recommended_permno'].astype('int64')).merge(df_first1, on='permno', how='left')
df_ipo3['days_first_crsp'] = (df_ipo3['first_crsp_date'] - pd.to_datetime(df_ipo3['recommended_date'])).dt.days
df_ipo4 = df_ipo3[(df_ipo3['days_first_crsp'] >= -v_days_before) & (df_ipo3['days_first_crsp'] <= v_days_after)].copy()
d_steps[f'a CRSP price from {v_days_before} day before to {v_days_after} days after the recommended date'] = len(df_ipo4)
df_ipo4['initial_return'] = df_ipo4['close_price'].abs() / df_ipo4['sdc_offer_price'] - 1
df_ipo4['year'] = pd.to_datetime(df_ipo4['recommended_date']).dt.year
print(pd.Series(d_steps).to_string())

# %%
#real proceeds in 2016 dollars (appendix: GDPDEF of the first quarter of each year, factor = value of 2016 / value of the year)
if p_gdp.exists():
    df_gdp1 = pd.read_csv(p_gdp)
    df_gdp1.columns = [v_c.strip() for v_c in df_gdp1.columns]
    df_gdp1 = df_gdp1.rename(columns={'observation_date': 'DATE'}) #the FRED csv names the date column observation_date
    df_gdp1['DATE'] = pd.to_datetime(df_gdp1['DATE'])
    df_gdp1['year'] = df_gdp1['DATE'].dt.year
    df_gdp2 = df_gdp1.sort_values('DATE').drop_duplicates('year')
    df_gdp2['factor_2016'] = df_gdp2.loc[df_gdp2['year'] == 2016, 'GDPDEF'].iloc[0] / df_gdp2['GDPDEF']
    df_ipo4 = df_ipo4.merge(df_gdp2[['year', 'factor_2016']], on='year', how='left')
else:
    df_ipo4['factor_2016'] = np.nan
    print(f"no deflator file {p_gdp}: real proceeds are not calculated")
for v_p, v_c in [('TR_NIProceedsAmtAllMkts', 'all'), ('TR_NIProceedsAmtThisMkt', 'this')]:
    df_ipo4[f'proceeds_{v_c}'] = df_ipo4[v_p]
    df_ipo4[f'proceeds_{v_c}_2016'] = df_ipo4[v_p] * df_ipo4['factor_2016']

# %%
#the table by year, next to the published one
df_t1 = df_ipo4[(df_ipo4['year'] >= 1973) & (df_ipo4['year'] <= 2016)].groupby('year').agg(n_ipos=('deal_no', 'size'), initial_return_pct=('initial_return', lambda s: 100 * s.mean()),
        avg_proceeds_all=('proceeds_all', 'mean'), avg_proceeds_this=('proceeds_this', 'mean'), avg_proceeds_all_2016=('proceeds_all_2016', 'mean'), avg_proceeds_this_2016=('proceeds_this_2016', 'mean'),
        agg_proceeds_all_2016=('proceeds_all_2016', 'sum'), agg_proceeds_this_2016=('proceeds_this_2016', 'sum')).reset_index()
df_pub1 = pd.read_csv(p_pub)
df_t2 = df_t1.merge(df_pub1[df_pub1['year'].notna()].astype({'year': 'int64'}), on='year', how='outer').sort_values('year').reset_index(drop=True)
#the total line of the table (year empty), next to the published total line
v_tot = df_ipo4[(df_ipo4['year'] >= 1973) & (df_ipo4['year'] <= 2016)]
d_tot = {'year': np.nan, 'n_ipos': len(v_tot), 'initial_return_pct': 100 * v_tot['initial_return'].mean(), 'avg_proceeds_all': v_tot['proceeds_all'].mean(), 'avg_proceeds_this': v_tot['proceeds_this'].mean(),
         'avg_proceeds_all_2016': v_tot['proceeds_all_2016'].mean(), 'avg_proceeds_this_2016': v_tot['proceeds_this_2016'].mean(), 'agg_proceeds_all_2016': v_tot['proceeds_all_2016'].sum(), 'agg_proceeds_this_2016': v_tot['proceeds_this_2016'].sum()}
d_tot.update(df_pub1[df_pub1['year'].isna()].drop(columns=['year', 'source']).iloc[0].to_dict())
df_t2 = pd.concat([df_t2, pd.DataFrame([d_tot])], ignore_index=True)
df_t2['diff_n_ipos'] = df_t2['n_ipos'].fillna(0) - df_t2['pub_n_ipos']
df_t2['diff_avg_proceeds_all_pct'] = 100 * (df_t2['avg_proceeds_all_2016'] / df_t2['pub_avg_proceeds_mil'] - 1)
df_t2['diff_avg_proceeds_this_pct'] = 100 * (df_t2['avg_proceeds_this_2016'] / df_t2['pub_avg_proceeds_mil'] - 1)
df_t2['diff_agg_proceeds_all_pct'] = 100 * (df_t2['agg_proceeds_all_2016'] / df_t2['pub_agg_proceeds_mil'] - 1)
df_t2['diff_agg_proceeds_this_pct'] = 100 * (df_t2['agg_proceeds_this_2016'] / df_t2['pub_agg_proceeds_mil'] - 1)
df_t2['diff_initial_return_pp'] = df_t2['initial_return_pct'] - df_t2['pub_initial_return_pct']
df_t2.to_parquet(p_sdc / f"lmv_table1_replication_{v_outputfile}.parquet", index=False)
df_ipo4.drop(columns=['factor_2016']).to_parquet(p_sdc / f"lmv_table1_sample_{v_outputfile}.parquet", index=False)
df_t2['year_label'] = df_t2['year'].map(lambda v: 'Total' if pd.isna(v) else str(int(v)))
df_by = df_t2[df_t2['year'].notna()]
print(f"years with the same number of IPOs: {(df_by['diff_n_ipos'] == 0).sum()} of {len(df_by)} | number of IPOs differs by at most 5%: {(df_by['diff_n_ipos'].abs() <= 0.05 * df_by['pub_n_ipos']).sum()} | initial return within 1 point: {(df_by['diff_initial_return_pp'].abs() <= 1).sum()}")
print(df_t2[['year_label', 'n_ipos', 'pub_n_ipos', 'diff_n_ipos', 'initial_return_pct', 'pub_initial_return_pct', 'diff_initial_return_pp']].round(1).to_string(index=False))
print(f"average proceeds (real 2016 dollars) against the published column: all markets median difference {df_by['diff_avg_proceeds_all_pct'].abs().median():.1f}%, this market {df_by['diff_avg_proceeds_this_pct'].abs().median():.1f}% | years within 10%: all markets {(df_by['diff_avg_proceeds_all_pct'].abs() <= 10).sum()}, this market {(df_by['diff_avg_proceeds_this_pct'].abs() <= 10).sum()} of {len(df_by)}")
print(df_t2[['year_label', 'avg_proceeds_all_2016', 'avg_proceeds_this_2016', 'pub_avg_proceeds_mil', 'agg_proceeds_all_2016', 'agg_proceeds_this_2016', 'pub_agg_proceeds_mil']].round(1).to_string(index=False))
