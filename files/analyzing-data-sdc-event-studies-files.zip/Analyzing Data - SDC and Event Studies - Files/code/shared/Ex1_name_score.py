#the name matching algorithm, one copy for every program (Ex1_02_merge_sdc_crsp: sdc name and crsp permno, Ex1_04_match_ritter: sdc name and Ritter name, sdc name and crsp permno). the algorithm is the same, only the two names it is given change
#it lives in its own file because the worker processes (windows starts them from scratch) must be able to import it. keep this file in the same folder as the programs are run from
#steps (section "Name scoring algorithm" of IPO table algorithm.md): clean both names, try the name, "The " + the name and every order of the words (names of up to 4 words), score each pair as the mean of six measures, keep the best
#the smallest slice is one name pair: the sdc name and one other name, or the sdc name and one crsp permno (the best score over the names the permno has had). a pair needs nothing else, so the pairs are dealt out to the workers and each pair is scored once
import itertools
import math
import os
import re
import string
import unicodedata
import duckdb
import pandas as pd
from cleanco import basename
from fuzzywuzzy import fuzz
from rapidfuzz import fuzz as rfz
from rapidfuzz import utils as ru
from rapidfuzz.distance import Jaro, JaroWinkler
from threadpoolctl import threadpool_limits
from functools import lru_cache
from pathlib import Path

D = {}   #names of each crsp permno, read once when the process needs them


@lru_cache(maxsize=None)
def clean(v_name):
    #lowercase, no brackets, no accents, "and" and punctuation taken out, company suffixes (inc, corp...) taken out by cleanco until one base word is left
    v_x = v_name.lower()
    v_x = re.sub(r'\s*\(.*\)', '', v_x)
    v_x = re.sub(r'\s*/[a-z]{2,4}/?\s*\Z', '', v_x)
    v_x = unicodedata.normalize('NFKD', v_x).encode('ASCII', 'ignore').decode()
    v_x = v_x.replace('&', ' & ')
    v_x = re.sub(r'\s{2,}', ' ', v_x)
    v_x = re.sub(r'\s+and\s+', ' ', v_x, flags=re.I)
    v_x = re.sub('[{}]'.format(re.escape(string.punctuation)), '', v_x).strip()
    while True:
        l_w = v_x.split()
        if len(l_w) <= 1:
            break
        v_y = basename(v_x).strip()
        if v_y == '':   #everything looked like a suffix (pse inc): only the last word is taken off
            v_y = ' '.join(l_w[:-1]) if basename(l_w[-1]).strip() == '' else v_x
        if v_y == v_x:
            break
        v_x = v_y
    return re.sub(r'\s+', '', v_x)


def sc(v_a, v_b):
    #average of six scores: jaro, jaro-winkler, ratio, partial ratio, token sort ratio, token set ratio. the cleaned names have no spaces, so each name is one token
    #five are calculated by rapidfuzz (rounded to a whole number where fuzzywuzzy rounds: the same result on 30,000 test pairs, 3 to 5 times faster). partial ratio stays with fuzzywuzzy: rapidfuzz aligns the two strings differently and gives another result on 35% of the pairs
    return (Jaro.similarity(v_a, v_b) * 100 + JaroWinkler.similarity(v_a, v_b) * 100 + round(rfz.ratio(v_a, v_b)) + fuzz.partial_ratio(v_a, v_b)
            + round(rfz.token_sort_ratio(v_a, v_b, processor=ru.default_process)) + round(rfz.token_set_ratio(v_a, v_b, processor=ru.default_process))) / 6


@lru_cache(maxsize=None)
def variants(v_n):
    #the name, the name with "The " in front and, for names of up to 4 words, every order of the words
    s_v = {v_n, 'The ' + v_n}
    l_w = v_n.split()
    if len(l_w) <= 4:
        s_v |= {' '.join(p) for p in itertools.permutations(l_w)}
    return tuple(s_v)


def score_names(v_sname, l_names):
    #best score of the sdc name against a list of names. 100 is the highest score possible, so the search stops there
    if not isinstance(v_sname, str) or not l_names:
        return 0.0
    v_a = clean(v_sname)
    v_best = 0.0
    for v_n in l_names:
        for v_v in variants(v_n):
            v_x = round(sc(v_a, clean(v_v)), 2)
            if v_x > v_best:
                v_best = v_x
                if v_best >= 100:
                    return v_best
    return v_best


def load_names(p_secinfo):
    #every crsp name of each permno (without "(Last Known)" and a trailing NEW)
    df_info = duckdb.query(f"SELECT permno, issuernm FROM read_parquet('{p_secinfo}')").df()
    df_nm = df_info.loc[df_info['issuernm'].notna() & ~df_info['issuernm'].str.contains(r'\(Last Known\)', na=False), ['permno', 'issuernm']].drop_duplicates()
    df_nm['issuernm'] = df_nm['issuernm'].str.replace(r'\s+NEW\Z', '', regex=True)
    D['names'] = df_nm.groupby('permno')['issuernm'].apply(lambda x: sorted(set(x))).to_dict()


def init_worker(p_secinfo):
    #runs once when a worker starts: the crsp names are loaded here, not in every task, and numpy limits its own threads so processes x threads is not above the cpu count
    threadpool_limits(limits=1)
    load_names(p_secinfo)


def name_cost(v_name):
    #cost of scoring against one name: the number of word orders tried (the name, "The " + name, and every order of the words for up to 4 words)
    v_k = len(v_name.split())
    return 2 + (math.factorial(v_k) if v_k <= 4 else 0)


def pair_cost(df_t, v_kind):
    #cost of each pair, to deal the pairs out evenly: own = the word orders of the Ritter name, permno = the word orders of all names of the permno
    if v_kind == 'own':
        return df_t['rname'].map(lambda v: name_cost(v) if isinstance(v, str) else 0)
    d_cost = {v_p: sum(name_cost(v_n) for v_n in l_n) for v_p, l_n in D['names'].items()}
    return df_t['permno'].map(d_cost).fillna(0)


def score_task(d_task):
    #one task per worker: the pairs of its share. kind own = sdc name and Ritter name (columns sname, rname), kind permno = sdc name and crsp permno (columns sname, permno). it reads its pairs from a parquet file and writes its own part file
    df_t = pd.read_parquet(d_task['p_in'])
    if d_task['kind'] == 'own':
        df_t['score'] = [score_names(v_a, [v_b]) for v_a, v_b in zip(df_t['sname'], df_t['rname'])]
    else:
        df_t['score'] = [score_names(v_a, D['names'].get(int(v_b), [])) for v_a, v_b in zip(df_t['sname'], df_t['permno'])]
    df_t.to_parquet(d_task['p_out'], index=False)
    return len(df_t)


def run_scores(ex, df_todo, v_kind, v_nw, p_work):
    #scores the pairs of df_todo once, on the workers of the pool ex. the pairs are sorted by cost, largest first, and dealt out 1 to v_nw, then v_nw back to 1, so every worker gets about the same work. returns the pairs with their score
    if len(df_todo) == 0:
        return df_todo.assign(score=pd.Series(dtype='float64'))
    df_todo = df_todo.reset_index(drop=True)
    df_todo['cost'] = pair_cost(df_todo, v_kind).values
    df_todo = df_todo.sort_values('cost', ascending=False).reset_index(drop=True)
    s_pos = pd.Series(range(len(df_todo))) % (2 * v_nw)
    df_todo['worker'] = s_pos.where(s_pos < v_nw, 2 * v_nw - 1 - s_pos)
    s_load = df_todo.groupby('worker')['cost'].sum()
    print(f"{v_kind}: pairs {len(df_todo)} | cost of the busiest worker {s_load.max() / s_load.mean():.3f} times the average")
    l_tasks = []
    for v_w, df_w in df_todo.groupby('worker'):
        p_in = Path(p_work) / f"todo_{v_kind}_{v_w}.parquet"
        df_w.drop(columns=['cost', 'worker']).to_parquet(p_in, index=False)
        l_tasks.append(dict(kind=v_kind, p_in=str(p_in), p_out=str(Path(p_work) / f"scored_{v_kind}_{v_w}.parquet")))
    list(ex.map(score_task, l_tasks))
    df_out = pd.concat([pd.read_parquet(d['p_out']) for d in l_tasks], ignore_index=True)
    for d in l_tasks:
        os.remove(d['p_in'])
        os.remove(d['p_out'])
    return df_out


def init_light():
    #runs once when a worker starts, for tasks that do not need the crsp names: numpy limits its own threads so processes x threads is not above the cpu count
    threadpool_limits(limits=1)


def clean_task(d_task):
    #one task per worker: the names of its share (column name), cleaned with the same clean() as the scores. reads its names from a parquet file and writes its own part file
    df_t = pd.read_parquet(d_task['p_in'])
    df_t['clean'] = [clean(v_n) if isinstance(v_n, str) else None for v_n in df_t['name']]
    df_t.to_parquet(d_task['p_out'], index=False)
    return len(df_t)


def run_clean(ex, df_names, v_nw, p_work):
    #cleans every name of df_names (column name) once, on the workers of the pool ex. the cost of a name is its number of words (cleanco goes over the name again for each suffix it takes off), so the names are sorted by cost, largest first, and dealt out 1 to v_nw, then v_nw back to 1. returns the names with the column clean
    df_names = df_names.reset_index(drop=True)
    df_names['cost'] = df_names['name'].map(lambda v: len(v.split()) if isinstance(v, str) else 0)
    df_names = df_names.sort_values('cost', ascending=False).reset_index(drop=True)
    s_pos = pd.Series(range(len(df_names))) % (2 * v_nw)
    df_names['worker'] = s_pos.where(s_pos < v_nw, 2 * v_nw - 1 - s_pos)
    s_load = df_names.groupby('worker')['cost'].sum()
    print(f"clean: names {len(df_names)} | cost of the busiest worker {s_load.max() / s_load.mean():.3f} times the average")
    l_tasks = []
    for v_w, df_w in df_names.groupby('worker'):
        p_in = Path(p_work) / f"todo_clean_{v_w}.parquet"
        df_w[['name']].to_parquet(p_in, index=False)
        l_tasks.append(dict(p_in=str(p_in), p_out=str(Path(p_work) / f"cleaned_{v_w}.parquet")))
    list(ex.map(clean_task, l_tasks))
    df_out = pd.concat([pd.read_parquet(d['p_out']) for d in l_tasks], ignore_index=True)
    for d in l_tasks:
        os.remove(d['p_in'])
        os.remove(d['p_out'])
    return df_out
