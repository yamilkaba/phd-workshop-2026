# T03 code: the IPO table

## What to run, in which order

Pick how deep you want to go. Each level includes the one above it. Programs on the same line can be run side by side (no dependencies between them).

| you want | run in this order | result |
|---|---|---|
| **1. SDC deals with a CRSP permno** | `Ex1_01_wrds_download` and `Ex1_01_sdc_import` (side by side) → `Ex1_02_merge_sdc_crsp` → `Ex1_03_one_deal_per_permno` | `sdc_ipo_step2_<date>.parquet`: one deal per permno |
| **2. + Ritter row and a recommended permno** | level 1, and `Ex1_01_ritter_download` (side by side with the other 01 programs) → after `Ex1_03`: `Ex1_04_match_ritter` | `sdc_ipo_step3_<date>.parquet`: with `recommended_permno` and `recommended_permno_reason` |
| **3. + SEC prospectus documents** | level 2, and `Ex1_01_sec_submissions_download` (side by side with the other 01 programs) → after `Ex1_04`: `Ex1_05_sec_prospectus_download` | filing list, documents of each deal, tie decisions (in the `sec` data folder) |
| **4. + what the prospectus says, the recommended date and the gvkey** | level 3 → after `Ex1_05`: `Ex1_06_prospectus_read` → `Ex1_07_prospectus_table` | `sdc_ipo_step4_<date>.parquet`: with the prospectus values, the comparison with SDC and `recommended_date` |

**Replications** (after `Ex1_07_prospectus_table`): `Ex2_01_replication1_lmv` alone; and for the quiet period (Tables I and II of Bradley, Jordan, Ritter 2003), in this order: `Ex2_02_replication2_quiet_events` (`code/replication`) → `Ex1_02_event_study_preprocess` (`code/event_study`, settings: run `quiet`, events file `events_quiet.parquet`, model `ma`, benchmark `nasdaq`, days -5 to +119) → `Ex2_03_replication2_quiet_table`.


The number in a program name tells when it can run: **01** = no dependencies on another program (downloads and imports), **02 to 07** = needs the output of an earlier number.

How to run a program: `cd` into its workstream folder and run it from there, for example `cd sdc_crsp` then `python jupytext_py\Ex1_02_merge_sdc_crsp.py`. The notebook with the same name (`Ex1_02_merge_sdc_crsp.ipynb`) has the same cells.

What each program needs before it starts:

| program | needs |
|---|---|
| `Ex1_01_wrds_download` | a WRDS login. Takes about 15 minutes (the daily CRSP file is most of it) |
| `Ex1_01_sdc_import` | the SDC export by hand (`sdc_ipo_download_20261104.xlsx` in Downloads) and the item list csv in `guides`. About 35 seconds |
| `Ex1_01_ritter_download` | nothing (one request to Jay Ritter's site, under a second) |
| `Ex1_01_sec_submissions_download` | nothing, but it is written and **not run** (`v_download=False`). One request, about 1.5 GB. The file can also be downloaded by hand: the steps and the SEC rules are in `guides/IPO table algorithm.md`, Appendix |
| `Ex1_02_merge_sdc_crsp` | the outputs of `Ex1_01_wrds_download` and `Ex1_01_sdc_import` |
| `Ex1_03_one_deal_per_permno` | the output of `Ex1_02` and the hand fix table `ipo_permno_exceptions.parquet` (in the `sdc` data folder) |
| `Ex1_04_match_ritter` | the outputs of `Ex1_03` and `Ex1_01_ritter_download`; the hand fix tables `ipo_ritter_fixes.parquet` and `ipo_ritter_info_wrong.parquet` are read if they exist. 30 to 60 seconds |
| `Ex1_05_sec_prospectus_download` | the output of `Ex1_04` and `submissions.zip` (or the two parquets it makes: `sec_entities` and `sec_filings_ipo_forms`). It asks the SEC for documents only with `v_download=True` |
| `Ex1_06_prospectus_read` | the output of `Ex1_05` and the documents on disk. 128 seconds on 16 workers; no request is sent |
| `Ex1_07_prospectus_table` | the outputs of `Ex1_04` and `Ex1_06`, the CRSP `stksecurityinfohist` table and the hand fix list `ipo_prospectus_fixes.parquet` (in the `sdc` data folder). 2 seconds |

## Folders

Every workstream folder has the notebooks (`.ipynb`) and the worker files at the top, and the `.py` of every program inside `jupytext_py`.

| folder | what | programs |
|---|---|---|
| `sdc_crsp` | SDC and CRSP: downloads, import, Steps 0 to 2 | `Ex1_01_wrds_download`, `Ex1_01_sdc_import`, `Ex1_02_merge_sdc_crsp`, `Ex1_03_one_deal_per_permno` |
| `ritter` | Ritter add-ons: download, Step 3 | `Ex1_01_ritter_download`, `Ex1_04_match_ritter` |
| `sec` | SEC prospectus add-ons | `Ex1_01_sec_submissions_download`, `Ex1_05_sec_prospectus_download` (+ `_worker.py`) |
| `prospectus` | what the prospectus says (Step 4) | `Ex1_06_prospectus_read` (+ `_worker.py`); `Ex1_07_prospectus_table` (fix list, comparison with SDC, first trading dates, recommended date; output `sdc_ipo_step4_<date>.parquet`) |
| `replication` | replications on our IPO table, each with the filters of its own paper | `Ex2_01_replication1_lmv` (Lowry, Michaely, Volkova 2017, Table 1), `Ex2_02_replication2_quiet_events` and `Ex2_03_replication2_quiet_table` (Bradley, Jordan, Ritter 2003, Tables I and II; between the two the event study runs) |
| `event_study` | our event study programs (model, benchmark, windows are settings) | `Ex1_02_event_study_preprocess`, `Ex1_03_cross_section_analysis`, `Ex1_03_time_series_analysis` |
| `shared` | code used by more than one workstream | `Ex1_name_score.py` (name matching, used by Steps 1 and 3) |
| `old` | not in use: October SDC and SEC programs 04 to 09, backups of 2026-11-09, the replications dropped on 2026-11-10 | |

Papers to replicate, Ritter's website files and the CRSP code tables are in `../references` (documents, neither code nor data; this folder goes to the website as references).

The data is in `D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109` (everything is made by these programs, except the SDC export and the hand fix tables). The decisions behind every step are in `guides/IPO table algorithm.md`.

`parallelization_blueprint.md`: how the parallel programs are built here.
