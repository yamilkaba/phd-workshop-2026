# %%
import os
import sys
import time
import duckdb
import numpy as np
import pandas as pd
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
sys.path.append(str(Path.cwd().parent / "shared"))   #run from this folder: the shared name matching file is in ../shared
import Ex1_name_score as ns

# %%
#folders and files: change accordingly. the step 0 and step 2 tables are the output of Ex1_02_merge_sdc_crsp and Ex1_03_one_deal_per_permno, the ritter parquet is the output of Ex1_01_ritter_download, the crsp table is the output of Ex1_01_wrds_download
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download. the outputs are sdc_ipo_step3_<v_outputfile>.parquet, sdc_ipo_step3_removed_<v_outputfile>.parquet (deals dropped) and sdc_ipo_step3_ritter_added_ / _removed_ / _unused_<v_outputfile>.parquet (the Ritter rows) in p_path/sdc
p_ritter=p_path / 'sdc' / 'ritter' / 'ritter_ipo_age_20261109.parquet'
p_secinfo=p_path / 'crsp_a_stock' / 'stksecurityinfohist.parquet'
p_work=p_path / 'sdc' / 'step3_work' #temporary files of the workers
v_reuse_scores=True #True = the name scores saved by an earlier run are read and only the pairs that are not in them are scored. False = everything is scored again (use it after the scoring code changes)
p_scores_own=p_path / 'sdc' / 'name_scores_own.parquet' #saved scores: sdc name and Ritter name
p_scores_permno=p_path / 'sdc' / f"name_scores_permno_{p_secinfo.stat().st_size}_{p_secinfo.stat().st_mtime_ns}.parquet" #saved scores: sdc name and crsp permno (best over its names). the file name has the size and time of the crsp security info file, so a new crsp download is scored again
v_days=30 #a ritter offer date is within this many days of the sdc issue date (or of the first crsp trading date of the permno)
v_days_year=365 #a ritter row found by permno must also be within a year of the sdc issue date
v_min_score=70 #minimum name score
v_cusip_days=7 #the cusip confirms a ritter row only within this many days
v_nw=os.cpu_count() #workers that score the name pairs. 1 = no extra processes
v_sample=None #a number = only the first deals of the table (to time the program), None = all
p_fix_row=p_path / 'sdc' / 'ipo_ritter_fixes.parquet' #hand fixes of the Ritter row: which Ritter row a deal has when the rules gave it a wrong one (made by hand)
p_none=p_path / 'sdc' / 'ipo_recommendation_none.parquet' #deals for which no permno is recommended (made by hand): step 2 and the candidates below are unchanged, the recommended permno is empty and the reason is 'correct firm not found'
p_fix_info=p_path / 'sdc' / 'ipo_ritter_info_wrong.parquet' #Ritter rows with a wrong permno or cusip (made by hand): the row is the right row for our deal, but the recommended permno does not come from it

# %%
if __name__ == '__main__':
    #deals of step 2: the permnos of each deal (a deal can have more than one) and the sdc fields used for the match
    df_step2_1 = pd.read_parquet(p_path / 'sdc' / f"sdc_ipo_step2_{v_outputfile}.parquet", columns=['deal_no', 'permno'])
    df_perm1 = df_step2_1.groupby('deal_no')['permno'].apply(lambda x: [int(v) for v in x.dropna()]).rename('permnos').reset_index()
    df_sdc1 = pd.read_parquet(p_path / 'sdc' / f"sdc_ipo_step0_{v_outputfile}.parquet", columns=['TR_NISdcDealNumber', 'TR_NIIssuerCusip9', 'TR_NIIssuerSDCCusip', 'TR_NIIssuerPrimayTickerSymbol', 'TR_NIIssuer', 'TR_NIIssueDate', 'TR_NIIsMainTranche'])
    df_sdc1 = df_sdc1.rename(columns={'TR_NISdcDealNumber': 'deal_no', 'TR_NIIssuerCusip9': 'c9', 'TR_NIIssuerSDCCusip': 'c6', 'TR_NIIssuerPrimayTickerSymbol': 'stk', 'TR_NIIssuer': 'sname', 'TR_NIIssueDate': 'idt', 'TR_NIIsMainTranche': 'main'})
    df_sdc1['idt'] = pd.to_datetime(df_sdc1['idt']).dt.normalize()
    df_sdc1['stk'] = df_sdc1['stk'].str.upper().str.strip()
    df_sdc1['k6'] = df_sdc1['c9'].str[:6].fillna(df_sdc1['c6'])
    df_deals1 = df_perm1.merge(df_sdc1, on='deal_no').sort_values('idt').reset_index(drop=True)
    df_deals1 = df_deals1.head(v_sample) if v_sample else df_deals1
    os.makedirs(p_work, exist_ok=True)
    print(f"deals {len(df_deals1)} | deals with a permno {(df_deals1['permnos'].str.len() > 0).sum()}")

# %%
if __name__ == '__main__':
    #ritter rows: offer date, name, ticker, cusip, crsp permno, dual share flag. rid = the position of the row in the sheet. a cusip is kept only when it has 6 to 9 letters or digits
    df_ritter0 = pd.read_parquet(p_ritter)
    df_ritter1 = df_ritter0.rename(columns={'offer date': 'od', 'IPO name': 'rname', 'Ticker': 'rtick', 'CUSIP': 'rc', 'CRSP Perm': 'rperm', 'Dual': 'dual'})
    df_ritter1['rid'] = range(len(df_ritter1))
    df_ritter1['od'] = pd.to_datetime(df_ritter1['od'].astype(str), format='%Y%m%d', errors='coerce')
    df_ritter1['rperm'] = pd.to_numeric(df_ritter1['rperm'], errors='coerce')
    df_ritter1['dual'] = df_ritter1['dual'].astype(str)
    df_ritter1['rc'] = df_ritter1['rc'].str.strip()
    df_ritter1.loc[~df_ritter1['rc'].str.match(r'^[0-9A-Za-z]{6,9}$', na=False), 'rc'] = pd.NA
    df_ritter1['r8'] = df_ritter1['rc'].str[:8]
    df_ritter1['r6'] = df_ritter1['rc'].str[:6]
    df_ritter1['rtick'] = df_ritter1['rtick'].str.upper().str.strip()
    df_ritter1.loc[df_ritter1['rtick'].isin(['NAN', 'NONE', '.', '']), 'rtick'] = pd.NA
    df_ritter1 = df_ritter1[['rid', 'rname', 'od', 'rtick', 'rc', 'r8', 'r6', 'rperm', 'dual']]
    df_rit1 = df_ritter1[df_ritter1['od'].notna()]
    print(f"ritter rows {len(df_ritter1)} | with an offer date {len(df_rit1)} | with a crsp permno {df_ritter1['rperm'].notna().sum()}")

# %%
if __name__ == '__main__':
    #from the crsp security info table: the first trading date of each permno, every ticker and trading symbol each permno has had, and the latest name of each permno
    df_info1 = duckdb.query(f"SELECT permno, ticker, tradingsymbol, issuernm, secinfoenddt, secinfostartdt FROM read_parquet('{p_secinfo}')").df()
    df_ft1 = df_info1.groupby('permno', as_index=False).agg(ft=('secinfostartdt', 'min'))
    df_ft1['ft'] = pd.to_datetime(df_ft1['ft'])
    df_tk1 = pd.concat([df_info1[['permno', 'ticker']].rename(columns={'ticker': 'tk'}), df_info1[['permno', 'tradingsymbol']].rename(columns={'tradingsymbol': 'tk'})]).dropna()
    df_tk1['tk'] = df_tk1['tk'].str.upper()
    df_tk1 = df_tk1.drop_duplicates()
    df_last1 = duckdb.query("SELECT permno, ARG_MAX(issuernm, secinfoenddt) AS nm FROM df_info1 WHERE issuernm NOT LIKE '%(Last Known)%' GROUP BY permno").df()
    d_last = dict(zip(df_last1['permno'], df_last1['nm']))
    print(f"permnos {len(df_ft1)} | permno and ticker pairs {len(df_tk1)}")

# %%
if __name__ == '__main__':
    #one pool of workers for the whole program (started once; each worker loads the crsp names once). it is shut down in the last cell
    ns.load_names(p_secinfo) #the names are also needed here, to estimate the cost of each pair
    ex = ProcessPoolExecutor(max_workers=v_nw, initializer=ns.init_worker, initargs=(p_secinfo,))
    #name scores of the crsp permnos of every deal: the sdc name against every name the permno has had, best score. one row for each distinct sdc name and permno, scored once and saved (a run reads the saved scores and scores only the pairs that are not in them). the scores are looked up by join below
    v_t0 = time.time()
    df_dp1 = df_deals1[['deal_no', 'sname', 'idt', 'permnos']].explode('permnos').dropna(subset=['permnos']).rename(columns={'permnos': 'permno'})
    df_dp1['permno'] = df_dp1['permno'].astype('int64')
    df_dp1['ord'] = range(len(df_dp1)) #the order of the permnos of a deal, a tie goes to the first
    df_sc_perm = pd.read_parquet(p_scores_permno) if (v_reuse_scores and p_scores_permno.exists()) else pd.DataFrame({'sname': pd.Series(dtype='str'), 'permno': pd.Series(dtype='int64'), 'score': pd.Series(dtype='float64')})
    df_sc_own = pd.read_parquet(p_scores_own) if (v_reuse_scores and p_scores_own.exists()) else pd.DataFrame({'sname': pd.Series(dtype='str'), 'rname': pd.Series(dtype='str'), 'score': pd.Series(dtype='float64')})
    print(f"saved scores read: sdc name and crsp permno {len(df_sc_perm)} | sdc name and Ritter name {len(df_sc_own)}")
    df_todo1 = df_dp1.loc[df_dp1['sname'].notna(), ['sname', 'permno']].drop_duplicates().merge(df_sc_perm[['sname', 'permno']], how='left', indicator=True)
    df_todo1 = df_todo1[df_todo1['_merge'] == 'left_only'][['sname', 'permno']]
    df_sc_perm = pd.concat([df_sc_perm, ns.run_scores(ex, df_todo1, 'permno', v_nw, p_work)], ignore_index=True)
    print(f"pairs scored now: sdc name and crsp permno {len(df_todo1)} | {time.time() - v_t0:.0f} seconds")

# %%
if __name__ == '__main__':
    #the Ritter row of each deal, one way after the other: permno, cusip, ticker, name. for the deals still without a row, one range join gives the candidate rows of the way (deal, Ritter row); the name pairs not scored yet are scored once; the scores are joined; the rows of a deal are ranked by the score of the Ritter row's own name (a tie goes to the row closest in date, then the lower row number) and the first row that is confirmed is taken
    #confirmed: the name (the Ritter row's own name, or a crsp name of its permno, scores at least 70), or the ticker (the same as the Ritter ticker or any ticker of the Ritter permno), or the cusip (same first 8 characters and within 7 days)
    #permno way: the Ritter row has one of the deal's permnos and its offer date is within 30 days of the sdc date or of the first crsp trading date of the permno, and within a year of the sdc date. cusip way: same first 8 (or first 6) characters, within 30 days. ticker way: same ticker, within 30 days. name way: any row within 30 days
    v_t0 = time.time()
    df_unres = df_deals1.copy()
    l_pick = []
    for v_way in ['permno', 'cusip', 'ticker', 'name']:
        df_dd = df_unres[['deal_no', 'idt', 'c9', 'k6', 'stk']]
        df_dp = df_dp1[df_dp1['deal_no'].isin(df_unres['deal_no'])][['deal_no', 'idt', 'permno']]
        if v_way == 'permno':
            v_q = f"""SELECT DISTINCT d.deal_no, r.rid FROM df_dp d JOIN df_rit1 r ON r.rperm = d.permno LEFT JOIN df_ft1 f ON f.permno = r.rperm
                      WHERE ABS(DATE_DIFF('day', d.idt::DATE, r.od::DATE)) <= {v_days_year} AND (ABS(DATE_DIFF('day', d.idt::DATE, r.od::DATE)) <= {v_days} OR ABS(DATE_DIFF('day', f.ft::DATE, r.od::DATE)) <= {v_days})"""
        elif v_way == 'cusip':
            v_q = f"""SELECT DISTINCT d.deal_no, r.rid FROM df_dd d JOIN df_rit1 r ON ((d.c9 IS NOT NULL AND r.r8 = LEFT(d.c9, 8)) OR (d.k6 IS NOT NULL AND r.r6 = d.k6))
                      AND r.od BETWEEN d.idt - INTERVAL {v_days} DAY AND d.idt + INTERVAL {v_days} DAY"""
        elif v_way == 'ticker':
            v_q = f"""SELECT DISTINCT d.deal_no, r.rid FROM df_dd d JOIN df_rit1 r ON d.stk IS NOT NULL AND r.rtick = d.stk
                      AND r.od BETWEEN d.idt - INTERVAL {v_days} DAY AND d.idt + INTERVAL {v_days} DAY"""
        else:
            v_q = f"""SELECT DISTINCT d.deal_no, r.rid FROM df_dd d JOIN df_rit1 r ON r.od BETWEEN d.idt - INTERVAL {v_days} DAY AND d.idt + INTERVAL {v_days} DAY"""
        df_cand1 = duckdb.query(v_q).df()
        df_cand1 = df_cand1.merge(df_unres[['deal_no', 'sname', 'stk', 'c9', 'idt']], on='deal_no').merge(df_rit1[['rid', 'rname', 'rtick', 'r8', 'rperm', 'od']], on='rid')
        #name pairs of this way that are not scored yet
        df_new_own = df_cand1.loc[df_cand1['sname'].notna() & df_cand1['rname'].notna(), ['sname', 'rname']].drop_duplicates().merge(df_sc_own[['sname', 'rname']], how='left', indicator=True)
        df_new_own = df_new_own[df_new_own['_merge'] == 'left_only'][['sname', 'rname']]
        df_new_perm = df_cand1.loc[df_cand1['sname'].notna() & df_cand1['rperm'].notna(), ['sname', 'rperm']].drop_duplicates().rename(columns={'rperm': 'permno'})
        df_new_perm['permno'] = df_new_perm['permno'].astype('int64')
        df_new_perm = df_new_perm.merge(df_sc_perm[['sname', 'permno']], how='left', indicator=True)
        df_new_perm = df_new_perm[df_new_perm['_merge'] == 'left_only'][['sname', 'permno']]
        df_sc_own = pd.concat([df_sc_own, ns.run_scores(ex, df_new_own, 'own', v_nw, p_work)], ignore_index=True)
        df_sc_perm = pd.concat([df_sc_perm, ns.run_scores(ex, df_new_perm, 'permno', v_nw, p_work)], ignore_index=True)
        #the scores are looked up
        df_c2 = df_cand1.merge(df_sc_own.rename(columns={'score': 'own'}), on=['sname', 'rname'], how='left')
        df_c2 = df_c2.merge(df_sc_perm.rename(columns={'score': 'sc_crsp', 'permno': 'rperm'}), on=['sname', 'rperm'], how='left')
        df_c2 = df_c2.merge(df_tk1.assign(tk_ok=True).rename(columns={'permno': 'rperm', 'tk': 'stk'}), on=['rperm', 'stk'], how='left')
        df_c2[['own', 'sc_crsp']] = df_c2[['own', 'sc_crsp']].fillna(0.0)
        df_c2['days'] = (df_c2['od'] - df_c2['idt']).dt.days.abs()
        f_name = df_c2[['own', 'sc_crsp']].max(axis=1) >= v_min_score
        f_ticker = df_c2['stk'].notna() & ((df_c2['rtick'].notna() & (df_c2['rtick'] == df_c2['stk'])) | df_c2['tk_ok'].eq(True))
        f_cusip = df_c2['c9'].notna() & df_c2['r8'].notna() & (df_c2['c9'].str[:8] == df_c2['r8']) & (df_c2['days'] <= v_cusip_days)
        df_c2['confirm'] = np.where(f_name, 'name', np.where(f_ticker, 'ticker', np.where(f_cusip, 'cusip', None)))
        df_c3 = df_c2[df_c2['confirm'].notna()].sort_values(['deal_no', 'own', 'days', 'rid'], ascending=[True, False, True, True]).drop_duplicates('deal_no')
        l_pick.append(df_c3[['deal_no', 'rid', 'confirm', 'own']].rename(columns={'rid': 'ritter_row', 'confirm': 'ritter_confirm', 'own': 'ritter_own_name_score'}).assign(ritter_way=v_way))
        df_unres = df_unres[~df_unres['deal_no'].isin(df_c3['deal_no'])]
        print(f"{v_way}: candidate rows {len(df_cand1)} | new name pairs scored {len(df_new_own) + len(df_new_perm)} | deals with a Ritter row {len(df_c3)} | deals still without {len(df_unres)} | {time.time() - v_t0:.0f} seconds")
    df_pick1 = pd.concat(l_pick, ignore_index=True)

# %%
if __name__ == '__main__':
    #the Ritter row that the rules gave to each deal, with the Ritter fields next to it (assignments). rk = the way that found it, a better way first (a row given by hand goes first of all)
    df_asg1 = df_pick1.merge(df_deals1[['deal_no', 'sname', 'main']], on='deal_no').merge(df_ritter1.rename(columns={'rid': 'ritter_row'}), on='ritter_row')
    df_asg1['rk'] = df_asg1['ritter_way'].map({'hand': -1, 'permno': 0, 'cusip': 1, 'ticker': 2, 'name': 3})
    df_asg1['e002'] = df_asg1['deal_no'].astype(str).str.endswith('002')
    print(f"deals with a Ritter row from the rules {len(df_asg1)}")

# %%
if __name__ == '__main__':
    #rule: two deals on one ritter row. the row belongs to one deal, the one that found it by the better way (permno, cusip, ticker, name); then the one whose deal number ends in 002; then the main tranche; then the better name score of the ritter row's own name. the other deals lose the row: their assignment goes to the removed table with the deal that kept the row (lost_to)
    l_keep = []
    l_lost = []
    for v_rid, df_g in df_asg1.groupby('ritter_row'):
        if df_g['deal_no'].nunique() < 2:
            l_keep.append(df_g)
            continue
        df_c = df_g[df_g['rk'] == df_g['rk'].min()]
        v_step = 'way'
        if len(df_c) > 1 and df_c['e002'].any() and not df_c['e002'].all():
            df_c = df_c[df_c['e002']]
            v_step = '002'
        if len(df_c) > 1 and (df_c['main'] == True).any() and not (df_c['main'] == True).all():
            df_c = df_c[df_c['main'] == True]
            v_step = 'main'
        if len(df_c) > 1 and df_c['ritter_own_name_score'].nunique() > 1:
            df_c = df_c[df_c['ritter_own_name_score'] == df_c['ritter_own_name_score'].max()]
            v_step = 'name score'
        l_keep.append(df_c)
        l_lost.append(df_g[~df_g['deal_no'].isin(df_c['deal_no'])].assign(removed_by=f"two deals on one Ritter row ({v_step})", lost_to=df_c['deal_no'].iloc[0]))
        if len(df_c) > 1:
            print('still tied', v_rid, df_c['deal_no'].tolist())
    df_asg2 = pd.concat(l_keep, ignore_index=True)
    df_lost1 = pd.concat(l_lost, ignore_index=True)
    df_lost1['lost_to'] = df_lost1['lost_to'].astype('Int64')
    print(f"deals that lose their ritter row: {len(df_lost1)} | by {df_lost1['removed_by'].value_counts().to_dict()}")

# %%
if __name__ == '__main__':
    #hand fixes of the Ritter row, applied last. when the row the rules gave to a deal is not the correct one, the fix file says which row the deal has: action assign (the deal gets this Ritter row; its other row and the other deals on that row go to the removed table) or no_row (the deal does not have this row; with no deal number, no deal has it). a row is found by its name and offer date. a deal that lost a row to a deal whose row is taken away by a fix (a fix with a deal number) gets its row back. the rule of two deals on one row runs again after the fixes
    df_fix1 = pd.read_parquet(p_fix_row) if p_fix_row.exists() else pd.DataFrame({'deal_no': pd.Series(dtype='Int64'), 'ritter_name': pd.Series(dtype='str'), 'ritter_ipo_date': pd.Series(dtype='datetime64[ns]'), 'action': pd.Series(dtype='str')})
    df_fix2 = df_fix1.merge(df_ritter1[['rid', 'rname', 'od']], left_on=['ritter_name', 'ritter_ipo_date'], right_on=['rname', 'od'], how='left')
    print(f"hand fixes of the Ritter row {len(df_fix2)} | Ritter row not found by name and date {df_fix2['rid'].isna().sum()}")
    df_asg3 = df_asg2.copy()
    l_rem = []
    l_add = []
    s_gone = set() #(deal, row) taken away by a fix
    for v_f in df_fix2[df_fix2['rid'].notna()].itertuples():
        v_rid = int(v_f.rid)
        if v_f.action == 'no_row':
            f_x = (df_asg3['ritter_row'] == v_rid) & ((df_asg3['deal_no'] == v_f.deal_no) if pd.notna(v_f.deal_no) else True)
            l_rem.append(df_asg3[f_x].assign(removed_by='hand fix (no row)', lost_to=pd.NA))
            if pd.notna(v_f.deal_no): #a row that is wrong for every deal (no deal number) is not given back to the deals that lost it to another deal
                s_gone |= set(zip(df_asg3.loc[f_x, 'deal_no'], df_asg3.loc[f_x, 'ritter_row']))
            df_asg3 = df_asg3[~f_x]
        elif v_f.action == 'assign':
            f_old = (df_asg3['deal_no'] == v_f.deal_no) & (df_asg3['ritter_row'] != v_rid)
            l_rem.append(df_asg3[f_old].assign(removed_by='hand fix (replaced by another row)', lost_to=pd.NA))
            s_gone |= set(zip(df_asg3.loc[f_old, 'deal_no'], df_asg3.loc[f_old, 'ritter_row']))
            f_other = (df_asg3['ritter_row'] == v_rid) & (df_asg3['deal_no'] != v_f.deal_no)
            l_rem.append(df_asg3[f_other].assign(removed_by='hand fix (row given to another deal)', lost_to=v_f.deal_no))
            df_asg3 = df_asg3[~f_old & ~f_other]
            if not ((df_asg3['deal_no'] == v_f.deal_no) & (df_asg3['ritter_row'] == v_rid)).any():
                df_new = df_deals1[df_deals1['deal_no'] == v_f.deal_no][['deal_no', 'sname', 'main']].merge(df_ritter1.assign(ritter_row=df_ritter1['rid'])[df_ritter1['rid'] == v_rid].drop(columns='rid'), how='cross')
                df_new = df_new.assign(ritter_way='hand', ritter_confirm='hand', ritter_own_name_score=np.nan, rk=-1, e002=str(v_f.deal_no).endswith('002'))
                l_add.append(df_new)
                df_asg3 = pd.concat([df_asg3, df_new], ignore_index=True)
    f_back = df_lost1.apply(lambda r: (r['lost_to'], r['ritter_row']) in s_gone, axis=1) if len(df_lost1) else pd.Series(dtype=bool)
    df_back = df_lost1[f_back].drop(columns=['removed_by', 'lost_to'])
    df_asg3 = pd.concat([df_asg3, df_back], ignore_index=True)
    df_rem1 = pd.concat([df_lost1[~f_back]] + l_rem, ignore_index=True)
    df_added1 = pd.concat(l_add, ignore_index=True) if l_add else df_asg1.iloc[0:0].copy()
    print(f"rows taken away by the fixes {sum(len(x) for x in l_rem)} | rows given by hand {len(df_added1)} | rows brought back from removed {len(df_back)}")

# %%
if __name__ == '__main__':
    #rule: two deals on one ritter row, again on the table with the hand fixes (same rule as above)
    l_keep = []
    l_lost = []
    for v_rid, df_g in df_asg3.groupby('ritter_row'):
        if df_g['deal_no'].nunique() < 2:
            l_keep.append(df_g)
            continue
        df_c = df_g[df_g['rk'] == df_g['rk'].min()]
        v_step = 'way'
        if len(df_c) > 1 and df_c['e002'].any() and not df_c['e002'].all():
            df_c = df_c[df_c['e002']]
            v_step = '002'
        if len(df_c) > 1 and (df_c['main'] == True).any() and not (df_c['main'] == True).all():
            df_c = df_c[df_c['main'] == True]
            v_step = 'main'
        if len(df_c) > 1 and df_c['ritter_own_name_score'].nunique() > 1:
            df_c = df_c[df_c['ritter_own_name_score'] == df_c['ritter_own_name_score'].max()]
            v_step = 'name score'
        l_keep.append(df_c)
        l_lost.append(df_g[~df_g['deal_no'].isin(df_c['deal_no'])].assign(removed_by=f"two deals on one Ritter row after the hand fixes ({v_step})", lost_to=df_c['deal_no'].iloc[0]))
    df_asg4 = pd.concat(l_keep, ignore_index=True)
    df_rem2 = pd.concat([df_rem1] + l_lost, ignore_index=True)
    df_rem2['lost_to'] = df_rem2['lost_to'].astype('Int64')
    print(f"deals with a Ritter row {len(df_asg4)} | rows in the removed table {len(df_rem2)}: {df_rem2['removed_by'].value_counts().to_dict()}")

# %%
if __name__ == '__main__':
    #scores that the rows given by hand need (sdc name against the crsp names of the Ritter permno) are scored now, then the scores are saved and the pool of workers is shut down
    df_new_perm = df_asg4.loc[df_asg4['sname'].notna() & df_asg4['rperm'].notna(), ['sname', 'rperm']].drop_duplicates().rename(columns={'rperm': 'permno'})
    df_new_perm['permno'] = df_new_perm['permno'].astype('int64')
    df_new_perm = df_new_perm.merge(df_sc_perm[['sname', 'permno']], how='left', indicator=True)
    df_new_perm = df_new_perm[df_new_perm['_merge'] == 'left_only'][['sname', 'permno']]
    df_sc_perm = pd.concat([df_sc_perm, ns.run_scores(ex, df_new_perm, 'permno', v_nw, p_work)], ignore_index=True)
    df_sc_own.to_parquet(p_scores_own, index=False) #the scores are kept for the next run
    df_sc_perm.to_parquet(p_scores_permno, index=False)
    ex.shutdown()
    print(f"new pairs scored for the final rows {len(df_new_perm)}")

# %%
if __name__ == '__main__':
    #the best crsp permno of each deal (a name score of at least 70 first, then the higher score, then the first trading date closest to the sdc date, then the first permno) and the score of the Ritter permno, both looked up in the scores
    df_cc1 = df_dp1.merge(df_ft1, on='permno').merge(df_sc_perm, on=['sname', 'permno'], how='left')
    df_cc1['score'] = df_cc1['score'].fillna(0.0)
    df_cc1['gap'] = (df_cc1['idt'] - df_cc1['ft']).dt.days
    df_cc1['ok'] = df_cc1['score'] >= v_min_score
    df_cb1 = df_cc1.sort_values(['deal_no', 'ok', 'score', 'gap', 'ord'], key=lambda s: s.abs() if s.name == 'gap' else s, ascending=[True, False, False, True, True]).drop_duplicates('deal_no')
    df_cb1 = df_cb1[['deal_no', 'permno', 'score', 'gap']].rename(columns={'permno': 'crsp_permno', 'score': 'crsp_name_score', 'gap': 'crsp_days'})
    df_rc1 = df_asg4[df_asg4['rperm'].notna()][['deal_no', 'rperm', 'sname']].merge(df_deals1[['deal_no', 'idt']], on='deal_no').rename(columns={'rperm': 'ritter_permno'})
    df_rc1['ritter_permno'] = df_rc1['ritter_permno'].astype('int64')
    df_rc1 = df_rc1.merge(df_ft1.rename(columns={'permno': 'ritter_permno'}), on='ritter_permno', how='left').merge(df_sc_perm.rename(columns={'permno': 'ritter_permno', 'score': 'ritter_name_score'}), on=['sname', 'ritter_permno'], how='left')
    df_rc1['ritter_name_score'] = df_rc1['ritter_name_score'].fillna(0.0).where(df_rc1['ft'].notna())
    df_rc1['ritter_days'] = (df_rc1['idt'] - df_rc1['ft']).dt.days
    df_match1 = df_deals1[['deal_no']].merge(df_asg4[['deal_no', 'ritter_row', 'ritter_way', 'ritter_confirm', 'ritter_own_name_score']], on='deal_no', how='left').merge(df_cb1, on='deal_no', how='left').merge(df_rc1[['deal_no', 'ritter_permno', 'ritter_name_score', 'ritter_days']], on='deal_no', how='left')
    df_match1 = df_match1.astype({'ritter_row': 'Int64', 'crsp_permno': 'Int64', 'ritter_permno': 'Int64', 'crsp_days': 'Int64', 'ritter_days': 'Int64'})
    print(df_match1.shape)
    print(df_match1['ritter_way'].fillna('none').value_counts().to_dict(), '| confirm', df_match1['ritter_confirm'].fillna('none').value_counts().to_dict())

# %%
if __name__ == '__main__':
    #the sdc, crsp and ritter fields next to each other. the Ritter info that is wrong (hand list): a Ritter row can be the right row for our deal and still have a wrong permno or cusip (for example two ipos with their permnos swapped); the flags show it
    df_r2 = df_ritter1.set_index('rid')
    df_wrong1 = pd.read_parquet(p_fix_info) if p_fix_info.exists() else pd.DataFrame({'ritter_name': pd.Series(dtype='str'), 'ritter_ipo_date': pd.Series(dtype='datetime64[ns]'), 'field': pd.Series(dtype='str')})
    df_wrong2 = df_wrong1.merge(df_ritter1[['rid', 'rname', 'od']], left_on=['ritter_name', 'ritter_ipo_date'], right_on=['rname', 'od'], how='left')
    print(f"Ritter info wrong, hand list {len(df_wrong2)} | row not found by name and date {df_wrong2['rid'].isna().sum()}")
    df_o1 = df_match1.merge(df_deals1, on='deal_no')
    df_o1['crsp_permnos'] = df_o1['permnos'].astype(str)
    df_o1['sdc_ipo_date'] = df_o1['idt']
    df_o1 = df_o1.rename(columns={'sname': 'sdc_name', 'c9': 'sdc_cusip9', 'stk': 'sdc_ticker', 'main': 'sdc_main'})
    df_o1['crsp_name'] = df_o1['crsp_permno'].map(d_last)
    df_o1['ritter_name'] = df_o1['ritter_row'].map(df_r2['rname'])
    df_o1['ritter_ipo_date'] = df_o1['ritter_row'].map(df_r2['od'])
    df_o1['ritter_ticker'] = df_o1['ritter_row'].map(df_r2['rtick'])
    df_o1['ritter_cusip'] = df_o1['ritter_row'].map(df_r2['rc'])
    df_o1['ritter_dual'] = df_o1['ritter_row'].map(df_r2['dual'])
    df_o1['ritter_crsp_name'] = df_o1['ritter_permno'].map(d_last)
    df_o1['ritter_permno_wrong'] = df_o1['ritter_row'].isin(set(df_wrong2.loc[df_wrong2['field'] == 'permno', 'rid'].dropna().astype(int)))
    df_o1['ritter_cusip_wrong'] = df_o1['ritter_row'].isin(set(df_wrong2.loc[df_wrong2['field'] == 'cusip', 'rid'].dropna().astype(int)))
    print(df_o1.shape, '| rows with a wrong Ritter permno', int(df_o1['ritter_permno_wrong'].sum()), '| with a wrong Ritter cusip', int(df_o1['ritter_cusip_wrong'].sum()))

# %%
if __name__ == '__main__':
    #the permno recommendation. candidates: the best crsp permno of step 2 and the permno of the ritter row. a candidate passes when its name score is at least 70. if both are the same permno it is accepted (no test); if both pass and differ the higher name score wins, a tie goes to the permno whose first crsp trading date is closer to the sdc date; none passes = no permno
    #the ritter permno is a candidate only when it is in crsp (it has a name score) and is not on the wrong list: then the recommendation is the crsp permno, and the label says so
    df_o2 = df_o1.copy()
    s_none = set(pd.read_parquet(p_none)['deal_no']) if p_none.exists() else set() #deals with no recommended permno by hand: the candidates are not used
    l_decision = []
    l_chosen = []
    for v_r in df_o2.itertuples():
        if v_r.deal_no in s_none:
            l_decision.append('correct firm not found')
            l_chosen.append(pd.NA)
            continue
        v_wrong = bool(v_r.ritter_permno_wrong) and pd.notna(v_r.ritter_permno)
        v_has_c = pd.notna(v_r.crsp_permno)
        v_has_r = pd.notna(v_r.ritter_name_score) and not v_wrong
        v_ok_c = v_has_c and v_r.crsp_name_score >= v_min_score
        v_ok_r = v_has_r and v_r.ritter_name_score >= v_min_score
        v_lab, v_ch, v_sc = '[no permno]', pd.NA, np.nan
        if v_has_c and not v_has_r:
            v_lab, v_ch, v_sc = ('[crsp only]', v_r.crsp_permno, v_r.crsp_name_score) if v_ok_c else ('[none passes]', pd.NA, np.nan)
        elif v_has_r and not v_has_c:
            v_lab, v_ch, v_sc = ('[ritter only]', v_r.ritter_permno, v_r.ritter_name_score) if v_ok_r else ('[none passes]', pd.NA, np.nan)
        elif v_has_c and v_has_r:
            if v_r.crsp_permno == v_r.ritter_permno:
                v_lab, v_ch, v_sc = '[agree]', v_r.crsp_permno, v_r.crsp_name_score
            elif v_ok_c and v_ok_r:
                if (v_r.crsp_name_score, -abs(v_r.crsp_days)) >= (v_r.ritter_name_score, -abs(v_r.ritter_days)):
                    v_lab, v_ch, v_sc = '[crsp wins]', v_r.crsp_permno, v_r.crsp_name_score
                else:
                    v_lab, v_ch, v_sc = '[ritter wins]', v_r.ritter_permno, v_r.ritter_name_score
            elif v_ok_c:
                v_lab, v_ch, v_sc = '[crsp wins]', v_r.crsp_permno, v_r.crsp_name_score
            elif v_ok_r:
                v_lab, v_ch, v_sc = '[ritter wins]', v_r.ritter_permno, v_r.ritter_name_score
            else:
                v_lab = '[none passes]'
        l_decision.append(v_lab + (' (ritter permno wrong)' if v_wrong else ''))
        l_chosen.append(v_ch)
    df_o2['recommended_permno_reason'] = l_decision #why this permno: which candidate and which rule
    df_o2['recommended_permno'] = pd.array(l_chosen, dtype='Int64') #the recommended permno: the crsp permno or the permno of the ritter row, by the rules above
    s_lost_deals = set(df_rem2['deal_no']) - set(df_asg4['deal_no'])
    df_o2['lost_ritter_row'] = df_o2['deal_no'].isin(s_lost_deals) #a deal that has no Ritter row because it lost it (rules or hand fix)
    df_o2['recommended_permno_reason'] = df_o2['recommended_permno_reason'] + np.where(df_o2['lost_ritter_row'] & ~df_o2['deal_no'].isin(s_none), ' (lost ritter row)', '')
    print(df_o2['recommended_permno_reason'].value_counts().to_dict())

# %%
if __name__ == '__main__':
    #drop rule: a deal with no permno has no crsp data, so it is dropped (it goes to the removed table), except the deals with no recommended permno by hand (correct firm not found): they stay in the table with an empty recommended permno. one deal for each permno is checked at the end
    l_drop_cols = ['permnos', 'idt', 'c6', 'k6']
    f_keep = df_o2['recommended_permno'].notna() | df_o2['deal_no'].isin(s_none)
    df_step3 = df_o2[f_keep].drop(columns=l_drop_cols).sort_values('deal_no').reset_index(drop=True)
    df_removed = df_o2[~f_keep].drop(columns=l_drop_cols).assign(removed_by='no permno after step 3').sort_values('deal_no').reset_index(drop=True)
    s_per = df_step3.groupby('recommended_permno')['deal_no'].nunique()
    print(f"deals before {len(df_o2)} | with a permno {len(df_step3)} | dropped {len(df_removed)} | permnos with more than 1 deal {(s_per > 1).sum()}")
    print(df_removed['recommended_permno_reason'].value_counts().to_dict())
    df_step3.to_parquet(p_path / 'sdc' / f"sdc_ipo_step3_{v_outputfile}.parquet", index=False)
    df_removed.to_parquet(p_path / 'sdc' / f"sdc_ipo_step3_removed_{v_outputfile}.parquet", index=False)

# %%
if __name__ == '__main__':
    #the Ritter rows are kept track of in three tables, all columns of the assignment: added = the rows given to a deal by hand; removed = the rows taken away from a deal (the rule of two deals on one row, or a hand fix), with the reason and the deal that kept the row; unused = the Ritter rows no deal has, with the closest sdc deal by date (within 45 days) and the kept deal that has the same permno
    df_unused1 = df_ritter1[df_ritter1['od'].notna() & ~df_ritter1['rid'].isin(df_asg4['ritter_row'])].copy()
    df_near1 = duckdb.query("""
        SELECT r.rid, d.deal_no AS closest_sdc_deal_no, d.sname AS closest_sdc_name, d.idt AS closest_sdc_ipo_date, DATE_DIFF('day', r.od::DATE, d.idt::DATE) AS days_sdc_minus_ritter,
               ROW_NUMBER() OVER (PARTITION BY r.rid ORDER BY ABS(DATE_DIFF('day', r.od::DATE, d.idt::DATE)), d.deal_no) AS rn
        FROM df_unused1 r JOIN df_deals1 d ON d.idt BETWEEN r.od - INTERVAL 45 DAY AND r.od + INTERVAL 45 DAY
    """).df()
    df_unused2 = df_unused1.merge(df_near1[df_near1['rn'] == 1].drop(columns='rn'), on='rid', how='left')
    df_unused2 = df_unused2.merge(df_step3[['recommended_permno', 'deal_no']].rename(columns={'recommended_permno': 'rperm', 'deal_no': 'kept_deal_with_this_permno'}), on='rperm', how='left').rename(columns={'rid': 'ritter_row'})
    df_added1.to_parquet(p_path / 'sdc' / f"sdc_ipo_step3_ritter_added_{v_outputfile}.parquet", index=False)
    df_rem2.to_parquet(p_path / 'sdc' / f"sdc_ipo_step3_ritter_removed_{v_outputfile}.parquet", index=False)
    df_unused2.to_parquet(p_path / 'sdc' / f"sdc_ipo_step3_ritter_unused_{v_outputfile}.parquet", index=False)
    print(f"Ritter rows added by hand {len(df_added1)} | removed {len(df_rem2)} | unused {len(df_unused2)} (with a close sdc deal {df_unused2['closest_sdc_deal_no'].notna().sum()})")
