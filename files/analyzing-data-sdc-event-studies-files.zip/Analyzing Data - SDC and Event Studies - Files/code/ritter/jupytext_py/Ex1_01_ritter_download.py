# %%
import pandas as pd
import requests
import time
from pathlib import Path

# %%
#folder of the ritter file: change accordingly. the file is IPO-age.xlsx from jay ritter's website (page https://site.warrington.ufl.edu/ritter/ipo-data/). it is downloaded by hand or by this program (v_download=True)
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109\sdc\ritter')
v_url='https://site.warrington.ufl.edu/ritter/files/IPO-age.xlsx' #link read from the page 2026-11-09. downloaded by this program on 2026-11-09: http status 200, 1,346,041 bytes, the same file (same md5) as the one downloaded by hand on 2026-10-28. the download took 0.4 seconds
v_download=True #True = download the file (one request) and replace the file in p_path. False = no request is sent, the file already in p_path is read
d_header={'User-Agent': 'user/user@domain.com'} #name and email of whoever runs the program: change accordingly
v_sheet='1975-2025' #sheet with the ipos
v_outputfile='20261109'

# %%
#v_download=True downloads the file again every time the program runs (one request)
p_file = p_path / 'IPO-age.xlsx'
if v_download:
    p_path.mkdir(parents=True, exist_ok=True)
    v_t0 = time.time()
    r_get = requests.get(v_url, headers=d_header, timeout=120)
    print(f"http status {r_get.status_code}, {len(r_get.content)} bytes, {time.time() - v_t0:.1f} seconds")
    r_get.raise_for_status()
    p_file.write_bytes(r_get.content)
else:
    print(f"v_download is False: no request was sent, reading {p_file}")

# %%
#reads the sheet as it is, no rename and no filter. the matching with sdc is done in a later program
df_ritter1 = pd.read_excel(p_file, sheet_name=v_sheet)
print(df_ritter1.shape)
print(df_ritter1.columns.tolist())

# %%
#a column with mixed types (a ticker like TRUE read as a boolean, a dot in a number column) cannot be saved as parquet: those columns are saved as text, empty cells stay empty
df_ritter2 = df_ritter1.copy()
for v_col in df_ritter2.columns[df_ritter2.dtypes == 'object']:
    df_ritter2[v_col] = df_ritter2[v_col].map(lambda v: v if pd.isna(v) else str(v))
print(df_ritter2.dtypes.to_string())

# %%
df_ritter2.to_parquet(p_path / f"ritter_ipo_age_{v_outputfile}.parquet", index=False)
