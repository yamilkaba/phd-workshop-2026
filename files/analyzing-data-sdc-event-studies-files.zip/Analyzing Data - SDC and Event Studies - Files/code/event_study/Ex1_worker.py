#function used by Ex1_02_event_study_preprocess. it lives in its own file because the worker processes (windows starts them from scratch) must be able to import it
#keep this file in the same folder as the notebook
import os
import duckdb
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
from threadpoolctl import threadpool_limits


def init_worker(v_threads=1):
    #each worker process limits numpy's own threads (blas), so processes x threads never goes above the cpu count
    threadpool_limits(limits=v_threads)


def es_share(d_task):
    #one task per worker: the events of its permnos plus the calendar arrays. the worker reads the returns of its permnos from the parquet file v_chunk permnos at a time, runs the event study for each event and writes its own part files (daily, model)
    p_stock = d_task['p_stock']
    p_parts = Path(d_task['p_parts'])
    p_progress = Path(d_task['p_progress'])
    v_worker = d_task['worker']
    v_run_id = d_task['run_id']
    v_model = d_task['model']
    l_coef = d_task['l_coef'] #alpha and the factors of the model, in the order of the columns of fac (empty for ma)
    v_start_eday = d_task['start_eday']
    v_end_eday = d_task['end_eday']
    v_start_estday = d_task['start_estday']
    v_end_estday = d_task['end_estday']
    v_min_days = d_task['min_days']
    v_chunk = d_task['chunk']
    cal = d_task['cal'] #trading calendar: days since 1970-01-01, sorted
    bench = d_task['bench'] #benchmark return for each calendar day
    sub = d_task['sub'] #what is subtracted from the firm return for each calendar day (rf for firm_excess, zeros for firm)
    fac = d_task['fac'] #regressors for each calendar day: benchmark first, then the other factors of the model
    df_ev = d_task['df_events'] #event_id, permno, event_date and the extra columns, sorted by permno

    ncal = len(cal)
    cal_ns = cal.astype('datetime64[D]').astype('datetime64[ns]')
    l_extra = [c for c in df_ev.columns if c not in ('event_id', 'permno', 'event_date')]

    #columns of the model table, in the order they are written (the daily table is built further down)
    l_model_cols = ['event_id', 'run_id', 'permno', 'event_date', 'effdate', 'moved', 'moved_days', 'status']
    if v_model != 'ma':
        l_model_cols += ['est_start_date', 'est_end_date', 'est_tdays', 'nobs', 'rsq', 'rmse']
        for v_c in l_coef:
            l_model_cols += [f"{v_c}_coef", f"{v_c}_tstat"]
    l_date_cols = ['event_date', 'effdate', 'est_start_date', 'est_end_date']
    l_int_cols = ['moved', 'moved_days', 'est_tdays', 'nobs']

    con = duckdb.connect()
    con.execute(f"SET threads TO {int(d_task['threads_duckdb'])}") #duckdb has its own threads, threadpool_limits does not control them
    d_writer = {}
    v_done = 0

    for i in range(0, len(df_ev), v_chunk):
        #a chunk is v_chunk consecutive events (they are sorted by permno), so it holds about the same number of events every time. a permno cut between two chunks is read twice
        df_c = df_ev.iloc[i:i + v_chunk]
        a_eid = df_c['event_id'].to_numpy(dtype='int64')
        a_evday = df_c['event_date'].values.astype('datetime64[D]').astype('int64')
        d_idx = df_c.groupby('permno', sort=False).indices
        l_chunk = list(d_idx.keys())
        df_r =con.execute(f"SELECT permno, dlycaldt, dlyret FROM read_parquet('{p_stock}') WHERE permno IN ({','.join(str(int(p)) for p in l_chunk)})").df()
        d_r = df_r.groupby('permno').indices
        a_rday = df_r['dlycaldt'].values.astype('datetime64[D]').astype('int64')
        a_rret = df_r['dlyret'].to_numpy(dtype='float64', na_value=np.nan)

        l_d_eid, l_d_perm, l_d_day, l_d_date, l_d_ret, l_d_exp, l_d_bench = [], [], [], [], [], [], []
        l_model = []

        for v_permno in l_chunk:
            #returns of this permno on the calendar: one value per calendar day, NaN where the permno has no return, minus rf if firm_excess
            if v_permno in d_r:
                ix = d_r[v_permno]
                pos = np.minimum(np.searchsorted(cal, a_rday[ix]), ncal - 1)
                ok = cal[pos] == a_rday[ix]
                arr = np.full(ncal, np.nan)
                arr[pos[ok]] = a_rret[ix][ok]
                arr = arr - sub
            else:
                arr = None

            for j in d_idx[v_permno]:
                v_eid = int(a_eid[j])
                v_evday = int(a_evday[j])
                v_eff = int(np.searchsorted(cal, v_evday)) #first calendar day on or after the event date
                v_effday = np.nan
                if v_evday >= cal[0] and v_eff < ncal:
                    v_effday = int(cal[v_eff])
                v_moved = np.nan if np.isnan(v_effday) else int(v_effday != v_evday)
                v_moved_days = np.nan if np.isnan(v_effday) else int(v_effday - v_evday) #calendar days from the event date to the effdate
                v_status = None #stays None until a problem is found
                v_nobs = np.nan
                d_est = {} #estimation columns of the model table, empty if the model was not estimated
                a_exp = None

                if np.isnan(v_effday):
                    v_status = 'event_date outside calendar'
                elif arr is None:
                    v_status = 'permno not found'
                else:
                    w0 = v_eff + v_start_eday
                    w1 = v_eff + v_end_eday
                    if w0 < 0 or w1 >= ncal:
                        v_status = 'event window outside calendar'

                if v_status is None:
                    y_ev = arr[w0:w1 + 1]
                    v_total = w1 - w0 + 1
                    v_avail = int((~np.isnan(y_ev)).sum()) #days of the event window with a return
                    if v_model == 'ma':
                        a_exp = bench[w0:w1 + 1]
                    else:
                        #estimation window: trading days start_estday to end_estday around the effdate, cut at the ends of the calendar
                        e0 = max(v_eff + v_start_estday, 0)
                        e1 = min(v_eff + v_end_estday, ncal - 1)
                        ye = arr[e0:e1 + 1]
                        ok = ~np.isnan(ye)
                        v_nobs = int(ok.sum())
                        v_np = len(l_coef) #alpha plus the factors
                        v_required = max(v_min_days, v_np + 1) #at least one more observation than coefficients
                        d_est = {'est_start_date': int(cal[e0]), 'est_end_date': int(cal[e1]), 'est_tdays': e1 - e0 + 1, 'nobs': v_nobs}
                        if v_nobs < v_required:
                            v_status = f"insufficient obs estimation [available {v_nobs}, required {v_required}]"
                        else:
                            X = np.column_stack((np.ones(v_nobs), fac[e0:e1 + 1][ok]))
                            y = ye[ok]
                            try:
                                beta = np.linalg.lstsq(X, y, rcond=None)[0]
                                xtx_inv = np.linalg.inv(X.T @ X)
                            except np.linalg.LinAlgError:
                                v_status = 'regression failed'
                        if v_status is None:
                            resid = y - X @ beta
                            v_rss = float(resid @ resid)
                            v_tss = float(((y - y.mean()) ** 2).sum())
                            with np.errstate(all='ignore'):
                                a_se = np.sqrt(np.diag(xtx_inv) * v_rss / (v_nobs - v_np))
                                a_t = beta / a_se
                                v_rsq = 1 - v_rss / v_tss if v_tss > 0 else np.nan
                            a_exp = beta[0] + fac[w0:w1 + 1] @ beta[1:]
                            d_est['rsq'] = v_rsq
                            d_est['rmse'] = np.sqrt(v_rss / (v_nobs - v_np)) #standard deviation of the estimation residuals
                            for k, v_c in enumerate(l_coef):
                                d_est[f"{v_c}_coef"] = beta[k]
                                d_est[f"{v_c}_tstat"] = a_t[k]
                    if v_status is None:
                        if v_avail == 0:
                            v_status = 'missing event window'
                        elif v_avail < v_total:
                            v_status = f"partial event window [available {v_avail}, total {v_total}]" #still calculated, the days without a return are empty
                        else:
                            v_status = 'success'

                #model table: every event, with its status. the estimation columns are empty if the model was not estimated
                l_model.append({'event_id': v_eid, 'run_id': v_run_id, 'permno': v_permno, 'event_date': v_evday, 'effdate': v_effday, 'moved': v_moved, 'moved_days': v_moved_days, 'status': v_status, **d_est})
                if v_status == 'success' or v_status.startswith('partial'):
                    n = w1 - w0 + 1
                    l_d_eid.append(np.full(n, v_eid))
                    l_d_perm.append(np.full(n, v_permno))
                    l_d_day.append(np.arange(v_start_eday, v_end_eday + 1))
                    l_d_date.append(cal_ns[w0:w1 + 1])
                    l_d_ret.append(y_ev)
                    l_d_exp.append(a_exp)
                    l_d_bench.append(bench[w0:w1 + 1])

        #tables of this chunk of permnos, with fixed dtypes so every chunk has the same schema
        if l_d_eid:
            df_daily = pd.DataFrame({'event_id': np.concatenate(l_d_eid), 'permno': np.concatenate(l_d_perm), 'day': np.concatenate(l_d_day), 'date': np.concatenate(l_d_date),
                                     'return': np.concatenate(l_d_ret), 'expected_return': np.concatenate(l_d_exp), 'benchmark': np.concatenate(l_d_bench)})
        else:
            df_daily = pd.DataFrame({'event_id': np.zeros(0, 'int64'), 'permno': np.zeros(0, 'int64'), 'day': np.zeros(0, 'int64'), 'date': np.zeros(0, 'datetime64[ns]'),
                                     'return': np.zeros(0), 'expected_return': np.zeros(0), 'benchmark': np.zeros(0)})
        df_daily['abnormal_return'] = df_daily['return'] - df_daily['expected_return']
        df_daily['run_id'] = v_run_id
        df_daily = df_daily.astype({'event_id': 'int64', 'permno': 'int64', 'day': 'int64', 'run_id': 'int64'})

        l_tables = [('daily', df_daily)]
        for v_name, l_rows, l_cols in [('model', l_model, l_model_cols)]:
            df_t = pd.DataFrame(l_rows, columns=l_cols)
            for v_c in l_cols:
                if v_c in l_date_cols:
                    df_t[v_c] = pd.to_datetime(df_t[v_c].astype('float64'), unit='D')
                elif v_c in l_int_cols:
                    df_t[v_c] = df_t[v_c].astype('float64').astype('Int64')
                elif v_c == 'status':
                    df_t[v_c] = df_t[v_c].astype('string')
                else:
                    df_t[v_c] = df_t[v_c].astype('int64' if v_c in ('event_id', 'run_id', 'permno') else 'float64')
            if l_extra:
                df_t = df_t.merge(df_c[['event_id'] + l_extra], on='event_id', how='left')
            l_tables.append((v_name, df_t))

        for v_name, df_t in l_tables:
            if v_name not in d_writer:
                t_first = pa.Table.from_pandas(df_t, preserve_index=False)
                d_writer[v_name] = pq.ParquetWriter(p_parts / f"{v_name}_{v_worker}.parquet", t_first.schema, compression='zstd')
                d_writer[v_name].write_table(t_first)
            else:
                d_writer[v_name].write_table(pa.Table.from_pandas(df_t, schema=d_writer[v_name].schema, preserve_index=False))

        v_done += len(df_c)
        #progress: the main program adds up these files
        Path(p_progress, f"{os.getpid()}.txt").write_text(str(v_done))

    for v_w in d_writer.values():
        v_w.close()
    return {'worker': v_worker, 'events': len(df_ev), 'permnos': int(df_ev['permno'].nunique())}
