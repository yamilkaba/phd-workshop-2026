# %%
import os
import sys
import time
import shutil
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, wait

# %%
#Ex1_worker.py (same folder as this notebook) holds the function the worker processes import
sys.path.append(str(Path.cwd()))
import Ex1_worker

# %%
#folder with the parquet files downloaded in Ex1_01_wrds_download, and the folder where the results are saved: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
p_out=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109\event_study')
#events file: one row per event with permno and event_date (any other columns are ignored unless listed in l_keep_cols)
p_events=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109\event_study\events_quiet.parquet')
l_keep_cols=['deal_no', 'period', 'ipo_date', 'offer_amount_mil', 'initial_return_pct', 'n_managers', 'lead_share_pct'] #extra columns of the events file to keep in the model table, e.g. ['issuer','deal_type']

# %%
#parameters of the run. every table of the run is saved as es_<v_run_name>_<table>.parquet
v_run_name='quiet'
v_run_id=1 #id of this run in the params table, so tables of several runs can be stacked and matched
v_model='ma' #ma (market adjusted), capm, ff3, ff4, ff5, ff6
v_return_type='firm' #firm = daily return of the stock, firm_excess = daily return minus rf
v_benchmark='nasdaq' #mkt, mkt_excess (fama french market), crspvw, crspvw_excess, crspew, crspew_excess (crsp nyse/amex/nasdaq value- and equal-weighted index), nasdaq, nasdaq_excess (nasdaq composite, price return, from 1972-12-14). _excess = minus rf. the benchmark is the market return in every model: it is the expected return of ma and the market regressor of the others
v_start_eday=-5 #event window in trading days around the effdate (the first trading day on or after the event_date)
v_end_eday=119 #quiet period replication (run quiet): days -5 to +119 around the end of the quiet period (event window -5 to +5, estimation days +20 to +119 for the variance of the portfolio). settings of the Table 16f run (run ritter16f): events_16f.parquet, v_start_eday=1, v_end_eday=756 (3 years of trading days after the first closing price day)
v_start_estday=-268 #estimation window in trading days around the effdate. not used by ma
v_end_estday=-14
v_min_days=7 #minimum number of days with a return in the estimation window. not used by ma
v_nproc = os.cpu_count() #number of worker processes
v_threads_reg = 1 #controls how many logical cpus numpy uses in each worker
v_threads_duckdb = 1 #controls how many logical cpus duckdb uses to read the parquet file in each worker
v_chunk_permnos = 50 #permnos a worker reads at a time, on average. the chunk is cut by events: this number times the average events per permno. smaller = less memory

# %%
if __name__ == '__main__':
    assert v_model in ['ma', 'capm', 'ff3', 'ff4', 'ff5', 'ff6'], 'v_model'
    assert v_return_type in ['firm', 'firm_excess'], 'v_return_type'
    assert v_benchmark in ['mkt', 'mkt_excess', 'crspvw', 'crspvw_excess', 'crspew', 'crspew_excess', 'nasdaq', 'nasdaq_excess'], 'v_benchmark'
    assert v_start_eday <= v_end_eday, 'event window'
    #alpha and the factors of each model. the first factor (market) is the benchmark, whichever it is, the others come from the fama french file
    d_coef = {'ma': [], 'capm': ['alpha', 'market'], 'ff3': ['alpha', 'market', 'smb', 'hml'], 'ff4': ['alpha', 'market', 'smb', 'hml', 'umd'],
              'ff5': ['alpha', 'market', 'smb', 'hml', 'rmw', 'cma'], 'ff6': ['alpha', 'market', 'smb', 'hml', 'rmw', 'cma', 'umd']}
    l_coef = d_coef[v_model]
    p_out.mkdir(parents=True, exist_ok=True)
    p_parts = p_out / f"parts_{v_run_name}"
    p_progress = p_parts / 'progress'
    if p_parts.exists():
        shutil.rmtree(p_parts)
    p_progress.mkdir(parents=True)

    #params table: one row for the run. the estimation window is empty for ma because it is not used
    v_t_start = time.time() #run_time of the params table is measured from here to the end of the run
    df_params1 = pd.DataFrame({'run_id': [v_run_id], 'model': [v_model], 'return_type': [v_return_type], 'benchmark': [v_benchmark],
                               'start_eday': [v_start_eday], 'end_eday': [v_end_eday],
                               'start_estday': [pd.NA if v_model == 'ma' else v_start_estday], 'end_estday': [pd.NA if v_model == 'ma' else v_end_estday],
                               'min_days': [pd.NA if v_model == 'ma' else v_min_days],
                               'run_datetime': [pd.Timestamp.now().floor('s')]}).astype({'start_estday': 'Int64', 'end_estday': 'Int64', 'min_days': 'Int64'})

# %%
#events: one event_id for each permno and event_date combination
if __name__ == '__main__':
    df_events1 = pd.read_parquet(p_events)
    df_events2 = df_events1[['permno', 'event_date'] + l_keep_cols].copy()
    df_events2['permno'] = df_events2['permno'].astype('int64')
    df_events2['event_date'] = pd.to_datetime(df_events2['event_date']).dt.normalize().astype('datetime64[ns]')
    v_n_in = len(df_events2)
    df_events2 = df_events2.drop_duplicates(['permno', 'event_date']).sort_values(['permno', 'event_date']).reset_index(drop=True)
    df_events2.insert(0, 'event_id', np.arange(1, len(df_events2) + 1))
    print(f"events in: {v_n_in} | repeated permno and event_date dropped: {v_n_in - len(df_events2)} | events: {len(df_events2)} | permnos: {df_events2['permno'].nunique()}")

# %%
#benchmark, rf and factors on every trading day. the trading calendar is the days of these files (only days where everything needed exists)
#days are counted as trading days of this calendar, so the file with the stock returns does not define them
if __name__ == '__main__':
    v_need_ff = (v_model != 'ma') or (v_return_type == 'firm_excess') or (v_benchmark in ['mkt', 'mkt_excess']) or v_benchmark.endswith('_excess')
    if v_need_ff:
        #ff3 and ff4 use the original 3-factor file (factors_daily): the smb of the 5-factor file is built differently. the other models use fivefactors_daily. mktrf, hml, rf and umd are the same in both files
        v_ff_file = 'factors_daily' if v_model in ['ff3', 'ff4'] else 'fivefactors_daily'
        df_bench1 = pd.read_parquet(f"{p_path}/ff_all/{v_ff_file}.parquet").rename(columns={'date': 'dlycaldt'})
    if v_benchmark.startswith('crsp') or v_benchmark.startswith('nasdaq'):
        v_indno = {'crspvw': 1000080, 'crspew': 1000081, 'nasdaq': 1000503}[v_benchmark.split('_')[0]] #crsp nyse/amex/nasdaq value-weighted or equal-weighted, or the nasdaq composite
        v_retcol = 'dlyprcret' if v_indno == 1000503 else 'dlytotret' #the nasdaq composite has a price return only (no dividends)
        df_idx1 = pd.read_parquet(f"{p_path}/crsp_a_indexes/inddlyseriesdata_ind.parquet", columns=['indno', 'dlycaldt', v_retcol])
        df_idx2 = df_idx1[df_idx1['indno'] == v_indno][['dlycaldt', v_retcol]].rename(columns={v_retcol: 'crsp_ret'})
        df_bench1 = df_idx2.merge(df_bench1, on='dlycaldt', how='inner') if v_need_ff else df_idx2
    df_bench2 = df_bench1.copy()
    if v_benchmark == 'mkt':
        df_bench2['bench'] = df_bench2['mktrf'] + df_bench2['rf']
    elif v_benchmark == 'mkt_excess':
        df_bench2['bench'] = df_bench2['mktrf']
    elif v_benchmark.endswith('_excess'):
        df_bench2['bench'] = df_bench2['crsp_ret'] - df_bench2['rf']
    else:
        df_bench2['bench'] = df_bench2['crsp_ret']
    df_bench2['sub'] = df_bench2['rf'] if v_return_type == 'firm_excess' else 0.0
    l_fac_cols = ['bench'] + l_coef[2:] #market regressor (benchmark), then the other factors
    df_bench2 = df_bench2.dropna(subset=['bench', 'sub'] + l_coef[2:]).sort_values('dlycaldt').reset_index(drop=True)
    a_cal = df_bench2['dlycaldt'].values.astype('datetime64[D]').astype('int64')
    print(f"calendar: {df_bench2['dlycaldt'].min().date()} to {df_bench2['dlycaldt'].max().date()} | {len(df_bench2)} trading days")

# %%
#one task per worker: the events of its permnos. only events and the calendar are sent, the workers read the returns themselves
if __name__ == '__main__':
    #events are sorted by permno and event_date: each worker gets one block of consecutive events, the same number for every worker (a permno can be split between two workers)
    v_nw = min(v_nproc, len(df_events2))
    v_chunk = max(1, round(v_chunk_permnos * len(df_events2) / df_events2['permno'].nunique())) #events a worker reads at a time: about v_chunk_permnos permnos
    l_bounds = [round(i * len(df_events2) / v_nw) for i in range(v_nw + 1)]
    l_tasks = []
    for w, (v_start, v_end) in enumerate(zip(l_bounds[:-1], l_bounds[1:])):
        df_w = df_events2.iloc[v_start:v_end]
        l_tasks.append({'p_stock': f"{p_path}/crsp_a_stock/stkdlysecuritydata.parquet", 'p_parts': str(p_parts), 'p_progress': str(p_progress), 'worker': w, 'run_id': v_run_id,
                        'model': v_model, 'l_coef': l_coef, 'start_eday': v_start_eday, 'end_eday': v_end_eday, 'start_estday': v_start_estday, 'end_estday': v_end_estday,
                        'min_days': v_min_days, 'chunk': v_chunk, 'threads_duckdb': v_threads_duckdb, 'cal': a_cal, 'bench': df_bench2['bench'].to_numpy(), 'sub': df_bench2['sub'].to_numpy(dtype='float64'),
                        'fac': df_bench2[l_fac_cols].to_numpy(dtype='float64') if l_coef else np.zeros((len(a_cal), 0)), 'df_events': df_w})
    print(f"workers: {v_nw} | events per worker: min {min(len(d['df_events']) for d in l_tasks)}, max {max(len(d['df_events']) for d in l_tasks)} | events per read: {v_chunk}")

# %%
#every 30 seconds the events done by all the workers are added up from their progress files
if __name__ == '__main__':
    v_t0 = time.time()
    with ProcessPoolExecutor(v_nw, initializer=Ex1_worker.init_worker, initargs=(v_threads_reg,)) as executor:
        l_fut = [executor.submit(Ex1_worker.es_share, d_task) for d_task in l_tasks]
        while True:
            l_done, l_wait = wait(l_fut, timeout=30)
            v_n = sum(int(p_file.read_text() or 0) for p_file in p_progress.glob('*.txt'))
            print(f"{v_n} of {len(df_events2)} events | {time.time() - v_t0:.0f}s")
            if not l_wait:
                break
    l_res = [v_fut.result() for v_fut in l_fut]
    print(f"workers done in {time.time() - v_t0:.0f}s")

# %%
#joins the part files of the workers into one parquet file per table, one batch at a time so memory stays low
if __name__ == '__main__':
    for v_tbl in ['daily', 'model']:
        l_parts = sorted(p_parts.glob(f"{v_tbl}_*.parquet"))
        v_schema = pq.ParquetFile(l_parts[0]).schema_arrow
        with pq.ParquetWriter(p_out / f"es_{v_run_name}_{v_tbl}.parquet", v_schema, compression='zstd') as writer:
            for p_part in l_parts:
                for v_batch in pq.ParquetFile(p_part).iter_batches(batch_size=500000):
                    writer.write_batch(v_batch)
    shutil.rmtree(p_parts)
    #params table is saved last because it holds the time the run took (seconds, from the start of the run to here)
    df_params1['run_time'] = round(time.time() - v_t_start, 1)
    df_params1.to_parquet(p_out / f"es_{v_run_name}_params.parquet", index=False)

# %%
#summary: events by status
if __name__ == '__main__':
    df_model1 = pd.read_parquet(p_out / f"es_{v_run_name}_model.parquet", columns=['event_id', 'moved', 'status'])
    s_status = df_model1['status'].str.split(' \\[').str[0] #status without the counts in brackets
    print(f"events: {len(df_events2)} | in the daily table: {int(s_status.isin(['success', 'partial event window']).sum())} | not in the daily table: {len(df_model1) - int(s_status.isin(['success', 'partial event window']).sum())} | effdate after event_date: {int(df_model1['moved'].sum())}")
    print(s_status.value_counts())
