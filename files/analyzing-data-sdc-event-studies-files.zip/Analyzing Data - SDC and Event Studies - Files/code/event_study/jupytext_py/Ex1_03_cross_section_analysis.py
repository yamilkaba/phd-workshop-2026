# %%
import duckdb
import pandas as pd
from pathlib import Path

# %%
#folder where Ex1_02_event_study_preprocess saved its results, and the run to read: change accordingly
p_out=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109\event_study')
v_run_name='run1'
#windows of the CARs, (start_day, end_day) in trading days around the effdate. any number of windows, each one inside the days of the daily table
l_windows=[(-1, 1), (0, 1), (-2, 2)]
v_only_complete=True #True = keep only events that have returns on all days of all the windows. False = keep every event, with the car empty in the windows that are incomplete

# %%
#days captured by the event study run
df_days1 = duckdb.query(f"SELECT MIN(day) AS first_day, MAX(day) AS last_day FROM read_parquet('{p_out}/es_{v_run_name}_daily.parquet')").df()
v_first_day = int(df_days1['first_day'].iloc[0])
v_last_day = int(df_days1['last_day'].iloc[0])
df_windows1 = pd.DataFrame(l_windows, columns=['start_day', 'end_day'])
print(f"days in the daily table: {v_first_day} to {v_last_day}")

# %%
#checks every window before anything is calculated, and stops with a message for each window that is not inside the days of the daily table
l_msg = []
for v_start, v_end in l_windows:
    if v_start > v_end:
        l_msg.append(f"window ({v_start}, {v_end}): start_day is later than end_day")
        continue
    v_early = v_start < v_first_day
    v_late = v_end > v_last_day
    if v_early and v_late:
        l_msg.append(f"window ({v_start}, {v_end}): start_day {v_start} is earlier and end_day {v_end} is later than the days of the daily table (earliest day {v_first_day}, latest day {v_last_day})")
    elif v_early:
        l_msg.append(f"window ({v_start}, {v_end}): start_day {v_start} is earlier than the earliest day of the daily table ({v_first_day}); the latest day is {v_last_day}")
    elif v_late:
        l_msg.append(f"window ({v_start}, {v_end}): end_day {v_end} is later than the latest day of the daily table ({v_last_day}); the earliest day is {v_first_day}")
if l_msg:
    raise ValueError("windows outside the days of the daily table:\n" + "\n".join(l_msg))

# %%
#car = sum of abnormal_return over the days of the window. if any day of the window has no return the car is empty. ndays = days of the window with a return (used only to find the empty cars)
df_car1 = duckdb.query(f"""
    SELECT d.event_id, d.run_id, w.start_day, w.end_day,
           CASE WHEN COUNT(d.abnormal_return) = w.end_day - w.start_day + 1 THEN SUM(d.abnormal_return) END AS car,
           COUNT(d.abnormal_return) AS ndays
    FROM read_parquet('{p_out}/es_{v_run_name}_daily.parquet') d
    JOIN df_windows1 w ON d.day BETWEEN w.start_day AND w.end_day
    GROUP BY d.event_id, d.run_id, w.start_day, w.end_day
    ORDER BY d.event_id, w.start_day, w.end_day
""").df()
print(df_car1.shape, f"| events: {df_car1['event_id'].nunique()} | car empty: {int(df_car1['car'].isna().sum())}")

# %%
#wide: one row per event, one column per window named by its range (m = minus, p = plus, 0 = day 0), e.g. (-1, 1) is car_m1_p1 and (0, 1) is car_0_p1
df_car2 = df_car1.pivot(index=['event_id', 'run_id'], columns=['start_day', 'end_day'], values='car')
df_car2 = df_car2[list(dict.fromkeys(l_windows))] #columns in the order of l_windows
df_car2.columns = [f"car_{'m' if v_s < 0 else 'p' if v_s > 0 else ''}{abs(v_s)}_{'m' if v_e < 0 else 'p' if v_e > 0 else ''}{abs(v_e)}" for v_s, v_e in df_car2.columns]
df_car2 = df_car2.reset_index()
#permno, event_date and effdate come from the model table
df_model1 = pd.read_parquet(p_out / f"es_{v_run_name}_model.parquet", columns=['event_id', 'permno', 'event_date', 'effdate'])
df_car2 = df_car2.merge(df_model1, on='event_id', how='left')
l_car_cols = [c for c in df_car2.columns if c.startswith('car_')]
df_car2 = df_car2[['event_id', 'run_id', 'permno', 'event_date', 'effdate'] + l_car_cols]
v_n_events = len(df_car2)
if v_only_complete:
    df_car2 = df_car2.dropna(subset=l_car_cols).reset_index(drop=True)
print(f"events in the daily table: {v_n_events} | events kept: {len(df_car2)} | dropped for an incomplete window: {v_n_events - len(df_car2)}")
print(df_car2.shape, list(df_car2.columns))

# %%
df_car2.to_parquet(p_out / f"es_{v_run_name}_car.parquet", index=False)
