# %%
import duckdb
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

# %%
#folder where Ex1_02_event_study_preprocess saved its results, and the run to read: change accordingly
p_out=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109\event_study')
v_run_name='run1'
#windows of the cumulative abnormal returns, (start_day, end_day) in trading days around the effdate. any number of windows, each one inside the days of the daily table
l_windows=[(-1, 1), (0, 1), (-2, 2)]
v_chart=True #True = also saves the chart of the mean car by event day (from the by day table) as a png

# %%
#days captured by the event study run and the number of coefficients of its model (alpha plus the factors, 0 for ma)
df_days1 = duckdb.query(f"SELECT MIN(day) AS first_day, MAX(day) AS last_day FROM read_parquet('{p_out}/es_{v_run_name}_daily.parquet')").df()
v_first_day = int(df_days1['first_day'].iloc[0])
v_last_day = int(df_days1['last_day'].iloc[0])
v_ncoef = len([c for c in pd.read_parquet(p_out / f"es_{v_run_name}_model.parquet").columns if c.endswith('_coef')])
df_windows1 = pd.DataFrame(l_windows, columns=['start_day', 'end_day'])
print(f"days in the daily table: {v_first_day} to {v_last_day} | coefficients of the model: {v_ncoef}")

# %%
#checks every window before anything is calculated, and stops with a message for each window that is not inside the days of the daily table
l_msg = []
for v_start, v_end in l_windows:
    if v_start > v_end:
        l_msg.append(f"window ({v_start}, {v_end}): start_day is later than end_day")
        continue
    v_early = v_start < v_first_day
    v_late = v_end > v_last_day
    if v_early and v_late:
        l_msg.append(f"window ({v_start}, {v_end}): start_day {v_start} is earlier and end_day {v_end} is later than the days of the daily table (earliest day {v_first_day}, latest day {v_last_day})")
    elif v_early:
        l_msg.append(f"window ({v_start}, {v_end}): start_day {v_start} is earlier than the earliest day of the daily table ({v_first_day}); the latest day is {v_last_day}")
    elif v_late:
        l_msg.append(f"window ({v_start}, {v_end}): end_day {v_end} is later than the latest day of the daily table ({v_last_day}); the earliest day is {v_first_day}")
if l_msg:
    raise ValueError("windows outside the days of the daily table:\n" + "\n".join(l_msg))

# %%
#by day: the events are aggregated for each day of the event window. n = events with a return that day
#mean_car is cumulative from the first day of the table to the day: car = sum of the abnormal_return. only events with a return on every day up to that day are used. t_car = mean_car / (standard deviation of the car across events / sqrt(events used))
#t = mean / (standard deviation / sqrt(n)), across events. sar = abnormal_return / rmse of the event, t_sar is the t of the sar. patell_z = sum of the sar / sqrt(sum of the variances of the sar), variance = (nobs - ncoef) / (nobs - ncoef - 2)
#the sar columns are empty for ma (it has no estimation window, so no rmse)
df_day1 = duckdb.query(f"""
    WITH e AS (
        SELECT d.event_id, d.day, d.abnormal_return AS ar,
               CASE WHEN m.rmse > 0 AND m.nobs - {v_ncoef} > 2 THEN d.abnormal_return / m.rmse END AS sar,
               CASE WHEN m.rmse > 0 AND m.nobs - {v_ncoef} > 2 THEN (m.nobs - {v_ncoef}) / (m.nobs - {v_ncoef} - 2.0) END AS var_sar
        FROM read_parquet('{p_out}/es_{v_run_name}_daily.parquet') d
        JOIN read_parquet('{p_out}/es_{v_run_name}_model.parquet') m ON d.event_id = m.event_id
    ), c AS (
        SELECT *,
               COUNT(*) OVER w AS n_days,
               COUNT(ar) OVER w AS n_ar,
               SUM(ar) OVER w AS car_run
        FROM e
        WINDOW w AS (PARTITION BY event_id ORDER BY day ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
    )
    SELECT day,
           COUNT(ar) AS n,
           AVG(CASE WHEN n_ar = n_days THEN car_run END) AS mean_car,
           AVG(CASE WHEN n_ar = n_days THEN car_run END) / (STDDEV_SAMP(CASE WHEN n_ar = n_days THEN car_run END) / SQRT(COUNT(CASE WHEN n_ar = n_days THEN car_run END))) AS t_car,
           AVG(ar) AS mean_abnormal_return,
           AVG(ar) / (STDDEV_SAMP(ar) / SQRT(COUNT(ar))) AS t_abnormal_return,
           AVG(sar) AS mean_sar,
           AVG(sar) / (STDDEV_SAMP(sar) / SQRT(COUNT(sar))) AS t_sar,
           CASE WHEN COUNT(sar) > 0 THEN SUM(sar) / SQRT(SUM(CASE WHEN sar IS NOT NULL THEN var_sar END)) END AS patell_z
    FROM c
    GROUP BY day
    ORDER BY day
""").df()
print(df_day1.round(5).to_string(index=False))

# %%
#chart of the by day table: mean car by event day, with a vertical line on day 0
if v_chart:
    v_model = pd.read_parquet(p_out / f"es_{v_run_name}_params.parquet")['model'].iloc[0]
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(df_day1['day'], df_day1['mean_car'], color='tab:red', linewidth=2, label=f"Mean CAR ({v_first_day}, t)")
    ax.axvline(0, color='black', linewidth=1)
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda v, _: f"{v:.1%}"))
    ax.set_xlabel('Event time')
    ax.set_ylabel('Cumulative abnormal return')
    ax.set_title(f"Mean cumulative abnormal return around the event date ({v_model})")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.savefig(p_out / f"es_{v_run_name}_time_series_chart.png", dpi=150, bbox_inches='tight')
    plt.show()

# %%
#by window: car of each event = sum of abnormal_return over the window. only events with a return on all days of the window are used
#t_car = mean / (standard deviation / sqrt(n)). scar = car / (rmse * sqrt(days of the window)). patell_z = sum of the scar / sqrt(sum of the variances of the scar), variance = (nobs - ncoef) / (nobs - ncoef - 2)
df_win1 = duckdb.query(f"""
    WITH c AS (
        SELECT d.event_id, w.start_day, w.end_day, SUM(d.abnormal_return) AS car, m.rmse, m.nobs
        FROM read_parquet('{p_out}/es_{v_run_name}_daily.parquet') d
        JOIN df_windows1 w ON d.day BETWEEN w.start_day AND w.end_day
        JOIN read_parquet('{p_out}/es_{v_run_name}_model.parquet') m ON d.event_id = m.event_id
        GROUP BY d.event_id, w.start_day, w.end_day, m.rmse, m.nobs
        HAVING COUNT(d.abnormal_return) = w.end_day - w.start_day + 1
    ), s AS (
        SELECT start_day, end_day, car,
               CASE WHEN rmse > 0 AND nobs - {v_ncoef} > 2 THEN car / (rmse * SQRT(end_day - start_day + 1)) END AS scar,
               CASE WHEN rmse > 0 AND nobs - {v_ncoef} > 2 THEN (nobs - {v_ncoef}) / (nobs - {v_ncoef} - 2.0) END AS var_scar
        FROM c
    )
    SELECT start_day, end_day,
           COUNT(car) AS n,
           AVG(car) AS mean_car,
           AVG(car) / (STDDEV_SAMP(car) / SQRT(COUNT(car))) AS t_car,
           AVG(scar) AS mean_scar,
           CASE WHEN COUNT(scar) > 0 THEN SUM(scar) / SQRT(SUM(CASE WHEN scar IS NOT NULL THEN var_scar END)) END AS patell_z
    FROM s
    GROUP BY start_day, end_day
    ORDER BY start_day, end_day
""").df()
print(df_win1.round(5).to_string(index=False))

# %%
df_day1.to_parquet(p_out / f"es_{v_run_name}_time_series_day.parquet", index=False)
df_win1.to_parquet(p_out / f"es_{v_run_name}_time_series_window.parquet", index=False)
