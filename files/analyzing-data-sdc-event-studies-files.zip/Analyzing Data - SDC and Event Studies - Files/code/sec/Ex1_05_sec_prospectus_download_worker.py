#function used by Ex1_05_sec_prospectus_download. it lives in its own file because the worker processes (windows starts them from scratch) must be able to import it
#keep this file in the same folder as the notebook
import json
import re
import zlib
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path


def sec_share(d_task):
    #one task per worker: the names of its json files in the zip. the worker reads them v_chunk at a time and writes its own part files (entities, filings)
    p_zip = d_task['p_zip']
    p_parts = Path(d_task['p_parts'])
    p_progress = Path(d_task['p_progress'])
    v_worker = d_task['worker']
    v_chunk = d_task['chunk']
    r_forms = re.compile(d_task['forms'], re.I)
    l_files = d_task['files'] #name, position of the file in the zip, compressed size, compression type
    #the zip is opened as a plain file, not with zipfile.ZipFile: ZipFile loads the list of all the 996,030 entries (about 700 MB in every worker)
    f_zip = open(p_zip, 'rb')
    sch_ent = pa.schema([('cik', pa.int64()), ('name', pa.string()), ('entity_type', pa.string()), ('sic', pa.string()), ('state_inc', pa.string()), ('ein', pa.string()),
                         ('tickers', pa.string()), ('exchanges', pa.string()), ('former_names', pa.string())])
    sch_fil = pa.schema([('cik', pa.int64()), ('accession', pa.string()), ('filing_date', pa.string()), ('form', pa.string()), ('file_number', pa.string()), ('primary_document', pa.string())])
    wr_ent = pq.ParquetWriter(p_parts / f"entities_{v_worker}.parquet", sch_ent)
    wr_fil = pq.ParquetWriter(p_parts / f"filings_{v_worker}.parquet", sch_fil)
    v_done = 0
    v_n_fil = 0

    for i in range(0, len(l_files), v_chunk):
        l_ent = []
        l_fil = []
        for v_name, v_pos, v_csize, v_ctype in l_files[i:i + v_chunk]:
            #local header of the file: 30 bytes, the name and extra field lengths are at bytes 26 to 30, the data starts after them
            f_zip.seek(v_pos)
            v_hdr = f_zip.read(30)
            assert v_hdr[:4] == b'PK\x03\x04', v_name
            f_zip.seek(v_pos + 30 + int.from_bytes(v_hdr[26:28], 'little') + int.from_bytes(v_hdr[28:30], 'little'))
            v_raw = f_zip.read(v_csize)
            d_json = json.loads(zlib.decompress(v_raw, -15) if v_ctype == 8 else v_raw) #8 = deflate, 0 = stored
            v_cik = int(re.match(r'CIK(\d{10})', v_name).group(1))
            if 'filings' in d_json:   #main file: company information plus the recent filings
                l_ent.append((v_cik, d_json.get('name'), d_json.get('entityType'), d_json.get('sic'), d_json.get('stateOfIncorporation'), d_json.get('ein'),
                              '|'.join(str(v_t) for v_t in (d_json.get('tickers') or []) if v_t),
                              '|'.join(str(v_e) for v_e in (d_json.get('exchanges') or []) if v_e),
                              '|'.join(str(d_f.get('name') or '') for d_f in (d_json.get('formerNames') or []))))
                d_arr = d_json['filings']['recent']
            else:                      #extra file of a company with a long history: the lists are at the top level
                d_arr = d_json
            for v_j, v_form in enumerate(d_arr['form']):
                if r_forms.match(v_form):
                    l_fil.append((v_cik, d_arr['accessionNumber'][v_j], d_arr['filingDate'][v_j], v_form, d_arr['fileNumber'][v_j], d_arr['primaryDocument'][v_j]))
        if l_ent:
            wr_ent.write_table(pa.Table.from_pandas(pd.DataFrame(l_ent, columns=sch_ent.names), schema=sch_ent, preserve_index=False))
        if l_fil:
            wr_fil.write_table(pa.Table.from_pandas(pd.DataFrame(l_fil, columns=sch_fil.names), schema=sch_fil, preserve_index=False))
        v_n_fil += len(l_fil)
        v_done += len(l_files[i:i + v_chunk])
        (p_progress / f"{v_worker}.txt").write_text(str(v_done))

    f_zip.close()
    wr_ent.close()
    wr_fil.close()
    return {'worker': v_worker, 'files': v_done, 'filings': v_n_fil}
