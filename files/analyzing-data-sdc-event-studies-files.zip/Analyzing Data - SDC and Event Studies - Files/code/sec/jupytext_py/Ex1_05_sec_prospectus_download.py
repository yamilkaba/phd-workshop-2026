# %%
import duckdb
import html
import os
import re
import shutil
import sys
import time
import zipfile
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import requests
from concurrent.futures import ProcessPoolExecutor, wait
from datetime import datetime
from pathlib import Path

# %%
#this program gets the SEC prospectus of every SDC deal: reads the SEC bulk file, matches filings to deals, downloads the documents and finds the prospectus of the deals that had none. how it works: guides/SEC prospectus download.md
#folders. submissions.zip is the SEC bulk file, not downloaded by this program: download it with Ex1_01_sec_submissions_download or by hand: open https://www.sec.gov/Archives/edgar/daily-index/bulkdata/submissions.zip in a browser and save it as <p_sec>/submissions.zip, about 1.5 GB, do not unzip it. the steps and the rules of the SEC are in IPO table algorithm.md, Appendix, Step 4. change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109')
v_outputfile='20261104' #day of the sdc download. the deals are the deals of sdc_ipo_step3_<v_outputfile>.parquet (Ex1_04_match_ritter, the deals with a recommended permno), with their fields from sdc_ipo_step0_<v_outputfile>.parquet
p_sdc=p_path / 'sdc'
p_sec=p_path / 'sec'
p_doc=p_sec / 'documents' #documents of the first search, one file per deal: deal_no_accession.htm
p_doc_extra=p_sec / 'documents_extra' #documents of the filings found for the deals that had none
v_deals='sdc_ipo_prospectus_deals.parquet' #the deals the prospectus is got for (made by the next cell, in the sdc folder): deal_no, issue_date, name_full, sec_file_no, proceeds (USD millions, all markets), offer_price
v_start='1997-01-01' #deals issued from this date on (the sec has the filings electronically from the mid 1990s)
v_download=False #False = no request is sent to the sec, the program only says how many documents it would ask for. True = the downloads are made (about 2 requests per second, one at a time)
#reading the bulk file
v_zip='submissions.zip'
v_redo=False #False = skip the reading of the zip if the two parquets exist, True = read the zip again
#forms kept from the zip: prospectus type (424B, 253G, 497), registration statements and exchange registration (S-1, F-1, SB-2, N-2, F-10, 1-A, S-11, S-18, S-3, F-3, 8-A12) and the offering notices (QUALIF, DOS, DRS)
v_forms_read=r'^(424|253G|497|S-1|F-1|SB-2|N-2|F-10|1-A|S-11|S-18|S-3|QUALIF|8-A12|F-3|N-14|DOS|DRS)'
v_nproc = os.cpu_count() #number of worker processes
v_chunk = 2000 #files a worker reads before writing to its part file. smaller = less memory (20,000 used 14 GB of memory in 16 workers)
#finding the filing of each deal
v_window=7 #days around the issue date. if the deal table has a column ritter_date the window is also used around that date
v_jw=0.90 #jaro winkler (0 to 1) to find the companies whose name looks like the sdc name. a loose filter, the name score validates
v_name=90 #name score (0 to 100, the six measures of the matching programs) to accept a company as the same firm
v_reuse_scores=True #True = the name scores and the clean names saved by an earlier run are read and only what is not in them is made. False = everything is made again (use it after the name matching code changes)
p_scores_own=p_sdc / 'name_scores_own.parquet' #saved scores: sdc name and another name (the same store as Ex1_04_match_ritter)
p_work=p_sec / 'name_work' #temporary files of the workers
v_out='sec_deal_filing'
#choosing between filings of the same form and date by reading the covers
v_cover=20000 #characters of the text used for the features, the cover page and the text near it
v_short=20000 #a document with less text than this is a notice or a press release, not the prospectus
v_margin=2 #score difference between the best document and the next one to accept the choice. less than that goes to review
#downloading. the sec asks to declare who is running the script in the header (name and contact) and to stay under 10 requests per second. https://www.sec.gov/about/webmaster-frequently-asked-questions
d_header={'User-Agent': 'user/user@domain.com', 'Accept-Encoding': 'gzip, deflate'}
v_seed=1 #order of the documents in a download. None = by deal number, a number = random order with this seed, so a small test has deals of all the years
v_limit=None #documents to download in each run of the download, None is all. use a small number as a test
v_retry_404=False #False = a document that got 404 at every address in a previous run is not asked again. True = ask again
v_delay=0.5 #seconds after each request. the sec maximum is 10 requests per second, 0.5 is 2 per second
v_flush=200 #the log is written to the parquet file every this many requests, so a stopped run does not lose it
v_max_per_sec=8 #second guard: if this many requests went out in the last second the program waits. it should never be reached with v_delay, it is there in case v_delay is lowered
v_bytes=1000000 #only the first 1,000,000 bytes of each document are saved, the cover page and the text near it. some documents are over 10 MB
#deals with no filing: a second look in a wider window
v_before=45 #days before the issue date
v_after=120 #days after the issue date. follow on filings and refiled prospectuses are left out later, when the documents are read
v_forms_prospectus=r'^(424B|253G|497)' #prospectus type forms
v_rank={'424B4': 1, '424B1': 2, '424B2': 3, '424B5': 4, '424B3': 5} #order of the forms. 253G and 497 are ranked after them
#which of the filings of the deals that had none is the prospectus
v_cover_sup=2500 #characters of the text used to see if the document is a supplement
v_hand='sec_extra_hand_decisions.parquet' #decisions made by reading the document: deal_no, f_usable, reason, decided. a decision here replaces the rule

# %%
#the SEC bulk file is downloaded by hand. if it is not in the sec folder, and the two parquets made from it are not either, the program stops here and says what to do
if __name__ == '__main__':
    p_sec.mkdir(parents=True, exist_ok=True)
    if not ((p_sec / v_zip).exists() or ((p_sec / 'sec_entities.parquet').exists() and (p_sec / 'sec_filings_ipo_forms.parquet').exists())):
        raise FileNotFoundError(f"download this file by hand: open https://www.sec.gov/Archives/edgar/daily-index/bulkdata/submissions.zip in a browser and save it as {p_sec / v_zip} (about 1.5 GB, do not unzip it). the rules of the SEC are in IPO table algorithm.md, Appendix, Step 4")

# %%
#the deals the prospectus is got for: the deals of the final table (they have a recommended permno), with the fields the search needs from the step 0 table. the sec file number is 0 when sdc has none
if __name__ == '__main__':
    df_final1 = pd.read_parquet(p_sdc / f"sdc_ipo_step3_{v_outputfile}.parquet", columns=['deal_no'])
    df_s0 = pd.read_parquet(p_sdc / f"sdc_ipo_step0_{v_outputfile}.parquet", columns=['TR_NISdcDealNumber', 'TR_NIIssueDate', 'TR_NIIssuer', 'TR_NISecFileFormNum', 'TR_NIProceedsAmtAllMkts', 'TR_NIOfferPrice'])
    df_s0 = df_s0.rename(columns={'TR_NISdcDealNumber': 'deal_no', 'TR_NIIssueDate': 'issue_date', 'TR_NIIssuer': 'name_full', 'TR_NISecFileFormNum': 'sec_file_no', 'TR_NIProceedsAmtAllMkts': 'proceeds', 'TR_NIOfferPrice': 'offer_price'})
    df_deals1 = df_final1.merge(df_s0, on='deal_no', how='left')
    df_deals1['sec_file_no'] = pd.to_numeric(df_deals1['sec_file_no'], errors='coerce').fillna(0).astype('int64')
    df_deals1.to_parquet(p_sdc / v_deals, index=False)
    print(f"deals {len(df_deals1)} | issued from {v_start} on {(df_deals1['issue_date'] >= v_start).sum()} | with an sdc file number {(df_deals1['sec_file_no'] > 0).sum()}")

# %%
#Ex1_05_sec_prospectus_download_worker.py (same folder as this notebook) holds the function the worker processes import
sys.path.append(str(Path.cwd()))
sys.path.append(str(Path.cwd().parent / 'shared')) #the name matching is the shared one (one copy for every program)
import Ex1_05_sec_prospectus_download_worker
import Ex1_name_score as ns

# %%
#the zip has one json per company (CIK0001848097.json) and extra json files for the companies with a long history (CIK0000005981-submissions-001.json)
#the main file has the company information and the recent filings, the extra files only have lists of filings. this program is run once and everything else reads the two parquets
#nothing is requested from the sec, it only reads the zip
if __name__ == '__main__':
    v_run = v_redo or not ((p_sec / 'sec_entities.parquet').exists() and (p_sec / 'sec_filings_ipo_forms.parquet').exists())
    if not v_run:
        print('the parquets already exist, set v_redo=True to read the zip again')

# %%
#the smallest slice is one json file. the size of every file is in the list of the zip, so the files are sorted from the largest to the smallest and dealt out one by one:
#the largest to worker 1, the second to worker 2, ... the n-th to worker n, then the next one to worker n again and back to worker 1, and so on (1 to n, n to 1). every worker gets the same number of files and almost the same number of bytes
if __name__ == '__main__' and v_run:
    p_parts = p_sec / 'parts_sec_read'
    p_progress = p_parts / 'progress'
    if p_parts.exists():
        shutil.rmtree(p_parts)
    p_progress.mkdir(parents=True)
    #the list of the zip is read here, once. each worker gets the position and the compressed size of its files and reads those bytes itself (see Ex1_05_sec_prospectus_download_worker.py)
    df_files = pd.DataFrame([(v_i.filename, v_i.file_size, v_i.header_offset, v_i.compress_size, v_i.compress_type) for v_i in zipfile.ZipFile(p_sec / v_zip).infolist() if v_i.filename.startswith('CIK')],
                            columns=['name', 'size', 'pos', 'csize', 'ctype'])
    df_files = df_files.sort_values('size', ascending=False, kind='stable').reset_index(drop=True)
    v_pos = df_files.index % (2 * v_nproc) #position in a round trip of 2n files: 0 to n-1 going up, n to 2n-1 coming back
    df_files['worker'] = v_pos.where(v_pos < v_nproc, 2 * v_nproc - 1 - v_pos)
    l_tasks = [{'p_zip': str(p_sec / v_zip), 'p_parts': str(p_parts), 'p_progress': str(p_progress), 'worker': v_w, 'chunk': v_chunk, 'forms': v_forms_read,
                'files': list(zip(df_g['name'], df_g['pos'], df_g['csize'], df_g['ctype']))} for v_w, df_g in df_files.groupby('worker')]
    df_load = df_files.groupby('worker')['size'].agg(['size', 'sum'])
    print(f"files: {len(df_files)} | workers: {v_nproc} | files per worker: {df_load['size'].min()} to {df_load['size'].max()} | MB per worker: {df_load['sum'].min() / 1e6:.0f} to {df_load['sum'].max() / 1e6:.0f}")

# %%
#every 30 seconds the files done by all the workers are added up from their progress files
if __name__ == '__main__' and v_run:
    v_t0 = time.time()
    with ProcessPoolExecutor(v_nproc) as executor:
        l_fut = [executor.submit(Ex1_05_sec_prospectus_download_worker.sec_share, d_task) for d_task in l_tasks]
        while True:
            l_done, l_wait = wait(l_fut, timeout=30)
            v_n = sum(int(p_file.read_text() or 0) for p_file in p_progress.glob('*.txt'))
            print(f"{v_n} of {len(df_files)} files | {time.time() - v_t0:.0f}s")
            if not l_wait:
                break
    l_res = [v_fut.result() for v_fut in l_fut]
    print(f"workers done in {time.time() - v_t0:.0f}s | filings kept: {sum(d_r['filings'] for d_r in l_res)}")

# %%
#joins the part files of the workers into the two parquet files, one batch at a time so memory stays low
if __name__ == '__main__' and v_run:
    for v_tbl, v_out in [('entities', 'sec_entities'), ('filings', 'sec_filings_ipo_forms')]:
        l_parts = sorted(p_parts.glob(f"{v_tbl}_*.parquet"))
        v_schema = pq.ParquetFile(l_parts[0]).schema_arrow
        with pq.ParquetWriter(p_sec / f"{v_out}.parquet", v_schema, compression='zstd') as writer:
            for p_part in l_parts:
                for v_batch in pq.ParquetFile(p_part).iter_batches(batch_size=500000):
                    writer.write_batch(v_batch)
    shutil.rmtree(p_parts)
    print('companies:', pq.ParquetFile(p_sec / 'sec_entities.parquet').metadata.num_rows, '| filings kept:', pq.ParquetFile(p_sec / 'sec_filings_ipo_forms.parquet').metadata.num_rows)

# %%
#deals: issue date, name and the sec file number that sdc gives. sdc has only the number (255461), the sec writes it 333-255461 (other prefixes are not handled here)
if __name__ == '__main__':
    df_deal = pd.read_parquet(p_sdc / v_deals, columns=['deal_no', 'issue_date', 'name_full', 'sec_file_no'])
    df_deal = df_deal[df_deal['issue_date'] >= v_start].copy()
    df_deal['issue_date'] = pd.to_datetime(df_deal['issue_date'])
    df_deal['file_number'] = np.where(df_deal['sec_file_no'] > 0, '333-' + df_deal['sec_file_no'].astype(str), None)
    if 'ritter_date' in df_deal.columns:
        df_deal['ritter_date'] = pd.to_datetime(df_deal['ritter_date'])
    else:
        df_deal['ritter_date'] = pd.Series(pd.NaT, index=df_deal.index, dtype='datetime64[ns]')
    print('deals:', len(df_deal), '| with an sdc file number:', df_deal['file_number'].notna().sum())

# %%
#filings of prospectus type: 424B (final prospectus and supplements), 253G (regulation A offering circular), 497 (funds)
#form_rank orders the documents of a company: 424B4 is the final prospectus of an ipo, the others are supplements or other offerings
if __name__ == '__main__':
    con = duckdb.connect()
    con.register('df_deal', df_deal)
    con.execute(f"""create table fil as
        select cik, accession, cast(filing_date as date) filing_date, form, file_number, primary_document,
        case when form='424B4' then 1 when form='424B1' then 2 when form='424B2' then 3 when form='424B5' then 4 when form='424B3' then 5
             when regexp_matches(form,'^253G') then 6 when form like '497AD%' then 8 else 7 end form_rank
        from read_parquet('{p_sec}/sec_filings_ipo_forms.parquet') where regexp_matches(form,'^(424B|253G|497)')""")
    con.execute(f"create table ent as select cik, name, former_names, sic, state_inc, tickers from read_parquet('{p_sec}/sec_entities.parquet')")
    #all the names of a company: the current one and the former ones, lowercase letters and numbers only
    con.execute("""create table nm as
        select cik, lower(regexp_replace(name,'[^A-Za-z0-9 ]','','g')) nn from ent
        union all select cik, lower(regexp_replace(trim(f),'[^A-Za-z0-9 ]','','g')) nn
        from (select cik, unnest(string_split(former_names,'|')) f from ent where former_names <> '') where trim(f) <> ''""")
    v_win = f"""(abs(date_diff('day', f.filing_date, d.issue_date)) <= {v_window}
                 or (d.ritter_date is not null and abs(date_diff('day', f.filing_date, d.ritter_date)) <= {v_window}))"""

# %%
#the name matching is the shared algorithm (Ex1_name_score.py, section "Name scoring algorithm" of IPO table algorithm.md). one pool of workers for the whole program. every company name (current and former) is cleaned once and saved; the file name has the size and time of sec_entities.parquet, so it is made again only when the zip was read again
if __name__ == '__main__':
    p_work.mkdir(parents=True, exist_ok=True)
    ex = ProcessPoolExecutor(v_nproc, initializer=ns.init_light)
    p_ent = p_sec / 'sec_entities.parquet'
    p_names_clean = p_sec / f"sec_names_clean_{p_ent.stat().st_size}_{p_ent.stat().st_mtime_ns}.parquet"
    v_t0 = time.time()
    if v_reuse_scores and p_names_clean.exists():
        df_nmc = pd.read_parquet(p_names_clean)
    else:
        df_e = pd.read_parquet(p_ent, columns=['cik', 'name', 'former_names'])
        df_fn = df_e[df_e['former_names'] != ''][['cik', 'former_names']].assign(name=lambda d: d['former_names'].str.split('|')).explode('name')[['cik', 'name']]
        df_nm0 = pd.concat([df_e[['cik', 'name']], df_fn])
        df_nm0['name'] = df_nm0['name'].str.strip()
        df_nm0 = df_nm0[df_nm0['name'].fillna('') != ''].drop_duplicates()
        df_cl = ns.run_clean(ex, df_nm0[['name']].drop_duplicates(), v_nproc, p_work)
        df_nmc = df_nm0.merge(df_cl, on='name')
        df_nmc.to_parquet(p_names_clean, index=False)
    print(f"company names {len(df_nmc)} | {time.time() - v_t0:.0f} seconds")

# %%
#the two routes are run for every deal, independently
#route A: the filings under the sdc file number inside the window
#route B: the filings inside the window of the companies whose name (current or former) is the sdc name. the six measure name score of the matching programs is used to validate later, here jaro winkler only finds the company
if __name__ == '__main__':
    con.execute(f"create table a as select d.deal_no, f.cik from df_deal d join fil f on f.file_number = d.file_number where {v_win}")
    #the date window is written as plain comparisons on the date columns (between) so duckdb can use a range join. the same window written with abs(date_diff(...)) and an or took 88 seconds, this takes 1.5 seconds and gives the same pairs (tested 2026-11-09)
    con.execute(f"""create table dc as select deal_no, cik from (
        select d.deal_no, f.cik from df_deal d join fil f on f.filing_date between cast(d.issue_date as date) - {v_window} and cast(d.issue_date as date) + {v_window}
        union all
        select d.deal_no, f.cik from df_deal d join fil f on f.filing_date between cast(d.ritter_date as date) - {v_window} and cast(d.ritter_date as date) + {v_window}) group by 1, 2""")
    con.execute("""create table dcn as select dc.deal_no, dc.cik, max(jaro_winkler_similarity(lower(regexp_replace(d.name_full,'[^A-Za-z0-9 ]','','g')), nm.nn)) jw
        from dc join df_deal d on d.deal_no = dc.deal_no join nm on nm.cik = dc.cik group by 1, 2""")
    con.execute(f"create table keep_ck as select deal_no, cik from dcn where jw >= {v_jw} union select distinct deal_no, cik from a")
    print('route A, deals with a filing:', con.sql('select count(distinct deal_no) from a').fetchone()[0], '| route B, deals with a filing:', con.sql(f'select count(distinct deal_no) from dcn where jw >= {v_jw}').fetchone()[0])

# %%
#all the filings of the companies found, inside the window. in_a is true when the filing is under the sdc file number
if __name__ == '__main__':
    df_cand = con.sql(f"""select k.deal_no, f.cik, f.accession, f.filing_date, f.form, f.form_rank, f.file_number, f.primary_document, n.jw name_jw,
        coalesce(f.file_number = d.file_number, false) in_a,
        least(abs(date_diff('day', f.filing_date, d.issue_date)), coalesce(abs(date_diff('day', f.filing_date, d.ritter_date)), 9999)) gap
        from keep_ck k join df_deal d on d.deal_no = k.deal_no join fil f on f.cik = k.cik and {v_win}
        join dcn n on n.deal_no = k.deal_no and n.cik = k.cik""").df()
    print('candidate filings:', len(df_cand), '| deals:', df_cand['deal_no'].nunique())

# %%
#the company of each deal. a company whose name matches is preferred, and among those the one that has filings under the sdc number.
#when no company matches the name the one of the sdc number is kept and f_name_ok is false
if __name__ == '__main__':
    df_co = df_cand.groupby(['deal_no', 'cik']).agg(jw=('name_jw', 'max'), in_a=('in_a', 'max')).reset_index()
    #name score of the sdc name against every name of the company (current and former), the best one: the shared name matching algorithm, the same scores as the steps for CRSP and Ritter. the pairs (sdc name, company name) are scored once on the pool and saved in the same store as the Ritter pairs (sdc name, Ritter name): a run scores only the pairs that are not in it
    df_names = df_nmc[df_nmc['cik'].isin(df_co['cik'])][['cik', 'name']].rename(columns={'name': 'ename'})
    df_pairs = df_co[['deal_no', 'cik']].merge(df_deal[['deal_no', 'name_full']], on='deal_no').merge(df_names, on='cik')
    df_pr = df_pairs[['name_full', 'ename']].dropna().drop_duplicates().rename(columns={'name_full': 'sname', 'ename': 'rname'})
    df_sc_own = pd.read_parquet(p_scores_own) if (v_reuse_scores and p_scores_own.exists()) else pd.DataFrame({'sname': pd.Series(dtype='str'), 'rname': pd.Series(dtype='str'), 'score': pd.Series(dtype='float64')})
    df_todo = df_pr.merge(df_sc_own[['sname', 'rname']], on=['sname', 'rname'], how='left', indicator=True).query("_merge == 'left_only'")[['sname', 'rname']]
    v_t0 = time.time()
    df_new = ns.run_scores(ex, df_todo, 'own', v_nproc, p_work)
    print(f"pairs {len(df_pr)} | scored now {len(df_todo)} | saved {len(df_sc_own)} | {time.time() - v_t0:.0f} seconds")
    df_sc_own = pd.concat([df_sc_own, df_new[['sname', 'rname', 'score']]], ignore_index=True).drop_duplicates(['sname', 'rname'])
    df_sc_own.to_parquet(p_scores_own, index=False)
    df_pairs = df_pairs.merge(df_sc_own.rename(columns={'sname': 'name_full', 'rname': 'ename'}), on=['name_full', 'ename'], how='left')
    df_co = df_co.merge(df_pairs.groupby(['deal_no', 'cik'])['score'].max().rename('name_score').reset_index(), on=['deal_no', 'cik'], how='left')
    df_co['name_score'] = df_co['name_score'].fillna(0)
    df_co['name_ok'] = df_co['name_score'] >= v_name
    df_co = df_co.sort_values(['deal_no', 'name_ok', 'in_a', 'name_score', 'cik'], ascending=[True, False, False, False, True])
    df_co['n_companies_ok'] = df_co.groupby('deal_no')['name_ok'].transform('sum')
    df_co.to_parquet(p_sec / 'sec_deal_companies.parquet', index=False) #every company found for each deal, to review the deals with more than one
    df_co_pick = df_co.drop_duplicates('deal_no')
    df_co_a = df_co[df_co['in_a']].groupby('deal_no')['cik'].apply(set).rename('ciks_sdc_number').reset_index()
    df_co_pick = df_co_pick.merge(df_co_a, on='deal_no', how='left')
    df_co_pick['f_sdc_number_other_company'] = [(isinstance(v_set, set) and v_cik not in v_set) for v_set, v_cik in zip(df_co_pick['ciks_sdc_number'], df_co_pick['cik'])]
    df_co_pick['route'] = np.select([df_co_pick['in_a'] & df_co_pick['name_ok'], df_co_pick['in_a']], ['sdc number and name', 'sdc number only'], default='name only')
    print(df_co_pick['route'].value_counts().to_string())
    print('the sdc number points to another company than the name:', df_co_pick['f_sdc_number_other_company'].sum(), '| more than one company with the name:', (df_co_pick['n_companies_ok'] > 1).sum())

# %%
#one filing per deal inside the company: best form first, then a filing under the sdc number, then the closest to the issue date
#f_tie is true when another filing has the same form, the same date and the same sdc number status. those need a look at the documents (the download and cover steps below)
if __name__ == '__main__':
    df_c = df_cand.merge(df_co_pick[['deal_no', 'cik']], on=['deal_no', 'cik'])
    df_c = df_c.sort_values(['deal_no', 'form_rank', 'in_a', 'gap', 'filing_date', 'accession'], ascending=[True, True, False, True, True, True])
    df_c['is_pick'] = ~df_c.duplicated('deal_no')
    df_k = df_c[df_c['is_pick']][['deal_no', 'form_rank', 'filing_date', 'in_a']].rename(columns={'form_rank': 'k_rank', 'filing_date': 'k_date', 'in_a': 'k_in_a'})
    df_c = df_c.merge(df_k, on='deal_no')
    df_c['f_tie_member'] = (df_c['form_rank'] == df_c['k_rank']) & (df_c['filing_date'] == df_c['k_date']) & (df_c['in_a'] == df_c['k_in_a'])
    df_c['n_tied'] = df_c.groupby('deal_no')['f_tie_member'].transform('sum')
    df_c['n_candidates'] = df_c.groupby('deal_no')['accession'].transform('size')
    df_c = df_c.drop(columns=['k_rank', 'k_date', 'k_in_a'])
    #link to the document. the filings after about 2001 have a main document (cik, accession without dashes, document name). the older ones have no document name in the sec file and are one text file named with the accession number
    v_dir = 'https://www.sec.gov/Archives/edgar/data/' + df_c['cik'].astype(str) + '/'
    df_c['url'] = np.where(df_c['primary_document'].fillna('') != '', v_dir + df_c['accession'].str.replace('-', '') + '/' + df_c['primary_document'], v_dir + df_c['accession'] + '.txt')
    df_c.to_parquet(p_sec / 'sec_deal_candidates.parquet', index=False)
    df_pick = df_c[df_c['is_pick']].drop(columns=['is_pick'])
    print('deals with one filing:', len(df_pick), 'of', len(df_deal), '| ties (same form, date and number status):', (df_pick['n_tied'] > 1).sum())

# %%
#the filing against the first prospectus type filing of the same file number. a filing long after the first is a follow on or a supplement, not the first offering
if __name__ == '__main__':
    con.register('df_pick', df_pick)
    df_out = con.sql(f"""select p.deal_no, r.route, p.n_candidates, p.n_tied > 1 f_tie, p.cik, p.accession, p.form, p.filing_date, p.file_number, p.primary_document,
        p.url,
        d.name_full sdc_name, e.name sec_name, e.former_names, e.sic, e.state_inc, e.tickers sec_tickers, d.issue_date,
        date_diff('day', d.issue_date, p.filing_date) days_filing_minus_issue, r.name_score,
        date_diff('day', (select min(x.filing_date) from fil x where x.cik = p.cik and x.file_number = p.file_number), p.filing_date) days_after_first_filing,
        r.f_sdc_number_other_company, r.n_companies_ok
        from df_pick p join df_deal d on d.deal_no = p.deal_no join (select * from df_co_pick) r on r.deal_no = p.deal_no
        left join ent e on e.cik = p.cik""").df()
    df_out['f_name_ok'] = df_out['name_score'] >= v_name
    df_out['f_date_ok'] = df_out['days_filing_minus_issue'].abs() <= v_window
    df_out['f_later_filing'] = df_out['days_after_first_filing'] > v_window
    df_out.to_parquet(p_sec / f'{v_out}.parquet', index=False)
    print(df_out['route'].value_counts().to_string())
    print('name ok:', df_out['f_name_ok'].sum(), '| date within the window:', df_out['f_date_ok'].sum(), '| tie:', df_out['f_tie'].sum(), '| later filing than the first:', df_out['f_later_filing'].sum())

# %%
#downloads filings to a folder. it is used three times below (the tied filings, the picked filing of every deal, the filings found for the deals that had none)
#df_in has deal_no, accession, cik, url, form, filing_date, file_number, primary_document. a document already on disk is skipped
#one request at a time. a failed download is removed so it is tried again in the next run. every request is written in the log
#two addresses for each document: the main document of the filing and, if the sec answers 404 (some filings of 2000 and 2001 list a main document that does not exist, for example 0001.txt), the whole filing as one text file named with the accession number
#the program stops at the first 429 (too many requests) or 403 (forbidden) answer of the sec, it does not keep asking
if __name__ == '__main__':
    def sec_download(df_in, p_dir, v_set):
        os.makedirs(p_dir, exist_ok=True)
        df_todo = df_in.sort_values(['deal_no', 'accession']).copy()
        df_todo = df_todo[np.array([not (p_dir / f'{v_d}_{v_a}.htm').exists() for v_d, v_a in zip(df_todo['deal_no'], df_todo['accession'])], dtype=bool)] #a boolean array, not a list: an empty list would be read as an empty list of columns
        v_log = p_sec / 'sec_download_log.parquet' #every request of every run, one row each. the file is read and written again at the end of each run (parquet cannot be appended)
        s_404 = set() #a document whose addresses all answered 404 in a previous run is not asked again. v_retry_404=True asks again
        if v_log.exists() and not v_retry_404:
            df_old = pd.read_parquet(v_log)
            s_404 = set(df_old.loc[df_old['status'].astype(str) == '404', 'url'])
        df_todo['cik'] = df_todo['cik'].astype('int64') #a whole number: as a decimal (1100395.0) the address is wrong and the sec answers 403
        df_todo['alt'] = 'https://www.sec.gov/Archives/edgar/data/' + df_todo['cik'].astype(str) + '/' + df_todo['accession'] + '.txt' #second address, the whole filing
        v_n_before = len(df_todo)
        df_todo = df_todo[np.array([not ((v_u in s_404) and (v_a in s_404)) for v_u, v_a in zip(df_todo['url'], df_todo['alt'])], dtype=bool)]
        v_n_404 = v_n_before - len(df_todo)
        if v_seed is not None:
            df_todo = df_todo.sample(frac=1, random_state=v_seed)
        if v_limit is not None:
            df_todo = df_todo.head(v_limit)
        print(f'{v_set}: filings in the table {len(df_in)} | not asked again (404 at every address in the log) {v_n_404} | documents to download {len(df_todo)}')
        if not v_download:
            print('v_download is False: no request was sent')
            return
        l_log = []
        l_sent = [] #times of the requests of the last second
        v_stop = False
        v_n_done = 0
        v_t0 = time.time()
        for v_row in df_todo.itertuples():
            v_file = p_dir / f'{v_row.deal_no}_{v_row.accession}.htm'
            for v_url in ([v_row.url] if v_row.url == v_row.alt else [v_row.url, v_row.alt]):   #old filings without a main document name already use the whole filing as the first address
                v_now = time.time()
                l_sent = [v_t for v_t in l_sent if v_now - v_t < 1.0]
                if len(l_sent) >= v_max_per_sec:   #wait until the oldest request of the last second is one second old
                    time.sleep(1.0 - (v_now - l_sent[0]))
                l_sent.append(time.time())
                v_status = ''
                v_size = 0
                try:
                    with requests.get(v_url, headers=d_header, stream=True, timeout=60) as r_get:
                        v_status = r_get.status_code
                        if r_get.status_code == 200:
                            with open(v_file, 'wb') as f_out:
                                for v_bytes_chunk in r_get.iter_content(chunk_size=65536):
                                    f_out.write(v_bytes_chunk)
                                    v_size += len(v_bytes_chunk)
                                    if v_size >= v_bytes:   #enough of the document, the rest is not downloaded
                                        break
                            print(f'saved {v_file.name} ({v_size} bytes) from {v_url}')
                        else:
                            print(f'failed {v_file.name}, http status {r_get.status_code}, {v_url}')
                except Exception as e:
                    v_status = f'error: {e}'
                    print(f'error {v_file.name}: {e}')
                    if v_file.exists():
                        os.remove(v_file)
                l_log.append({'time': datetime.now().isoformat(timespec='seconds'), 'deal_no': v_row.deal_no, 'url': v_url, 'status': str(v_status), 'bytes': v_size})
                time.sleep(v_delay)   #the sec limit
                if v_status in (403, 429):
                    print(f'the sec answered {v_status}, stopping. wait before the next run and check the header and the rate')
                    v_stop = True
                    break
                if v_status != 404:   #saved, or an error that is not a missing document: the second address is only for a 404
                    break
            v_n_done += 1
            if len(l_log) >= v_flush:   #write the log so far
                df_log = pd.DataFrame(l_log)
                df_log = pd.concat([pd.read_parquet(v_log), df_log], ignore_index=True) if v_log.exists() else df_log
                df_log.to_parquet(v_log, index=False)
                l_log = []
            if v_n_done % 100 == 0:
                print(f'--- {v_n_done} of {len(df_todo)} documents | {time.time() - v_t0:.0f}s')
            if v_stop:
                break
        if l_log:   #the rest of the log is added to the file
            df_log = pd.DataFrame(l_log)
            df_log = pd.concat([pd.read_parquet(v_log), df_log], ignore_index=True) if v_log.exists() else df_log
            df_log.to_parquet(v_log, index=False)
            print(df_log['status'].value_counts().to_string())
        #the documents of this run that are not on disk, with the last answer of the sec for each address (404 = not found, other numbers = server problems, empty = not asked in this log). written again at the end of every run
        df_all_log = pd.read_parquet(v_log) if v_log.exists() else pd.DataFrame({'url': [], 'status': []})
        d_last = dict(zip(df_all_log['url'], df_all_log['status'].astype(str))) #the log is in time order: the last answer of each address
        df_miss = df_todo[np.array([not (p_dir / f'{v_d}_{v_a}.htm').exists() for v_d, v_a in zip(df_todo['deal_no'], df_todo['accession'])], dtype=bool)].copy()
        df_miss['status_main'] = df_miss['url'].map(d_last)
        df_miss['status_whole_filing'] = df_miss['alt'].map(d_last)
        df_miss.to_parquet(p_sec / f'sec_download_missing_{v_set}.parquet', index=False)
        print('documents of this run not on disk:', len(df_miss), f'| written to sec_download_missing_{v_set}.parquet')

# %%
#filings to download first: the deals where two or more filings have the same form and date (f_tie). the cover of each one is read below to choose the right one
if __name__ == '__main__':
    df_cand_t = pd.read_parquet(p_sec / 'sec_deal_candidates.parquet')
    sec_download(df_cand_t[df_cand_t['f_tie_member'] & (df_cand_t['n_tied'] > 1)], p_doc, 'ties')

# %%
#the deals where two or more filings of the same form and date were found
if __name__ == '__main__':
    df_cand_d = pd.read_parquet(p_sec / 'sec_deal_candidates.parquet')
    df_tie = df_cand_d[df_cand_d['f_tie_member'] & (df_cand_d['n_tied'] > 1)].sort_values(['deal_no', 'accession']).copy()
    print('deals with a tie:', df_tie['deal_no'].nunique(), '| documents:', len(df_tie))

# %%
#features of each document: text without the html tags. the old filings are one text file that starts with a header, the text starts after <TEXT>
#the right document of a deal is the prospectus of the offering: it has the offer price, the underwriters and the words initial public offering
if __name__ == '__main__':
    r_price = re.compile(r'\$\s?\d[\d,]*(?:\.\d+)?\s*(?:per|a|each)\s+(?:share|unit|ads|american depositary share|ordinary share|common share|security)', re.I)
    r_shares = re.compile(r'(\d[\d,]{4,})\s+(?:ordinary shares|american depositary shares|shares|units)', re.I)
    r_sell = re.compile(r'selling\s+(?:stock|share|security)\s?holders?|offered by the selling|resale', re.I)
    l_feat = []
    for v_row in df_tie.itertuples():
        v_file = p_doc / f'{v_row.deal_no}_{v_row.accession}.htm'
        d_f = {'deal_no': v_row.deal_no, 'accession': v_row.accession, 'f_downloaded': v_file.exists()}
        if v_file.exists():
            v_txt = v_file.read_bytes().decode('utf-8', errors='ignore')
            v_k = re.search(r'<TEXT>', v_txt, re.I)
            if v_k:
                v_txt = v_txt[v_k.end():]
            v_txt = re.sub(r'(?is)<(script|style).*?</\1>', ' ', v_txt)
            v_txt = html.unescape(re.sub(r'<[^>]+>', ' ', v_txt))
            v_txt = re.sub(r'\s+', ' ', v_txt)
            v_cov = v_txt[:v_cover]
            v_sh = r_shares.search(v_cov)
            d_f.update({'n_chars': len(v_txt), 'f_price': bool(r_price.search(v_cov)), 'n_ipo_words': len(re.findall('initial public offering', v_cov, re.I)),
                        'n_selling': len(r_sell.findall(v_cov)), 'n_underwriter': len(re.findall('underwriter', v_cov, re.I)),
                        'shares': int(v_sh.group(1).replace(',', '')) if v_sh else None, 'cover_start': v_txt[:150]})
        l_feat.append(d_f)
    df_feat = pd.DataFrame(l_feat)
    print('documents read:', df_feat['f_downloaded'].sum(), 'of', len(df_feat))
    #score: price on the cover +3, initial public offering +2, underwriters named +1, selling shareholders without a price -2
    df_feat['score'] = (3 * df_feat['f_price'].fillna(False).astype(int) + 2 * (df_feat['n_ipo_words'].fillna(0) > 0).astype(int)
                        + (df_feat['n_underwriter'].fillna(0) > 0).astype(int) - 2 * ((df_feat['n_selling'].fillna(0) > 0) & ~df_feat['f_price'].fillna(False).astype(bool)).astype(int))

# %%
#the choice for each deal:
#1. the short documents are left out (press releases, notices)
#2. the best score wins if it is at least v_margin above the next one
#shares that sdc implies: proceeds (millions of dollars) divided by the offer price
if __name__ == '__main__':
    df_sdc = pd.read_parquet(p_sdc / v_deals, columns=['deal_no', 'proceeds', 'offer_price'])
    d_sdc_sh = dict(zip(df_sdc['deal_no'], df_sdc['proceeds'] * 1e6 / df_sdc['offer_price']))
    l_dec = []
    for v_deal, df_g in df_feat.groupby('deal_no'):
        df_g = df_g[df_g['f_downloaded']].sort_values(['score', 'accession'], ascending=[False, True])
        if len(df_g) == 0:
            l_dec.append({'deal_no': v_deal, 'accession': None, 'reason': 'documents not downloaded', 'f_review': True})
            continue
        df_k = df_g[df_g['n_chars'] >= v_short]
        if len(df_k) == 0:
            df_k = df_g
        v_best = df_k.iloc[0]
        if len(df_k) == 1:
            l_dec.append({'deal_no': v_deal, 'accession': v_best['accession'], 'reason': 'the other documents are short (press release or notice)', 'f_review': False})
            continue
        if v_best['score'] - df_k.iloc[1]['score'] >= v_margin:
            l_dec.append({'deal_no': v_deal, 'accession': v_best['accession'], 'reason': 'best cover score', 'f_review': False})
        elif df_k['shares'].nunique(dropna=False) == 1:
            l_dec.append({'deal_no': v_deal, 'accession': df_k['accession'].min(), 'reason': 'same shares, versions of the same offering (for example U.S. and international prospectus), the first filed', 'f_review': False})
        else:
            #different documents with different shares: the one closest to the shares that sdc implies (proceeds / offer price) if it is within 35% and the next one is not or is twice as far
            df_k = df_k.assign(err=(df_k['shares'] - d_sdc_sh.get(v_deal, float('nan'))).abs() / d_sdc_sh.get(v_deal, float('nan'))).sort_values('err')
            v_e = df_k['err'].tolist()
            if v_e[0] <= 0.35 and (v_e[1] > 0.35 or v_e[1] >= 2 * v_e[0]):
                l_dec.append({'deal_no': v_deal, 'accession': df_k.iloc[0]['accession'], 'reason': 'closest to the shares of sdc', 'f_review': False})
            else:
                l_dec.append({'deal_no': v_deal, 'accession': v_best['accession'], 'reason': 'different documents, shares do not decide', 'f_review': True})
    df_best = pd.DataFrame(l_dec)
    df_best.to_parquet(p_sec / 'sec_tie_decision.parquet', index=False)
    df_feat.to_parquet(p_sec / 'sec_tie_features.parquet', index=False)
    print(df_best.groupby(['reason', 'f_review']).size().to_string())

# %%
#the final table: the filing chosen for the tied deals replaces the one picked by the filing step, the others stay as they are
if __name__ == '__main__':
    df_final_d = pd.read_parquet(p_sec / 'sec_deal_filing.parquet')
    df_ch = df_best[~df_best['f_review']][['deal_no', 'accession', 'reason']].merge(df_cand_d, on=['deal_no', 'accession'])
    df_final_d = df_final_d.merge(df_ch[['deal_no', 'accession', 'cik', 'file_number', 'primary_document', 'filing_date', 'form', 'url', 'reason']].rename(columns={'url': 'url_t', 'accession': 'accession_t', 'cik': 'cik_t', 'file_number': 'file_number_t', 'primary_document': 'doc_t', 'filing_date': 'date_t', 'form': 'form_t', 'reason': 'tie_reason'}), on='deal_no', how='left')
    df_final_d['f_tie_resolved'] = df_final_d['accession_t'].notna()
    for v_c, v_t in [('accession', 'accession_t'), ('cik', 'cik_t'), ('file_number', 'file_number_t'), ('primary_document', 'doc_t'), ('filing_date', 'date_t'), ('form', 'form_t'), ('url', 'url_t')]:
        df_final_d[v_c] = df_final_d[v_t].where(df_final_d['f_tie_resolved'], df_final_d[v_c])
    df_final_d['cik'] = df_final_d['cik'].astype('int64') #the merge with the tied deals made it a decimal number
    df_final_d = df_final_d.drop(columns=['url_t', 'accession_t', 'cik_t', 'file_number_t', 'doc_t', 'date_t', 'form_t'])
    #does the document agree with sdc on the shares? the shares of the chosen document against the shares sdc implies (proceeds / offer price), within 35%. it is information, not a decision. missing when one of them is not available
    df_chosen = df_feat[['deal_no', 'accession', 'shares']].rename(columns={'shares': 'doc_shares'})
    df_final_d = df_final_d.merge(df_chosen, on=['deal_no', 'accession'], how='left')
    df_final_d['sdc_shares'] = df_final_d['deal_no'].map(d_sdc_sh)
    df_final_d['f_shares_agree_sdc'] = ((df_final_d['doc_shares'] - df_final_d['sdc_shares']).abs() / df_final_d['sdc_shares'] <= 0.35).where(df_final_d['doc_shares'].notna() & df_final_d['sdc_shares'].notna())
    df_final_d.to_parquet(p_sec / 'sec_deal_filing_final.parquet', index=False)
    print('final table:', len(df_final_d), 'deals | tie resolved by the documents:', df_final_d['f_tie_resolved'].sum(), '| tie left for review:', (df_final_d['f_tie'] & ~df_final_d['f_tie_resolved']).sum())

# %%
#the filing chosen for each deal (sec_deal_filing_final): download them
if __name__ == '__main__':
    df_final_c = pd.read_parquet(p_sec / 'sec_deal_filing_final.parquet')
    sec_download(df_final_c, p_doc, 'picked')

# %%
#all the deals from the start date and the deals that already have a filing from the steps above (sec_deal_filing_final)
if __name__ == '__main__':
    df_deal1 = pd.read_parquet(p_sdc / v_deals, columns=['deal_no', 'issue_date', 'name_full', 'sec_file_no'])
    df_deal1 = df_deal1[df_deal1['issue_date'] >= v_start].copy()
    df_deal1['issue_date'] = pd.to_datetime(df_deal1['issue_date'])
    df_deal1['file_number'] = np.where(df_deal1['sec_file_no'] > 0, '333-' + df_deal1['sec_file_no'].astype(str), None) #sdc has only the number, the sec writes 333-number
    df_final1 = pd.read_parquet(p_sec / 'sec_deal_filing_final.parquet', columns=['deal_no'])
    df_miss1 = df_deal1[~df_deal1['deal_no'].isin(df_final1['deal_no'])].copy()
    print('deals from the start date:', len(df_deal1), '| with a filing:', len(df_deal1) - len(df_miss1), '| without a filing:', len(df_miss1))

# %%
#the list of filings and companies built by the zip step
if __name__ == '__main__':
    con = duckdb.connect()
    con.register('df_miss1', df_miss1)
    con.execute(f"create table fil as select cik, accession, cast(filing_date as date) filing_date, form, file_number, primary_document from read_parquet('{p_sec}/sec_filings_ipo_forms.parquet')")
    con.execute(f"create table ent as select cik, name, former_names from read_parquet('{p_sec}/sec_entities.parquet')")

# %%
#route A: the company of the sdc file number. any filing of the list under that number gives the company (the number is on the registration statement as well)
if __name__ == '__main__':
    df_a2 = con.sql("""select distinct m.deal_no, f.cik from df_miss1 m join fil f on f.file_number = m.file_number where m.file_number is not null""").df()
    print('route A, deals whose file number is in the list:', df_a2['deal_no'].nunique(), 'of', df_miss1['file_number'].notna().sum(), 'with a number')

# %%
#route B: a company with exactly the sdc name (current or former name). both names are cleaned with the shared name matching code (clean in Ex1_name_score.py); the clean names of all company names were made once above, so this is a join
if __name__ == '__main__':
    df_miss1['clean'] = [ns.clean(v) if isinstance(v, str) else None for v in df_miss1['name_full']]
    df_nmc_ok = df_nmc[df_nmc['clean'].fillna('') != ''][['cik', 'clean']].drop_duplicates()
    df_b2 = df_miss1[df_miss1['clean'].fillna('') != ''][['deal_no', 'clean']].merge(df_nmc_ok, on='clean')[['deal_no', 'cik']].drop_duplicates()
    print('route B, deals with a company of exactly the same name:', df_b2['deal_no'].nunique())

# %%
#the companies of each deal and how they were found, then every prospectus type filing of those companies in the window
if __name__ == '__main__':
    df_co2 = pd.concat([df_a2.assign(r_a=True, r_b=False), df_b2.assign(r_a=False, r_b=True)]).groupby(['deal_no', 'cik']).agg(f_route_a=('r_a', 'max'), f_route_b=('r_b', 'max')).reset_index()
    con.register('df_co2', df_co2)
    df_cand2 = con.sql(f"""select c.deal_no, c.cik, c.f_route_a, c.f_route_b, f.accession, f.filing_date, f.form, f.file_number, f.primary_document,
        date_diff('day', m.issue_date, f.filing_date) gap
        from df_co2 c join df_miss1 m on m.deal_no = c.deal_no join fil f on f.cik = c.cik
        where regexp_matches(f.form, '{v_forms_prospectus}') and date_diff('day', m.issue_date, f.filing_date) between -{v_before} and {v_after}""").df()
    print('candidate filings:', len(df_cand2), '| deals:', df_cand2['deal_no'].nunique())

# %%
#one filing per deal: the best form first (424B4, 424B1, 424B2, 424B5, 424B3, then 253G and 497), then the closest to the issue date. the other filings stay in the table with f_pick False
if __name__ == '__main__':
    df_cand3 = df_cand2.copy()
    df_cand3['form_rank'] = df_cand3['form'].map(v_rank).fillna(9)
    df_cand3['abs_gap'] = df_cand3['gap'].abs()
    df_cand3 = df_cand3.sort_values(['deal_no', 'form_rank', 'abs_gap', 'accession'])
    df_cand3['f_pick'] = ~df_cand3.duplicated('deal_no')
    df_cand3['n_candidates'] = df_cand3.groupby('deal_no')['accession'].transform('size')
    v_dir = 'https://www.sec.gov/Archives/edgar/data/' + df_cand3['cik'].astype(str) + '/'
    df_cand3['url'] = np.where(df_cand3['primary_document'].fillna('') != '', v_dir + df_cand3['accession'].str.replace('-', '') + '/' + df_cand3['primary_document'], v_dir + df_cand3['accession'] + '.txt')
    df_cand3 = df_cand3.merge(df_miss1[['deal_no', 'name_full', 'issue_date']], on='deal_no')
    df_cand3.to_parquet(p_sec / 'sec_extra_candidates.parquet', index=False)
    print('deals with a pick:', df_cand3['f_pick'].sum(), '| picks by form:', df_cand3[df_cand3['f_pick']]['form'].value_counts().to_dict())

# %%
#why a deal has no filing: one row for each deal without a filing in the filing step
if __name__ == '__main__':
    df_status2 = df_miss1[['deal_no', 'name_full', 'issue_date', 'file_number']].copy()
    df_status2['f_file_number'] = df_status2['file_number'].notna()
    df_status2['f_number_in_list'] = df_status2['deal_no'].isin(df_a2['deal_no'])
    df_status2['f_name_company'] = df_status2['deal_no'].isin(df_b2['deal_no'])
    df_status2['f_candidate'] = df_status2['deal_no'].isin(df_cand2['deal_no'])
    df_status2['reason'] = np.select([df_status2['f_candidate'],
                                      df_status2['f_number_in_list'] | df_status2['f_name_company'],
                                      df_status2['f_file_number']],
                                     ['prospectus type filing found in the wider window', 'company found, no prospectus type filing in the window', 'sdc file number is not in the filing list'],
                                     default='no sdc file number and no company with the same name')
    df_status2.to_parquet(p_sec / 'sec_extra_status.parquet', index=False)
    print(df_status2['reason'].value_counts().to_string())

# %%
#the filing picked for each deal that had no filing: download them
if __name__ == '__main__':
    df_cand_e = pd.read_parquet(p_sec / 'sec_extra_candidates.parquet')
    sec_download(df_cand_e[df_cand_e['f_pick']], p_doc_extra, 'extra')

# %%
#the filing picked by the missing deals step for each deal and whether its document is on disk
if __name__ == '__main__':
    df_pick1 = pd.read_parquet(p_sec / 'sec_extra_candidates.parquet')
    df_pick1 = df_pick1[df_pick1['f_pick']].sort_values('deal_no').copy()
    df_pick1['f_downloaded'] = [(p_doc_extra / f'{v_d}_{v_a}.htm').exists() for v_d, v_a in zip(df_pick1['deal_no'], df_pick1['accession'])]
    print('picked filings:', len(df_pick1), '| downloaded:', df_pick1['f_downloaded'].sum())

# %%
#text of each document without the html tags (the old filings are one text file that starts with a header, the text starts after <TEXT>) and the rule:
#a supplement (it adds to a prospectus of an earlier date, or offers interests of a 401(k) plan) is not the prospectus of the offering
if __name__ == '__main__':
    r_sup = re.compile(r'prospectus\s+supplement|supplement\s+(?:no\.?\s*\d+\s+)?to\s+(?:the\s+)?prospectus|this\s+(?:prospectus\s+)?supplement|supplements\s+(?:and\s+amends\s+)?(?:the|that)|401\s?\(k\)|participation\s+interests', re.I)
    l_cover = []
    for v_row in df_pick1[df_pick1['f_downloaded']].itertuples():
        v_txt = (p_doc_extra / f'{v_row.deal_no}_{v_row.accession}.htm').read_bytes().decode('utf-8', errors='ignore')
        v_k = re.search(r'<TEXT>', v_txt, re.I)
        if v_k:
            v_txt = v_txt[v_k.end():]
        v_txt = re.sub(r'(?is)<(script|style).*?</\1>', ' ', v_txt)
        v_txt = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', v_txt)))
        l_cover.append({'deal_no': v_row.deal_no, 'n_chars': len(v_txt), 'f_supplement': bool(r_sup.search(v_txt[:v_cover_sup])), 'cover_start': v_txt[:300]})
    df_cover2 = pd.DataFrame(l_cover)
    df_class2 = df_pick1.merge(df_cover2, on='deal_no', how='left')
    df_class2['f_usable_rule'] = df_class2['f_downloaded'] & (df_class2['f_supplement'] == False)
    df_class2['reason_rule'] = np.select([~df_class2['f_downloaded'], df_class2['f_supplement'] == True], ['document not downloaded', 'supplement of a prospectus (or 401(k) plan interests)'], default='prospectus of the offering')
    print(df_class2['reason_rule'].value_counts().to_string())

# %%
#the decisions made by reading the documents replace the rule. the file has the cases the rule gets wrong:
#a prospectus of a later offering (follow on, continuous offering) that the rule keeps, and a prospectus filed with a supplement notice in front of it that the rule drops
if __name__ == '__main__':
    df_hand2 = pd.read_parquet(p_sec / v_hand) if (p_sec / v_hand).exists() else pd.DataFrame({'deal_no': pd.Series(dtype='int64'), 'f_usable': pd.Series(dtype='bool'), 'reason': pd.Series(dtype='str')})
    df_class3 = df_class2.merge(df_hand2[['deal_no', 'f_usable', 'reason']].rename(columns={'f_usable': 'f_usable_hand', 'reason': 'reason_hand'}), on='deal_no', how='left')
    df_class3['f_usable'] = df_class3['f_usable_hand'].fillna(df_class3['f_usable_rule']).astype(bool)
    df_class3['reason'] = df_class3['reason_hand'].fillna(df_class3['reason_rule'])
    df_class3['source'] = np.where(df_class3['f_usable_hand'].notna(), 'hand', 'rule')
    df_class3.to_parquet(p_sec / 'sec_extra_classified.parquet', index=False)
    print('usable:', df_class3['f_usable'].sum(), 'of', len(df_class3), '| decided by hand:', (df_class3['source'] == 'hand').sum())
    print(df_class3.groupby(['f_usable', 'source']).size().to_string())

# %%
#the usable filings in the columns of sec_deal_filing_final, and one table with all the filings (the first run plus these)
if __name__ == '__main__':
    df_ent3 = pd.read_parquet(p_sec / 'sec_entities.parquet', columns=['cik', 'name', 'former_names', 'tickers']).drop_duplicates('cik')
    df_extra3 = df_class3[df_class3['f_usable']].merge(df_ent3.rename(columns={'name': 'sec_name', 'tickers': 'sec_tickers'}), on='cik', how='left')
    df_extra3 = df_extra3[['deal_no', 'accession', 'form', 'filing_date', 'cik', 'file_number', 'sec_name', 'former_names', 'sec_tickers', 'url', 'primary_document']].copy()
    df_extra3['cik'] = df_extra3['cik'].astype('int64')
    df_extra3.to_parquet(p_sec / 'sec_deal_filing_extra.parquet', index=False)
    df_final3 = pd.read_parquet(p_sec / 'sec_deal_filing_final.parquet')
    df_all3 = pd.concat([df_final3.assign(f_extra=False), df_extra3.assign(f_extra=True)], ignore_index=True)
    df_all3['cik'] = df_all3['cik'].astype('int64')
    df_all3.to_parquet(p_sec / 'sec_deal_filing_all.parquet', index=False)
    print('filings: first run', len(df_final3), '+ extra', len(df_extra3), '=', len(df_all3), '| one filing per deal:', df_all3['deal_no'].is_unique)

# %%
#the pool of workers is closed
if __name__ == '__main__':
    ex.shutdown()
