# %%
import time
import zipfile
import pandas as pd
import requests
from datetime import datetime
from pathlib import Path

# %%
#downloads the SEC bulk file submissions.zip (the public EDGAR filing history of all filers, about 1.5 GB). it is one request to sec.gov. the file can also be downloaded by hand: the steps and the rules of the SEC are in IPO table algorithm.md, Appendix, Step 4, "SEC download"
#folder of the sec files: change accordingly
p_sec=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Event Study SDC 20261109\sec')
v_url='https://www.sec.gov/Archives/edgar/daily-index/bulkdata/submissions.zip' #the address on the EDGAR APIs page of the SEC, section Bulk Data
v_download=False #False = no request is sent, the program only says what it would do. True = the file is downloaded (one request). not run yet
v_redo=False #False = if submissions.zip is already in the folder it is not downloaded again. True = it is downloaded again and replaces the file
#the sec asks to declare who is running the script in the header (name and contact email) and to stay under 10 requests per second. this is one request, so the rate is not an issue. change the name and the email to whoever runs the program
d_header={'User-Agent': 'user/user@domain.com', 'Accept-Encoding': 'gzip, deflate'}
v_chunk=1048576 #bytes written to disk at a time
v_timeout=120 #seconds the sec can take to answer or between two chunks before the request is given up

# %%
#to do: run this program once with v_download=True and write here the date of the download, the seconds it took and the size of the file. the file is saved as .part and renamed when it is complete, so a download that stopped never looks finished
p_zip=p_sec / 'submissions.zip'
p_part=p_sec / 'submissions.zip.part'
if p_zip.exists() and not v_redo:
    print(f"{p_zip} is already there ({p_zip.stat().st_size / 1e9:.2f} GB), not downloaded again. v_redo=True downloads it again")
elif not v_download:
    print(f"v_download is False: no request was sent. it would ask for {v_url} and save it as {p_zip}")
else:
    p_sec.mkdir(parents=True, exist_ok=True)
    v_t0 = time.time()
    v_bytes = 0
    with requests.get(v_url, headers=d_header, stream=True, timeout=v_timeout) as r_get:
        v_status = r_get.status_code
        print(f"http status {v_status}")
        if v_status in (403, 429):
            raise RuntimeError(f"the sec answered {v_status}: stop and wait. check the header (name and email) and do not ask again right away")
        r_get.raise_for_status()
        v_size = int(r_get.headers.get('Content-Length', 0))
        with open(p_part, 'wb') as f_out:
            for v_bytes_chunk in r_get.iter_content(chunk_size=v_chunk):
                f_out.write(v_bytes_chunk)
                v_bytes += len(v_bytes_chunk)
                if (v_bytes // v_chunk) % 200 == 0:
                    print(f"{v_bytes / 1e6:.0f} MB of {v_size / 1e6:.0f} MB | {time.time() - v_t0:.0f} seconds")
    p_part.replace(p_zip)
    v_secs = time.time() - v_t0
    print(f"saved {p_zip} | {v_bytes / 1e9:.2f} GB | {v_secs:.0f} seconds")
    df_times1 = pd.DataFrame([{'run_time': datetime.now().isoformat(timespec='seconds'), 'url': v_url, 'status': v_status, 'bytes': v_bytes, 'seconds': round(v_secs, 1)}])
    p_times = p_sec / 'sec_submissions_download_times.parquet' #one row for each run, so the date of the file is kept
    if p_times.exists():
        df_times1 = pd.concat([pd.read_parquet(p_times), df_times1], ignore_index=True)
    df_times1.to_parquet(p_times, index=False)

# %%
#check of the file: it must be a zip and the list of its files must be readable (the list is read, the files are not unzipped)
if p_zip.exists():
    print(f"is a zip file: {zipfile.is_zipfile(p_zip)}")
    with zipfile.ZipFile(p_zip) as z_in:
        l_names = z_in.namelist()
    print(f"files in the zip {len(l_names)} | first {l_names[:2]}")
