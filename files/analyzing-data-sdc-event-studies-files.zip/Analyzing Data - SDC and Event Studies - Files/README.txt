﻿Analyzing Data - SDC and Event Studies - Files
PhD Workshop 2026 Fall - Empirical Research Pipeline

Contents
  code        the programs: Jupyter notebooks (.ipynb) and, in the jupytext_py folders, the same programs as .py files.
              Start with code\README.md: it gives the run order.
  guides      how the IPO table is built (IPO table algorithm.md), the SDC search and column lists, the published tables the replications compare with
  sdc_session_report  the SDC report and session files (lmv_variables_report.sdcrpt, lmv_variables_session.sdcs)
  references  the CRSP code tables and the two Lowry, Michaely, Volkova papers; for the Bradley, Jordan, Ritter paper, a text file with its link

Before you run a program, change these at the top of it:
  1. v_username = "user"  ->  your own WRDS username
  2. the header with the name and email in the SEC and Ritter downloads ('user/user@domain.com')  ->  your own name and email (the SEC asks who is running the program)
  3. the data folder path  ->  a folder on your computer where the data files are saved
