# SEC prospectus download: how we got the prospectus of each SDC deal

This guide explains how the prospectus documents were found and downloaded, in the order of the programs. The data is got by programs in `code/sec` (this guide: `Ex1_01_sec_submissions_download`, `Ex1_05_sec_prospectus_download`); the WRDS download is in `code/sdc_crsp`. The numbers in the Results sections come from the files on disk (checked 2026-11-08). The reader that takes price and shares out of the documents is Step 4 of `IPO table algorithm.md`, not part of this guide.

## What it gives

- One filing (the prospectus of the offering) for each SDC deal issued from 1997-01-09 on, and its text saved as `sec/documents/<deal_no>_<accession>.htm` (the first 1 MB of the document).
- Deals before 1997 have no document: the SEC has the filings electronically from the mid 1990s, and our documents start with deals of 1997-01-09.
- Final table: `sec/sec_deal_filing_all.parquet`, one row per deal with the accession number, form, filing date, company (cik, name), file number and url.

## Folder `Event Study SDC/sec`

| File or folder | What it is |
|---|---|
| `submissions.zip` | the SEC bulk file, one json per company (1.5 GB). **Download this file** by hand from https://www.sec.gov/Archives/edgar/daily-index/bulkdata/submissions.zip, or with `Ex1_01_sec_submissions_download` (written, not run yet), and save it here without unzipping it; the steps are in the Appendix of `IPO table algorithm.md`, Step 4, "SEC download" |
| `sec_entities.parquet`, `sec_filings_ipo_forms.parquet` | companies (990,624) and the filings of the forms we keep (3,166,599), made by part 1 |
| `sec_deal_candidates.parquet`, `sec_deal_filing.parquet` | every candidate filing of each deal and the one picked, made by part 2 |
| `sec_tie_features.parquet`, `sec_tie_decision.parquet`, `sec_deal_filing_final.parquet` | the covers read for tied deals and the final picks of the first run, made by part 4 |
| `documents/` | 9,390 downloaded documents of the first run |
| `sec_extra_candidates.parquet`, `sec_extra_status.parquet` | the filings found for deals that had none, and the reason when none was found, made by part 6 |
| `documents_extra/` | documents of those filings |
| `sec_extra_hand_decisions.parquet`, `sec_extra_classified.parquet`, `sec_deal_filing_extra.parquet`, `sec_deal_filing_all.parquet` | which of them are the prospectus, made by part 8 |
| `sec_download_log.parquet` | every request to the SEC (time, deal, url, status, bytes) |

## The parts of `Ex1_05_sec_prospectus_download`, in the order they run (one program, one part after the other)

| Part | What it does | Sends requests to the SEC? |
|---|---|---|
| 1. read the zip (with `Ex1_05_sec_prospectus_download_worker.py`) | reads `submissions.zip` in parallel and writes the company list and the filing list. Forms kept: 424B, 253G, 497 (prospectus type), registration statements (S-1, F-1, SB-2, N-2, S-11, S-3 ...) and 8-A12. Run once. | no (reads the zip) |
| 2. find the filing of each deal | finds the filings of each deal (two routes, below) and picks one | no |
| 3. download the tied filings | downloads every filing of the deals where two or more filings have the same form and date | yes |
| 4. read the covers | reads the covers of those documents and chooses one for each tied deal; writes `sec_deal_filing_final` | no |
| 5. download the picked filings | downloads the picked filing of every deal | yes |
| 6. deals with no filing | for the deals with no filing, looks again in a wider window and records why none was found | no |
| 7. download the filings found in part 6 | downloads the filings found in part 6 into `documents_extra` | yes |
| 8. which of them is the prospectus | marks which of those filings are the prospectus of the offering and builds `sec_deal_filing_all` | no |

Parts 1 to 5 are the old programs Ex1_06 to Ex1_09 (they stay until this program is accepted). The three download parts use one function, `sec_download`. **No request is sent unless `v_download=True`** in the config cell (the default is False: each download part only prints how many documents it would ask for). The whole program runs on one deal table (`v_deals`: deal_no, issue_date, name_full, sec_file_no, proceeds in USD millions, offer_price); a deal that part 2 never saw would show up as "no filing" in part 6.

## How a filing is found (part 2)

1. Deals issued from 1997-01-01 on.
2. Route A, the SDC file number: SDC gives only the number (255461); the SEC writes it 333-255461. The filings under that file number inside 7 days of the issue date.
3. Route B, the name: the filings inside 7 days of the issue date of every company whose name (current or former) looks like the SDC name (Jaro-Winkler 0.90 to find the company, then the name score of the matching programs, at least 90, to accept it).
4. Only prospectus type forms count: 424B (final prospectus and supplements), 253G (Regulation A offering circular), 497 (funds).
5. One filing for each deal, in this order: the form (424B4 first, then 424B1, 424B2, 424B5, 424B3, 253G, 497), then a filing under the SDC file number, then the closest to the issue date.
6. A tie is two or more filings with the same form, date and file number status. They are downloaded and part 4 reads the covers: a document with the price on the cover scores +3, the words "initial public offering" +2, underwriters named +1, selling shareholders without a price -2; short documents (under 20,000 characters, press releases and notices) are left out; then the best score decides if it is 2 points above the next, then the same shares (copies of one filing and versions of the same offering: the first filed is kept), then the shares closest to SDC proceeds divided by offer price (within 35%). What is left stays for review.

### Results of the first run (deals from 1997 on, the old SDC download)

- 9,702 deals from 1997 on; 9,079 have a filing: 8,143 found by number and name, 778 by name only, 158 by number only. Forms: 424B4 6,765, 424B1 1,297, 497 527, 424B3 339, 424B5 57, 424B2 50, others.
- 258 deals had a tie: 233 were decided by reading the covers, 25 are left for review.
- Download: 9,795 requests on 2026-10-28 and 2026-10-29: 9,612 answered 200, 182 answered 404 (the document does not exist at that address) and 1 answered 403 (a bug: the cik was a decimal number in the address; it was cast to a whole number). 9,390 documents are on disk.
- In 3 deals the SDC file number is under a different company (cik) than the filing picked: Enduro Royalty Trust (the picked company is named Permianville Royalty Trust, its later name), Medpace Holdings and ECA Marcellus Trust I (same name in both). Not examined further.

## Run on the deals of the final table (test of 2026-11-09, no request sent)

The program builds the list of deals from `sdc_ipo_step3_<date>.parquet` (the deals with a recommended permno) and `sdc_ipo_step0_<date>.parquet`, and saves it as `sdc/sdc_ipo_prospectus_deals.parquet`. Tested with the filing list and the documents of the first run in a sandbox folder (downloads off):

- 7,970 deals issued from 1997 on. 7,630 have a filing from the first search (7,263 by number and name, 237 by name only, 130 by number only) and 340 have none.
- 182 ties: 174 decided by reading the covers, 8 left for review.
- Of the 340 without a filing, the wider search finds a prospectus type filing for 66 (39 of them are the prospectus of the offering: 38 by the rule and 1 by hand); 236 have a company but no prospectus type filing in the window, 24 have no SDC file number and no company with the same name, 14 have a file number that is not in the filing list.
- One filing for each of 7,669 deals; 301 deals from 1997 on have none.
- Documents still to download for this deal list, given the documents of the first run: 2 picked filings and 3 of the extra filings, 5 requests. The documents of the first run are in the earlier folder `Event Study SDC/sec/documents`; the new folder `Event Study SDC 20261109/sec` has none, so they have to be copied there (local files, no request) or downloaded again (about 9,400 requests).

## Deals with no filing (part 6)

623 deals from 1997 on had no filing after the first run. Part 6 uses only the files on disk:

- Route A: the company of the SDC file number, taken from any filing of the list under that number (the number is also on the registration statement).
- Route B: a company with exactly the SDC name after cleaning (current or former name).
- The filings of those companies of the prospectus type, from 45 days before to 120 days after the issue date, one for each deal (same form order as before, then the closest date).

Result on those 623 deals (run 2026-11-08): 107 have a prospectus type filing in the wider window, 424 have a company but no prospectus type filing in it, 20 have an SDC file number that is not in the list, and 72 have no file number and no company with the same name. `sec_extra_status.parquet` has the reason for every deal. Why the filing list has nothing for a file number is not known.

On the deals of the final table (the 342 from 1997 on that had no filing after the first run) the same search found 64 filings, which were downloaded on 2026-11-08 (65 requests: 64 answered 200 and one 503 that worked on the retry). 44 more of the 107 are not downloaded: 3 are deals of the final table found through a former name, and 41 are deals that Step 2 and Step 3 drop later.

## Which of them is the prospectus (part 8)

A filing found in the wider window is often not the prospectus: 45 of the 64 were 424B3, the form of supplements and of some real prospectuses. Part 8 reads the start of each document:

- A supplement (the text says "prospectus supplement", "supplements the prospectus", "401(k)" or "participation interests" in the first 2,500 characters) is not usable. 22 of the 63 documents.
- The rest are usable by the rule. 41 of 63.
- Four decisions were made by reading the documents and replace the rule (`sec_extra_hand_decisions.parquet`): United Rentals (a follow on prospectus of 1998-03, price 25.56, the IPO price was 13.50), HotJobs (follow on at 30.38, the IPO price was 8.00) and the streetTRACKS Gold Trust (a continuous offering update) are not usable although the rule keeps them; GT Group Telecom is usable although the rule drops it (the filing starts with a notice of a supplement and then holds the IPO prospectus).
- Result: 39 usable of the 63 downloaded (40 with BATS Global Markets, which is not in the old SDC download that the test used).

## SEC access rules (read from sec.gov, 2026-10-28; the pages were read again 2026-11-09)

The SEC's own statements of the rules, with the link to the page where each one is, are in the Appendix of `IPO table algorithm.md`, Step 4, "SEC download". What the program does:

- At most 10 requests per second in total. The download is one request at a time with 0.5 seconds after each one (2 per second) and a guard of 8 per second.
- The header names who is running the program: `user/user@domain.com`.
- robots.txt (read again 2026-11-09) disallows /cgi-bin, /Archives/bin, /bin and /node and allows /Archives/edgar/data, so browse-edgar is not used; the bulk file and the archive addresses under /Archives/edgar/data are.
- The download stops at the first 403 or 429. It does not ask again for an address that answered 404 in an earlier run (`v_retry_404=True` asks again).
- The main document of a filing is asked first; if the answer is 404 the whole filing as one text file (`/Archives/edgar/data/<cik>/<accession>.txt`) is asked.
- Only the first 1 MB of each document is saved: the cover and the text near it hold what Step 4 reads.
- `v_download=False` is the default, so a run of the program sends nothing. Parallel workers are not used for requests.

## To run it again

1. Put the SDC deal table in `sdc/` and set `v_deals`. Set `v_start` if the SEC documents start at another date.
2. Part 1 reads the zip only if `sec_entities.parquet` and `sec_filings_ipo_forms.parquet` do not exist or `v_redo=True`.
3. Run the program once with `v_download=False` to see the counts, then with `v_download=True` to download. The parts run in the order of the table; a second run only asks for the documents that are not on disk.

## Limits

- No documents before 1997.
- 25 tied deals are left for review (the covers do not decide).
- For the deals in the 107 above, whether the filing found is the prospectus of the offering is decided by the rule and four hand decisions; the 44 not downloaded are not classified.
- The documents are the SEC text of the filing, not a clean copy; Step 4 reads them with regular expressions.
