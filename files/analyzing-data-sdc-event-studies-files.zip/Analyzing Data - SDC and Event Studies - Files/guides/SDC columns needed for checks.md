# SDC columns needed for checks and comparisons

Started 2026-11-03. Status: **have** = in our export (`sdc_lmv.parquet`, or `sdc_ipo.parquet` where marked), **seen** = shown in the SDC platform for the two Banner Aerospace deals but not in our files, **to check** = in the SDC Data Item Library but not pulled yet (not known whether filled for old deals).

## Identify the deal and the firm
| Column | Status | Used for |
|---|---|---|
| SDC Deal Number (`deal_no`), Tranche ID | have | key; tranche pairs |
| Issuer 9-digit CUSIP (`cusip9`), 6-digit CUSIP (`cusip6`) | have | step 1 passes (8 and 6 characters); Ritter confirmation |
| Issuer ticker | have | ticker pass and ticker confirmation |
| Issuer full name (`name_full`) | have | name score |
| Immediate / ultimate parent 6-digit CUSIP, new-issues CUSIP, ticker and name (`sdc_ipo.parquet` only) | have | not used yet |

## Event dates and type
| Column | Status | Used for |
|---|---|---|
| Issue date, filing date | have | 30 day and 7 day date tests; filing date checks against the authors' corrections |
| IPO flag, Original IPO flag | have | Step 0 filter |
| Main tranche flag, number of tranches | have | tranche rules |
| Security type, security type all markets, security type code | have | units vs shares; tell tranche parts apart |
| Unit issue flag, unit type, depositary flag, closed-end flag | have | exclusions (the unit flag was False for GFL units, so the security type text is needed) |

## Size and price
| Column | Status | Used for |
|---|---|---|
| Offer price, proceeds this market, proceeds all markets | have | compare the two parts of one offering (price x shares = proceeds) |
| File price low and high (and full history versions) | have | price range; history fields are 0.0 when empty |
| Gross spread, gross spread percent | have | same offering has the same percent in both parts (Banner 5.75%) |
| Primary shares and primary amount filed (`sdc_ipo.parquet` only) | have | often empty (empty for Banner) |

## Shares (new, from the platform)
| Column | Status | Used for |
|---|---|---|
| Shares Offered This Market | seen | 7.5M and 2.0M for Banner; tells the parts apart |
| Shares Offered All Markets | seen | 9.5M for both Banner deals; same offering |
| Primary Shares Offered This Market, Secondary Shares Offered This Market | seen | who sold the shares in each part |
| Primary Shares Offered All Markets, Secondary Shares Offered All Markets | seen | **can be wrong**: Banner shows 9.5M secondary in one deal and 9.5M primary in the other; do not rely on it |
| Offering Technique | seen | Firm Commitment vs Offer for Subscription (Banner) |
| Tranche Currency | seen | USD for both Banner parts |
| Related SDC Deal Number | seen | empty for both Banner deals |
| Issuer public status, issuer stock exchange | seen | weak: "Subsidiary" vs "Private" for Banner |
| Financials: Shares Outstanding After Offer, Financials: Shares Outstanding Before Offer | seen | total shares to compare with CRSP. For Banner only deal 170499002 is filled: 18,000,000 in both columns; deal 1099450009 is empty. Same number before and after, so it may just repeat the post-offer count: do not read it as the pre-IPO count. |
| Shares Outstanding After Offer From Prospectus, Shares Outstanding Before Offer From Prospectus | seen | empty for both Banner deals |
| Global Offering: International Shares Offered, Percent of Shares Offered Internationally, Global Offering: Shares Offered This Market | to check | international part of a two-part offering |
| Overallotment Shares Option (This Market, All Markets), Overallotment Shares Exercised | to check | explains differences between offered and outstanding |
| Selling Shareholder Shares | to check | secondary shares |
| Shares Held by Directors Before Offer, After Offer | to check | insider holdings |

## Managers and SEC
| Column | Status | Used for |
|---|---|---|
| Lead managers code, co-managers code | have | international-looking codes (`-I`, `-INT`) mark the 009 deal in 37 of 63 pairs |
| SEC file number, SEC file form | have | match to SEC prospectuses; two parts of one registration share the number |

## Outside SDC, needed for the same checks
| Source | Used for |
|---|---|
| CRSP `stkshares` (`shrout`, unadjusted, in thousands) | shares outstanding after the IPO (Banner 18,000 from 1990-07-27) |
| CRSP monthly adjustment factor (`stkmthcumulativeadjfactor`, in the Ex7 folder) | adjust shares across splits (`mthcumfacshr`) |
| CRSP first trading date | date test |
| Ritter file (offer date, name, ticker, CUSIP, permno, dual flag) | the event list we match to |

## Added 2026-11-04: columns used to keep one of two main tranche deals on one permno
| Column | Status | Used for |
|---|---|---|
| Stock Price at Close of Offer/First Trade (USD) (`TR.NIIssuerStkPriceAtCloseOfFirstTrade`) | have (in the download with the price column) | step 1: the deal whose SDC close equals CRSP's first-day close |
| Target Market (`TR.NITargetMarket`, Concat=";") | have (in the download of 2026-11-04) | step 2: the deal whose Target Market is the United States alone |
| Prospectus Status (`TR.NIProspectusStatus`) | have (in the download of 2026-11-04) | step 3: the deal whose Prospectus Status is Completed |
| Filing date, Proceeds Amount This Market | have | step 4 tie-break between two deals ending in 002 |
