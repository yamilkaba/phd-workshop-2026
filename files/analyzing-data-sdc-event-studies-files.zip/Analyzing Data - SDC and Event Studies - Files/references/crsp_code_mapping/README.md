# CRSP code mapping (the user's own work)

`shrcd.xlsx`: each old CRSP share code (SHRCD) as the combination of the new fields of `stksecurityinfohist` (sharetype, securitytype, securitysubtype, usincflg, issuertype). Share codes 10 to 19 are the six rows 10, 11, 12, 14, 15 and 18; 10 and 11 are common stock of US companies (issuer type ACOR and CORP).

`exchcd.xlsx`: each old exchange code (EXCHCD) as primaryexch, conditionaltype and tradingstatusflg. Exchange codes 1, 2 and 3 are primary exchange N, A and Q with conditional type RW and trading status A (active).

Used by the replication programs in `code/replication`: they read these two files and pick the codes of their own paper.
