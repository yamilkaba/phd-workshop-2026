# References

Documents that are neither code nor data: the papers we replicate and the reference tables we use. This folder is what goes to the website as references.

## papers_to_replicate

| file | what it is | replicated in |
|---|---|---|
| Lowry Michaely Volkova 2017 - Initial Public Offerings, a synthesis (SSRN 2912354).pdf | the paper (Foundations and Trends in Finance); Table 1 on page 173 of the PDF | `Ex2_01_replication1_lmv` |
| Lowry Michaely Volkova 2017 - Online Appendix - Extraction and Cleaning of IPO Data from SDC Platinum.pdf | the Online Appendix: how their IPO sample is built from SDC and CRSP | the sample steps of `Ex2_01_replication1_lmv` |
| Bradley Jordan Ritter 2003 - The Quiet Period Goes Out with a Bang (Journal of Finance).pdf | the paper (Journal of Finance 58(1), 1-36); Table I (descriptive statistics) on page 7 and Table II (event study at the end of the quiet period) on page 9 of the journal (PDF pages 8 and 10); sample filters on page 6 | `Ex2_02_replication2_quiet_events`, event study, `Ex2_03_replication2_quiet_table` |

The numbers of the published tables, typed from these PDFs, are the csv files `... as published.csv` in `guides` (the programs read them).

## crsp_code_mapping

The user's tables that turn the old CRSP share and exchange codes into the new fields (`shrcd.xlsx`, `exchcd.xlsx`). See the README in that folder.
