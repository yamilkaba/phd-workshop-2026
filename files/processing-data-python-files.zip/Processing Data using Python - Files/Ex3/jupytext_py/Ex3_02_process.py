# %%
import pandas as pd
import duckdb
from pathlib import Path

# %%
#path where the files were downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex3')

# %%
df_comp1 = pd.read_parquet(f"{p_path}/df_comp1.parquet")

# %%
#industry = first two digits of the sic code (integer division keeps missing sic as missing)
df_comp2 = df_comp1.copy()
df_comp2['industry'] = df_comp2['sic'] // 100

# %%
#total sales and number of firms per industry and fiscal year
df_industry1 = df_comp2.groupby(["industry", "fyear"]).agg({"sale": "sum", "gvkey": "count"}).reset_index()
df_industry1.rename(columns={"gvkey": "n_gvkey"}, inplace=True)

# %%
#rank industries within each fiscal year by sales (1 = largest)
df_industry2 = df_industry1.sort_values(by=['fyear', 'sale'], ascending=[True, False])
df_industry2['rk_sale_per_fyear'] = df_industry2.groupby('fyear').cumcount() + 1

# %%
#keep the top 10 industries per fiscal year
df_industry3 = df_industry2[df_industry2['rk_sale_per_fyear'] <= 10].copy()
print(f"in: {df_industry2.shape} | out: {df_industry3.shape}")
df_industry3.head(20)

# %%
#same result in one duckdb query, one cte per operation: industry, totals, rank. duckdb reads df_comp1 by its variable name
#pandas groupby drops rows with a missing key, duckdb keeps them as a group, so missing sic and fyear are filtered out in the first cte (470 rows have no fyear)
query = """
WITH industry_cte AS (
    SELECT gvkey, fyear, sale, sic // 100 AS industry
    FROM df_comp1
    WHERE sic IS NOT NULL AND fyear IS NOT NULL
),
totals_cte AS (
    SELECT industry, fyear, SUM(sale) AS sale, COUNT(gvkey) AS n_gvkey
    FROM industry_cte
    GROUP BY industry, fyear
),
rank_cte AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY fyear ORDER BY sale DESC) AS rk_sale_per_fyear
    FROM totals_cte
)
SELECT *
FROM rank_cte
WHERE rk_sale_per_fyear <= 10
ORDER BY fyear, rk_sale_per_fyear
"""
df_industry4 = duckdb.query(query).df()
print(df_industry4.shape)
df_industry4.head(20)

# %%
#diagnostic: pandas and duckdb results should match - all rows 'both', 0 left_only, 0 right_only
df_chk_industry = pd.merge(df_industry3, df_industry4, how='outer', on=['industry', 'fyear', 'rk_sale_per_fyear'], suffixes=('_pd', '_dd'), indicator=True)
print(df_chk_industry['_merge'].value_counts())
print("max abs difference in sale:", (df_chk_industry['sale_pd'].astype(float) - df_chk_industry['sale_dd'].astype(float)).abs().max())
