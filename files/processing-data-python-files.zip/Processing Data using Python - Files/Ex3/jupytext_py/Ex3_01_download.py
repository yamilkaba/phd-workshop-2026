# %%
import pandas as pd
from pathlib import Path

# %%
#path where the files will be downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex3')
#wrds username, change accordingly
v_username="user"

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
df_comp1 = conn.raw_sql(
    """
    select a.gvkey, a.datadate, fyear,
    a.SICH, cast(b.Sic as int) as SIC,
    SALE, AT
    from comp.FUNDA as a
    left outer join comp.Names as b on a.gvkey = b.gvkey
    where INDFMT= 'INDL' and DATAFMT='STD' and POPSRC='D' and CONSOL='C' and CURCD='USD'
    """,
    date_cols=['datadate']
)
print(df_comp1.shape)
df_comp1.head()

# %%
conn.close()

# %%
p_path.mkdir(parents=True, exist_ok=True)
df_comp1.to_parquet(f"{p_path}/df_comp1.parquet", index=False)
