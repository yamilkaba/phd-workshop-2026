# %%
import pandas as pd
import duckdb
from pathlib import Path

# %%
#path where the files were downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex3')

# %%
df_comp1 = pd.read_parquet(f"{p_path}/df_comp1.parquet")

# %%
#firms whose historical sic (sich) does not keep the same first 2 digits over their history. rows with missing sich are ignored
#one cte per operation: first 2 digits, number of distinct values per firm, keep firms with more than one
query = """
WITH sich2_cte AS (
    SELECT gvkey, datadate, fyear, sich, sic, sich // 100 AS sich2
    FROM df_comp1
    WHERE sich IS NOT NULL
),
n_cte AS (
    SELECT *, COUNT(DISTINCT sich2) OVER (PARTITION BY gvkey) AS n_sich2_per_gvkey
    FROM sich2_cte
)
SELECT gvkey, datadate, fyear, sich, sic
FROM n_cte
WHERE n_sich2_per_gvkey > 1
ORDER BY gvkey, datadate
"""
df_sichchg1 = duckdb.query(query).df()
print(f"firms in df_comp1 with sich: {df_comp1.loc[df_comp1['sich'].notna(), 'gvkey'].nunique()} | firms with changing sich: {df_sichchg1['gvkey'].nunique()} | rows: {df_sichchg1.shape[0]}")
df_sichchg1.head(20)

# %%
#rows with missing sich: ignored above, kept here in their own dataframe
df_sichmiss1 = df_comp1.loc[df_comp1['sich'].isna(), ['gvkey', 'datadate', 'fyear', 'sich', 'sic']].copy()
print(f"rows with missing sich: {df_sichmiss1.shape[0]} | firms: {df_sichmiss1['gvkey'].nunique()}")
df_sichmiss1.head(20)
