﻿Processing Data using Python - Files
PhD Workshop 2026 Fall - Empirical Research Pipeline

Contents
  Syllabus PDF  the syllabus for this topic
  Ex1 ... Ex8   Jupyter notebooks (.ipynb) and, in jupytext_py, the same programs as .py files
  excel         Excel files used in the slides (Ex3 group by, Ex5 lags)
  guides        Installing Python and Visual Studio Code

Before you run a program, change two things at the top of it:
  1. v_username = "user"   ->  your own WRDS username
  2. p_path = Path(r'...')  ->  a folder on your computer where the data files will be saved
