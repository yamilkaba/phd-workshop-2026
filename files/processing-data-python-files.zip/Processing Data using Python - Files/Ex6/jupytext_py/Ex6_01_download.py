# %%
import pandas as pd
from pathlib import Path

# %%
#path where the files will be downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex6')
#wrds username, change accordingly
v_username="user"

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
#linking table: each row links an ibes ticker to a crsp permno between sdate and edate
df_ibeslnk1 = conn.raw_sql(
    """
    select *
    from wrdsapps_link_crsp_ibes.ibcrsphist
    order by sdate, edate
    """,
    date_cols=['sdate','edate']
)
print(df_ibeslnk1.shape)
df_ibeslnk1.head()

# %%
#ibes consensus eps forecast for the fiscal year ending in the same month as the statistics date
df_statsum1 = conn.raw_sql(
    """
    select ticker, statpers, fpedats, numest, medest, meanest, stdev, actual, curr_act
    from tr_ibes.statsum_epsus
    where fpi='1' and DATE_TRUNC('month', statpers) = DATE_TRUNC('month', fpedats)
    order by ticker, fpedats
    """,
    date_cols=['statpers','fpedats']
)
print(df_statsum1.shape)
df_statsum1.head()

# %%
conn.close()

# %%
p_path.mkdir(parents=True, exist_ok=True)
df_ibeslnk1.to_parquet(f"{p_path}/df_ibeslnk1.parquet", index=False)
df_statsum1.to_parquet(f"{p_path}/df_statsum1.parquet", index=False)
