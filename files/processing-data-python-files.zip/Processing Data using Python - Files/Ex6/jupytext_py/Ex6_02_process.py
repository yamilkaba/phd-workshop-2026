# %%
import pandas as pd
import duckdb
from pathlib import Path

# %%
#path where the files were downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex6')

# %%
df_ibeslnk1 = pd.read_parquet(f"{p_path}/df_ibeslnk1.parquet")
df_statsum1 = pd.read_parquet(f"{p_path}/df_statsum1.parquet")
print(df_ibeslnk1.shape, df_statsum1.shape)

# %%
#keep the best links only: score 1 is the best match and 6 the worst. rows with a missing score are dropped too
df_ibeslnk2 = df_ibeslnk1[df_ibeslnk1['score'] <= 2].copy()
print(f"in: {df_ibeslnk1.shape} | out: {df_ibeslnk2.shape}")

# %%
#method 1 - pandas: join on the identifier (ticker), then filter that statpers falls between sdate and edate
#the first step creates one row for every ticker-link pair, so it can be much bigger than either table and can blow up the ram when there are many links per ticker
df_m1a = pd.merge(df_statsum1, df_ibeslnk2, how='inner', left_on=['ticker'], right_on=['ticker'], suffixes=('', '_x'))
df_m1a = df_m1a.sort_values(by=['permno', 'fpedats'])
print(f"after the join on ticker: {df_m1a.shape}")

# %%
df_m1b = df_m1a[(df_m1a['statpers'] >= df_m1a['sdate']) & (df_m1a['statpers'] <= df_m1a['edate'])]
print(f"after the date filter: {df_m1b.shape}")

# %%
#one example of the first stage: pick a ticker and statpers that has several rows after the join on ticker (one per link) and exactly one row after the date filter
l_keys_ex = ['ticker', 'statpers', 'fpedats']
df_ex_n1 = df_m1a.groupby(l_keys_ex).size().rename('n_before').reset_index()
df_ex_n2 = df_m1b.groupby(l_keys_ex).size().rename('n_after').reset_index()
df_ex_n3 = pd.merge(df_ex_n1, df_ex_n2, how='left', left_on=l_keys_ex, right_on=l_keys_ex, suffixes=('', '_x'))
df_ex_n3 = df_ex_n3[(df_ex_n3['n_before'] > 1) & (df_ex_n3['n_after'] == 1)]
v_ticker = df_ex_n3['ticker'].iloc[0]
v_statpers = df_ex_n3['statpers'].iloc[0]
l_cols_ex = ['ticker', 'statpers', 'permno', 'sdate', 'edate', 'score']
print(f"before the date filter: {v_ticker} on {v_statpers.date()} has several rows, one per link")
print(df_m1a.loc[(df_m1a['ticker'] == v_ticker) & (df_m1a['statpers'] == v_statpers), l_cols_ex].to_string())
print("after the date filter: only the link whose sdate to edate contains statpers is left")
print(df_m1b.loc[(df_m1b['ticker'] == v_ticker) & (df_m1b['statpers'] == v_statpers), l_cols_ex].to_string())

# %%
#method 2 - duckdb: the date range is part of the join condition, so the rows that fall outside the range are never kept in memory
#duckdb reads the dataframes by their variable names. columns are listed one by one so ticker appears once (select * would return it twice)
query = """
SELECT a.ticker, a.statpers, a.fpedats, a.numest, a.medest, a.meanest, a.stdev, a.actual, a.curr_act,
       b.permno, b.ncusip, b.sdate, b.edate, b.score
FROM df_statsum1 AS a
JOIN df_ibeslnk2 AS b
  ON a.ticker = b.ticker
 AND a.statpers BETWEEN b.sdate AND b.edate
ORDER BY a.ticker, a.statpers, a.fpedats
"""
df_m2 = duckdb.query(query).df()
print(f"duckdb result: {df_m2.shape}")
df_m2.head()

# %%
#diagnostic: both methods should return the same rows - all 'both', 0 left_only, 0 right_only
#some rows are repeated in the data (and permno can be missing), so n numbers the repeats and the merge keeps them apart
l_keys = ['ticker', 'statpers', 'fpedats', 'permno', 'sdate', 'edate']
df_chk_m1 = df_m1b[l_keys].copy()
df_chk_m1['n'] = df_chk_m1.groupby(l_keys, dropna=False).cumcount()
df_chk_m2 = df_m2[l_keys].copy()
df_chk_m2['n'] = df_chk_m2.groupby(l_keys, dropna=False).cumcount()
df_chk_m = pd.merge(df_chk_m1, df_chk_m2, how='outer', left_on=l_keys + ['n'], right_on=l_keys + ['n'], suffixes=('', '_x'), indicator=True)
print(df_chk_m['_merge'].value_counts())

# %%
#returns all the rows that share the same key, sorted by the key
def dups(df, subset, sort_cols=None):
    df_d = df[df.duplicated(subset=subset, keep=False)]
    return df_d.sort_values(subset + (sort_cols or []))

# %%
#dup diagnostics at firm and fiscal period end - the same permno and fpedats appears more than once
df_dups_permno_fpedats = dups(df_m2, ['permno', 'fpedats'], ['statpers'])
print(f"rows sharing a permno and fpedats: {len(df_dups_permno_fpedats)}")
df_dups_permno_fpedats.head(10)
