# %%
import pandas as pd

# %%
#forecasts come first in time (left), actuals come after (right)
df_fcst = pd.DataFrame({
    'firm_id': [1, 2, 3, 4],
    'eps_forecast': [2.10, 1.85, 3.40, 0.95],
})
df_act = pd.DataFrame({
    'firm_id': [2, 3, 4, 5],
    'eps_actual': [1.90, 3.40, 1.10, 2.60],
})

# %%
#inner: only firm_id in both tables (2, 3, 4)
df_a_inner = pd.merge(df_fcst, df_act, how='inner', left_on=['firm_id'], right_on=['firm_id'], suffixes=('', '_x'))

# %%
#left: all forecasts kept, firm_id 1 has no actual so eps_actual is NaN
df_b_left = pd.merge(df_fcst, df_act, how='left', left_on=['firm_id'], right_on=['firm_id'], suffixes=('', '_x'))

# %%
#right: all actuals kept, firm_id 5 has no forecast so eps_forecast is NaN
df_c_right = pd.merge(df_fcst, df_act, how='right', left_on=['firm_id'], right_on=['firm_id'], suffixes=('', '_x'))

# %%
#full: all firm_id from both tables (1 to 5), NaN wherever one side is missing
df_d_outer = pd.merge(df_fcst, df_act, how='outer', left_on=['firm_id'], right_on=['firm_id'], suffixes=('', '_x'))

# %%
#cross: every forecast row paired with every actual row (4 x 4 = 16), no key allowed so no left_on/right_on
df_e_cross = pd.merge(df_fcst, df_act, how='cross', suffixes=('', '_x'))

# %%
#union needs the same column names in both tables: eps_forecast and eps_actual become eps, and a type column says which table each row came from
df_fcst_u = df_fcst.rename(columns={'eps_forecast': 'eps'}).assign(type='forecast')
df_act_u = df_act.rename(columns={'eps_actual': 'eps'}).assign(type='actual')

# %%
#union (vertical): concat stacks the rows of both tables (8 rows = 4 + 4, nothing removed). sorting by firm_id keeps forecast before actual for each firm
df_f_union = pd.concat([df_fcst_u, df_act_u], ignore_index=True)[['firm_id', 'type', 'eps']].sort_values('firm_id', kind='stable').reset_index(drop=True)
df_f_union

# %%
#distinct ids: each firm_id once from both tables (1 to 5)
df_g_ids = df_f_union[['firm_id']].drop_duplicates().reset_index(drop=True)
df_g_ids
