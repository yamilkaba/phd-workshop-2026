# %%
import pandas as pd
import numpy as np
from pathlib import Path

# %%
#path where the Ex3 file was downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex3')

# %%
df_comp1 = pd.read_parquet(f"{p_path}/df_comp1.parquet")

# %%
#returns all the rows that share the same key, sorted by the key
def dups(df, subset, sort_cols=None):
    df_d = df[df.duplicated(subset=subset, keep=False)]
    return df_d.sort_values(subset + (sort_cols or []))

# %%
#summary stats: one row per variable, columns are obs, mean, std, min, p01, p05, p25, p50, p75, p95, p99, max
def desc_stats(df, cols):
    l_q = [0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99]
    df_q = df[cols].quantile(l_q).T
    df_q.columns = ['p01', 'p05', 'p25', 'p50', 'p75', 'p95', 'p99']
    df_out = pd.DataFrame({'obs': df[cols].count(), 'mean': df[cols].mean(), 'std': df[cols].std(), 'min': df[cols].min()})
    df_out = df_out.join(df_q)
    df_out['max'] = df[cols].max()
    return df_out

# %%
#a lag with shift(1) takes the previous row of the firm, not the previous fiscal year, so before lagging we need one row per gvkey and fyear
#dup diagnostics at fyear - the same fyear appears twice for some firms
df_dups_gvkey_fyear = dups(df_comp1, ['gvkey', 'fyear'], ['datadate'])
print(f"rows sharing a gvkey and fyear: {len(df_dups_gvkey_fyear)}")
df_dups_gvkey_fyear.head(10)

# %%
#drop rows with a missing key: any = drops if one of them is missing, all = drops only if both are missing
df_comp2 = df_comp1.dropna(subset=['gvkey', 'fyear'], how='any').copy()
print(f"in: {df_comp1.shape} | out: {df_comp2.shape}")

# %%
#choose one row per gvkey and fyear. decision: if both rows have assets, pick the biggest (if they are equal it does not matter); if only one has assets, pick that one; if both are missing it does not matter
#ties and missing in both go to the later datadate. rk = 1 is the row chosen (11 rows removed - 10/15/2026 yk)
df_comp3 = df_comp2.sort_values(['gvkey', 'fyear', 'at', 'datadate'], na_position='first')
df_comp3['rk_at_per_gvkeyfyear'] = df_comp3.groupby(['gvkey', 'fyear']).cumcount(ascending=False) + 1
df_comp3['f_dedup_gvkeyfyear'] = (df_comp3['rk_at_per_gvkeyfyear'] == 1).astype(int)

# %%
df_comp4 = df_comp3[df_comp3['f_dedup_gvkeyfyear'].eq(1)].copy()
print(f"in: {df_comp3.shape} | out: {df_comp4.shape}")

# %%
#the duplicated rows and the choice made: f_dedup_gvkeyfyear 1 = picked, 0 = dropped, decision_at = the criterion behind it
df_dups_choice1 = df_comp3[df_comp3.groupby(['gvkey', 'fyear'])['gvkey'].transform('size') > 1].copy()
df_dups_choice1['n_at_per_gvkeyfyear'] = df_dups_choice1.groupby(['gvkey', 'fyear'])['at'].transform('count')
df_dups_choice1['n_atdistinct_per_gvkeyfyear'] = df_dups_choice1.groupby(['gvkey', 'fyear'])['at'].transform('nunique')
df_dups_choice1['decision_at'] = np.select(
    [df_dups_choice1['n_at_per_gvkeyfyear'] == 0, df_dups_choice1['n_at_per_gvkeyfyear'] == 1, df_dups_choice1['n_atdistinct_per_gvkeyfyear'] == 1],
    ['all missing: did not matter', 'one has value: picked the one with value', 'same value: did not matter'], default='differ: picked the highest')
print(df_dups_choice1.drop_duplicates(['gvkey', 'fyear'])['decision_at'].value_counts())
df_dups_choice1[['gvkey', 'fyear', 'datadate', 'at', 'f_dedup_gvkeyfyear', 'decision_at']].sort_values(['gvkey', 'fyear', 'datadate'])

# %%
#dup diagnostics at fyear - should output 0 rows
print(len(dups(df_comp4, ['gvkey', 'fyear'])))

# %%
#lags: previous row of the same firm, with rows sorted by fyear. chg_fyear is the distance in fiscal years between the two rows
df_comp5 = df_comp4.sort_values(['gvkey', 'fyear']).copy()
df_comp5['fyear_l1'] = df_comp5.groupby('gvkey')['fyear'].shift(1)
df_comp5['at_l1'] = df_comp5.groupby('gvkey')['at'].shift(1)
df_comp5['sale_l1'] = df_comp5.groupby('gvkey')['sale'].shift(1)
df_comp5['chg_fyear'] = df_comp5['fyear'] - df_comp5['fyear_l1']

# %%
#gap diagnostics: chg_fyear is missing for the first row of each firm, 1 when the previous row is the previous fiscal year, more than 1 when a year is missing
print(df_comp5['chg_fyear'].value_counts(dropna=False).sort_index().head(10))
df_gaps_gvkey_fyear = df_comp5[df_comp5['chg_fyear'] > 1]
print(f"rows after a gap: {len(df_gaps_gvkey_fyear)} | firms with a gap: {df_gaps_gvkey_fyear['gvkey'].nunique()}")
df_gaps_gvkey_fyear.head(10)

# %%
#growth = (current - previous) / previous. missing when there is a gap (the lag would be more than a year old) or when the previous value is 0 (division by 0)
df_comp6 = df_comp5.copy()
df_comp6['f_consecutive_fyear'] = (df_comp6['chg_fyear'] == 1).fillna(False).astype(int)
v_ok = (df_comp6['f_consecutive_fyear'] == 1)
df_comp6['chg_at__at_l1'] = ((df_comp6['at'] - df_comp6['at_l1']) / df_comp6['at_l1']).where(v_ok & (df_comp6['at_l1'] != 0))
df_comp6['chg_sale__sale_l1'] = ((df_comp6['sale'] - df_comp6['sale_l1']) / df_comp6['sale_l1']).where(v_ok & (df_comp6['sale_l1'] != 0))

# %%
#diagnostics: do the results look ok? the median is reasonable but the max is extreme because some previous values are tiny
df_stats1 = desc_stats(df_comp6, ['chg_at__at_l1', 'chg_sale__sale_l1'])
print(df_stats1)
