# %%
import pandas as pd
import numpy as np
import duckdb
from pathlib import Path

# %%
#path where the files were saved: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex8')

# %%
#summary stats: one row per variable, columns are obs, mean, std, min, p01, p05, p25, p50, p75, p95, p99, max
def desc_stats(df, cols):
    l_q = [0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99]
    df_q = df[cols].quantile(l_q).T
    df_q.columns = ['p01', 'p05', 'p25', 'p50', 'p75', 'p95', 'p99']
    df_out = pd.DataFrame({'obs': df[cols].count(), 'mean': df[cols].mean(), 'std': df[cols].std(), 'min': df[cols].min()})
    df_out = df_out.join(df_q)
    df_out['max'] = df[cols].max()
    return df_out

# %%
#monthly file, same stock filter as in the prepare step (ranged join to stksecurityinfohist on the price date)
query_msf = f"""
SELECT a.permno, a.mthcaldt, a.mthprc, a.mthcap
FROM read_parquet('{p_path}/crsp_a_stock/stkmthsecuritydata.parquet') AS a
JOIN read_parquet('{p_path}/crsp_a_stock/stksecurityinfohist.parquet') AS c
  ON a.permno = c.permno
 AND a.mthprcdt BETWEEN c.secinfostartdt AND c.secinfoenddt
WHERE c.sharetype = 'NS' AND c.securitytype = 'EQTY' AND c.securitysubtype = 'COM' AND c.usincflg = 'Y'
  AND c.issuertype IN ('ACOR', 'CORP') AND c.primaryexch IN ('N', 'A', 'Q') AND c.conditionaltype = 'RW' AND c.tradingstatusflg = 'A'
"""
df_msf1 = duckdb.query(query_msf).df()
#regression coefficients dataset
df_results1 = pd.read_parquet(f"{p_path}/results.parquet")
print(df_msf1.shape, df_results1.shape)

# %%
#regressions with at least 15 daily observations in the month
df_results2 = df_results1[df_results1['nobs'] >= 15].copy()
print(f"in: {df_results1.shape} | out: {df_results2.shape}")

# %%
#monthly file: drop rows with a missing price, key = permno and ym (first day of the month, same as in the regressions)
df_msf2 = df_msf1.dropna(subset=['mthprc'], how='any').copy()
df_msf2['ym'] = df_msf2['mthcaldt'].dt.to_period('M').dt.to_timestamp()
df_msf2 = df_msf2.dropna(subset=['permno', 'ym'], how='any').sort_values(['permno', 'ym'])
print(f"in: {df_msf1.shape} | out: {df_msf2.shape}")

# %%
#lags: previous row of the same permno. chg_month is the distance in months between the two rows
df_msf3 = df_msf2.copy()
df_msf3['ym_l1'] = df_msf3.groupby('permno')['ym'].shift(1)
df_msf3['mthprc_l1'] = df_msf3.groupby('permno')['mthprc'].shift(1)
df_msf3['mthcap_l1'] = df_msf3.groupby('permno')['mthcap'].shift(1)
df_msf3['chg_month'] = (df_msf3['ym'].dt.year - df_msf3['ym_l1'].dt.year) * 12 + (df_msf3['ym'].dt.month - df_msf3['ym_l1'].dt.month)

# %%
#keep rows where the previous row is the previous month (the first row of each permno and rows after a gap have no valid lag)
df_msf4 = df_msf3[df_msf3['chg_month'] == 1].copy()
print(f"in: {df_msf3.shape} | out: {df_msf4.shape}")

# %%
#price bucket 1 to 100 of last month's price within each month, and drop the lowest and the highest bucket
df_msf4['rk_prc_pct_per_ym'] = df_msf4.groupby('ym')['mthprc_l1'].rank(method='dense', pct=True)
df_msf4['p100'] = np.ceil(df_msf4['rk_prc_pct_per_ym'] * 100).clip(1, 100).astype('Int64')
df_msf5 = df_msf4[df_msf4['p100'].notna() & (df_msf4['p100'] != 1) & (df_msf4['p100'] != 100)][['permno', 'ym', 'p100', 'mthprc_l1', 'mthcap_l1']].copy()
print(f"in: {df_msf4.shape} | out: {df_msf5.shape}")

# %%
#ivola = annualized idiosyncratic volatility (252 trading days), beta = sum of the three market coefficients
df_main1 = pd.merge(df_msf5, df_results2, how='inner', left_on=['permno', 'ym'], right_on=['permno', 'ym'], suffixes=('', '_x'))
df_main1['ivola'] = round(df_main1['ivol'] * np.sqrt(252), 6)
df_main1['beta'] = round(df_main1['coef_mktrf'] + df_main1['coef_mktrftm1'] + df_main1['coef_mktrfavgtm2_4'], 6)
df_main1['absbeta'] = abs(df_main1['beta'])
df_main1 = df_main1[['permno', 'ym', 'p100', 'ivola', 'beta', 'absbeta', 'mthprc_l1', 'mthcap_l1']].replace([np.inf, -np.inf], pd.NA)
print(df_main1.shape)

# %%
#winsorize at the 1st and 99th percentile of the whole sample
def winsorize_overall(s, p=(0.01, 0.99)):
    x = pd.to_numeric(s, errors='coerce').replace([np.inf, -np.inf], np.nan)
    lo, hi = x.quantile(p[0]), x.quantile(p[1])
    return x.clip(lower=lo, upper=hi)

df_main2 = df_main1.copy()
for v_col in ['ivola', 'beta', 'absbeta']:
    df_main2[f"{v_col}_w"] = winsorize_overall(df_main2[v_col])

# %%
df_stats1 = desc_stats(df_main2.dropna(), ['ivola_w', 'beta_w', 'absbeta_w', 'mthprc_l1', 'mthcap_l1'])
print(df_stats1)
