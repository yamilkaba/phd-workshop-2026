# %%
import duckdb
from pathlib import Path

# %%
#path where the files were downloaded to (Ex8_01_download): change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex8')

# %%
#regression inputs: daily excess return of each stock, the market excess return of the day, of the day before, and the average of t-2 to t-4. ym = first day of the month
#the lags are taken on the factor table (one row per trading day), so t-1 is the previous trading day for every stock
#stocks are kept when the info valid on the day is common stock of a us corporation on nyse, amex or nasdaq (ranged join to stksecurityinfohist, same filter as the old wrds_dsfv2_query)
#rows with any missing input are dropped, as the regression would drop them. rows are sorted by permno so each permno sits in a few row groups of the file (the workers read only their permnos)
query = f"""
WITH ff_cte AS (
    SELECT date, rf, mktrf,
           LAG(mktrf, 1) OVER (ORDER BY date) AS mktrftm1,
           (LAG(mktrf, 2) OVER (ORDER BY date) + LAG(mktrf, 3) OVER (ORDER BY date) + LAG(mktrf, 4) OVER (ORDER BY date)) / 3 AS mktrfavgtm2_4
    FROM read_parquet('{p_path}/ff_all/factors_daily.parquet')
)
SELECT a.permno, DATE_TRUNC('month', a.dlycaldt) AS ym, a.dlyret - b.rf AS retrf, b.mktrf, b.mktrftm1, b.mktrfavgtm2_4
FROM read_parquet('{p_path}/crsp_a_stock/stkdlysecuritydata.parquet') AS a
JOIN read_parquet('{p_path}/crsp_a_stock/stksecurityinfohist.parquet') AS c
  ON a.permno = c.permno
 AND a.dlycaldt BETWEEN c.secinfostartdt AND c.secinfoenddt
JOIN ff_cte AS b
  ON a.dlycaldt = b.date
WHERE c.sharetype = 'NS' AND c.securitytype = 'EQTY' AND c.securitysubtype = 'COM' AND c.usincflg = 'Y'
  AND c.issuertype IN ('ACOR', 'CORP') AND c.primaryexch IN ('N', 'A', 'Q') AND c.conditionaltype = 'RW' AND c.tradingstatusflg = 'A'
  AND a.dlyret IS NOT NULL AND b.rf IS NOT NULL AND b.mktrf IS NOT NULL AND b.mktrftm1 IS NOT NULL AND b.mktrfavgtm2_4 IS NOT NULL
ORDER BY a.permno, ym
"""
duckdb.execute(f"COPY ({query}) TO '{p_path}/regready.parquet' (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 100000)")

# %%
print(duckdb.query(f"SELECT COUNT(*) AS n_rows, COUNT(DISTINCT permno) AS n_permno FROM read_parquet('{p_path}/regready.parquet')").df())
duckdb.query(f"SELECT * FROM read_parquet('{p_path}/regready.parquet') LIMIT 10").df()
