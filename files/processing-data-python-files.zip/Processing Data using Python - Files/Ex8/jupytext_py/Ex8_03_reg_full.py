# %%
import os
import sys
import time
import duckdb
import pandas as pd
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, wait

# %%
#Ex8_worker.py (same folder as this notebook) holds the regression functions the worker processes import
sys.path.append(str(Path.cwd()))
import Ex8_worker

# %%
#path where regready.parquet was saved (Ex8_02_prepare): change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex8')
v_nproc = os.cpu_count() #number of worker processes = logical cores of this computer (16 here: 8 physical cores, 2 logical each). each worker gets one block of permno-months
v_threads_reg = 1 #controls how many logical cpus the regression (numpy blas) uses in each worker
v_threads_duckdb = 1 #controls how many logical cpus duckdb uses to read the parquet file in each worker
v_chunk = 200 #permno-months a worker reads at a time. one read per permno-month was 5 times slower (Ex8_03_reg_compare); 100 and 200 are close to reading the whole block at once but keep memory low
v_minobs = 15 #a permno-month needs at least this many daily observations
v_nperm = None #None = all permnos. a number runs only the first permnos (they sit together in the file, so reads stay small), for a quick test

# %%
#permno-months to regress: at least v_minobs daily rows. only the counts are read here, not the returns
#windows starts every worker by importing this file again: the code under this check runs only in the main program
if __name__ == '__main__':
    df_pm1 = duckdb.query(f"""
        SELECT permno, ym FROM read_parquet('{p_path}/regready.parquet')
        GROUP BY permno, ym HAVING COUNT(*) >= {v_minobs}
        ORDER BY permno, ym
    """).df()
    if v_nperm:
        df_pm1 = df_pm1[df_pm1['permno'].isin(df_pm1['permno'].unique()[:v_nperm])]

# %%
#one task per worker: its block of permno-months, the keys only (about the same number for every worker). no data is sent to the workers
if __name__ == '__main__':
    p_progress = p_path / 'progress'
    p_progress.mkdir(exist_ok=True)
    for p_old in p_progress.glob('*.txt'):
        p_old.unlink()
    l_bounds = [round(i * len(df_pm1) / v_nproc) for i in range(v_nproc + 1)]
    l_tasks = []
    for v_start, v_end in zip(l_bounds[:-1], l_bounds[1:]):
        df_block = df_pm1.iloc[v_start:v_end]
        l_tasks.append((f"{p_path}/regready.parquet", v_minobs, v_chunk, v_threads_duckdb, df_block['permno'].tolist(), df_block['ym'].tolist(), str(p_progress)))
    print(f"permnos: {df_pm1['permno'].nunique()} | permno-months: {len(df_pm1)} | workers: {v_nproc} | permno-months per worker: {len(df_pm1) // v_nproc}")

# %%
#each worker reads only its own rows from the parquet file, v_chunk permno-months at a time, so the full 80 million row file never sits in memory
#every 30 seconds the permno-months done by all the workers are added up from their progress files
if __name__ == '__main__':
    v_t0 = time.time()
    with ProcessPoolExecutor(v_nproc, initializer=Ex8_worker.init_worker, initargs=(v_threads_reg,)) as executor:
        l_fut = [executor.submit(Ex8_worker.reg_share, v_task) for v_task in l_tasks]
        while True:
            l_done, l_wait = wait(l_fut, timeout=30)
            v_n = sum(int(p_file.read_text() or 0) for p_file in p_progress.glob('*.txt'))
            print(f"{v_n} of {len(df_pm1)} permno-months | {time.time() - v_t0:.0f}s")
            if not l_wait:
                break
    df_results1 = pd.concat([v_fut.result() for v_fut in l_fut], ignore_index=True)
    print(df_results1.shape, f"{time.time() - v_t0:.0f}s")

# %%
if __name__ == '__main__':
    df_results1.to_parquet(f"{p_path}/results.parquet", index=False)
