#functions used by Ex8_03_reg_compare and Ex8_03_reg_full. they live in their own file because the worker processes (windows starts them from scratch) must be able to import them
#keep this file in the same folder as the notebooks
import os
import duckdb
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from pathlib import Path
from threadpoolctl import threadpool_limits


def init_worker(v_threads=1):
    #each worker process limits numpy's own threads (blas), so processes x threads never goes above the cpu count
    threadpool_limits(limits=v_threads)


def reg_group(df_group, v_minobs=15):
    #one regression for one permno and month. groups with fewer than v_minobs observations are skipped (they are dropped after the regressions anyway)
    if len(df_group) < v_minobs:
        return None
    with np.errstate(all='ignore'): #a month with constant returns gives a division by zero in r2 (result is NaN), no need to print it for every group
        model = smf.ols('retrf ~ mktrf + mktrftm1 + mktrfavgtm2_4', data=df_group).fit()
        d_res = {
            'coef_mktrf': model.params['mktrf'],
            'tstat_mktrf': model.tvalues['mktrf'],
            'coef_mktrftm1': model.params['mktrftm1'],
            'tstat_mktrftm1': model.tvalues['mktrftm1'],
            'coef_mktrfavgtm2_4': model.params['mktrfavgtm2_4'],
            'tstat_mktrfavgtm2_4': model.tvalues['mktrfavgtm2_4'],
            'ivol': np.sqrt(model.scale), #std of the residuals
            'r2': model.rsquared,
            'r2_adj': model.rsquared_adj,
            'nobs': int(model.nobs),
        }
    return d_res


def reg_df(df, v_minobs=15):
    #all the regressions of a dataframe: one row per permno and ym
    l_rows = []
    for (v_permno, v_ym), df_group in df.groupby(['permno', 'ym'], sort=False):
        d_res = reg_group(df_group, v_minobs)
        if d_res is not None:
            l_rows.append({'permno': v_permno, 'ym': v_ym, **d_res})
    return pd.DataFrame(l_rows)


def reg_one_group(group_data):
    #for executor.map over groupby: each task receives (key, dataframe of the group), so the data is copied into the worker
    (v_permno, v_ym), df_group = group_data
    d_res = reg_group(df_group)
    return None if d_res is None else {'permno': v_permno, 'ym': v_ym, **d_res}


def reg_from_parquet(args):
    #for executor.map over lists of permnos: the task receives only the file path and the permnos, and reads its own rows from the parquet file
    p_file, l_permno = args
    df = pd.read_parquet(p_file, filters=[('permno', 'in', l_permno)])
    return reg_df(df)


def reg_share(args):
    #one task per worker: the task receives only the keys (permno, ym) of its whole block of permno-months, no data. the worker reads the rows from the parquet file v_chunk permno-months at a time and runs the regressions
    p_file, v_minobs, v_chunk, v_threads_duckdb, l_permno, l_ym, p_progress = args
    con = duckdb.connect()
    con.execute(f"SET threads TO {int(v_threads_duckdb)}") #duckdb has its own threads, threadpool_limits does not control them
    v_query = f"SELECT * FROM read_parquet('{p_file}') WHERE permno >= ? AND permno <= ?"
    l_res = []
    for i in range(0, len(l_permno), v_chunk):
        df_keys = pd.DataFrame({'permno': l_permno[i:i + v_chunk], 'ym': l_ym[i:i + v_chunk]})
        #the keys are sorted, so the chunk lies between its first and last permno. rows of other months of those permnos are dropped by the merge
        df = con.execute(v_query, [int(df_keys['permno'].iloc[0]), int(df_keys['permno'].iloc[-1])]).df()
        df = pd.merge(df, df_keys, how='inner', left_on=['permno', 'ym'], right_on=['permno', 'ym'], suffixes=('', '_x'))
        l_res.append(reg_df(df, v_minobs))
        #progress: the main program adds up these files
        Path(p_progress, f"{os.getpid()}.txt").write_text(str(i + len(df_keys)))
    return pd.concat(l_res, ignore_index=True)
