# %%
import duckdb
from pathlib import Path

# %%
#path where the files were downloaded to (Ex7_01_download): change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex7')

# %%
#duckdb reads the parquet files directly with read_parquet, so none of the tables is loaded into pandas
#the ranged join (a.mthprcdt between b.secinfostartdt and b.secinfoenddt) is done inside duckdb as well
query = f"""
SELECT a.permno, a.mthcaldt, a.mthprcdt, a.mthret, a.mthretx, a.mthprc, d.mthcumfacpr, d.mthcumfacshr,
       a.sharetype, a.securitytype, a.securitysubtype, a.usincflg, a.issuertype,
       a.primaryexch, a.conditionaltype, a.tradingstatusflg, a.mthdelflg,
       f.mthtotret AS vwretd, b.siccd AS sic_crsp, b.naics AS naics_crsp
FROM read_parquet('{p_path}/crsp_a_stock/stkmthsecuritydata.parquet') AS a
LEFT JOIN read_parquet('{p_path}/crsp_a_stock/stksecurityinfohist.parquet') AS b
  ON a.permno = b.permno
 AND a.mthprcdt BETWEEN b.secinfostartdt AND b.secinfoenddt
LEFT JOIN read_parquet('{p_path}/crsp_a_stock/stkmthcumulativeadjfactor.parquet') AS d
  ON a.permno = d.permno
 AND a.mthcaldt = d.mthcaldt
LEFT JOIN read_parquet('{p_path}/crsp_a_indexes/indmthseriesdata_ind.parquet') AS f
  ON a.mthcaldt = f.mthcaldt
ORDER BY a.permno, a.mthcaldt
"""

# %%
#the result goes straight from duckdb to a parquet file, it never becomes a pandas dataframe
duckdb.execute(f"COPY ({query}) TO '{p_path}/crsp_monthret1.parquet' (FORMAT PARQUET, COMPRESSION ZSTD)")

# %%
#only a small piece is loaded into pandas to look at it
df_crsp_monthret1 = duckdb.query(f"SELECT * FROM read_parquet('{p_path}/crsp_monthret1.parquet') LIMIT 10").df()
df_crsp_monthret1

# %%
#diagnostic: the left joins should not add rows - rows in the output vs rows in stkmthsecuritydata
print(duckdb.query(f"SELECT (SELECT COUNT(*) FROM read_parquet('{p_path}/crsp_monthret1.parquet')) AS n_out, (SELECT COUNT(*) FROM read_parquet('{p_path}/crsp_a_stock/stkmthsecuritydata.parquet')) AS n_in").df())
