# %%
import pandas as pd

# %%
#wrds username, change accordingly
v_username="user"
#an idle connection is terminated if it has been idle longer than this many minutes (your own pooled connections are much younger)
v_idle_minutes=10
#True = only list what would be terminated, False = terminate
v_dry_run=True

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
#all connections of your user. is_self = True is the connection that ran this query, it is never terminated
df_conn1 = conn.raw_sql(r"""
    SELECT pid, (pid = pg_backend_pid()) AS is_self, state, backend_start, state_change,
           ROUND(EXTRACT(EPOCH FROM (now() - state_change)) / 60) AS idle_min,
           substring(regexp_replace(query, '\s+', ' ', 'g'), 1, 60) AS short_query
    FROM pg_stat_activity
    WHERE usename = CURRENT_USER
    ORDER BY backend_start
""")
print(f"{len(df_conn1)} connection(s) for your user")
df_conn1.head(20)

# %%
#idle for more than v_idle_minutes and not the connection running this query. the self check is inside the same statement
#because the pool can hand out a different connection on every call
v_where = f"usename = CURRENT_USER AND pid <> pg_backend_pid() AND state = 'idle' AND state_change < now() - interval '{v_idle_minutes} minutes'"

if v_dry_run:
    df_term1 = conn.raw_sql(f"SELECT pid, state, state_change FROM pg_stat_activity WHERE {v_where}")
    print(f"dry run: {len(df_term1)} idle connection(s) would be terminated")
else:
    df_term1 = conn.raw_sql(f"SELECT pid, pg_terminate_backend(pid) AS terminated FROM pg_stat_activity WHERE {v_where}")
    print(f"terminated: {int(df_term1['terminated'].sum())} of {len(df_term1)} idle connection(s)")
df_term1.head(20)

# %%
conn.close()
