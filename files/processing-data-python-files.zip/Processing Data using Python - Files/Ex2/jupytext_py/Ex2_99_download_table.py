# %%
import pandas as pd

# %%
#wrds username, change accordingly
v_username="user"

# %%
#table to download: change accordingly (Ex2_99_wrds_libraries lists the schema.table you have access to)
v_schema="crsp_a_stock"
v_table="stocknames_v2"
l_date_cols=['namedt', 'nameenddt', 'securitybegdt', 'securityenddt'] #columns to convert to date format (the table comes with them as text). leave as [] if none
v_limit=None #number of rows to download. None = all rows. try a small number first (e.g. 1000) for big tables

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
#no LIMIT clause when v_limit is None
v_limit_sql = f"LIMIT {int(v_limit)}" if v_limit is not None else ""
#the dataframe is named after the table: stocknames_v2 -> df_stocknames_v2
v_df_name = f"df_{v_table}"
globals()[v_df_name] = conn.raw_sql(
    f"""
    SELECT *
    FROM {v_schema}.{v_table}
    {v_limit_sql}
    """,
    date_cols=l_date_cols
)
print(f"{v_schema}.{v_table} -> {v_df_name}: {globals()[v_df_name].shape}")
globals()[v_df_name].head()

# %%
#columns of the table with type and comment (needs the connection open)
conn.describe_table(v_schema, v_table)

# %%
conn.close()
