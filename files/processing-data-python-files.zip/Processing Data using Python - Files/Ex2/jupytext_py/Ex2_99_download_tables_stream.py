# %%
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path

# %%
#root folder: each table is saved in p_path/<schema>/<table>.parquet (table name exactly as in wrds), mirroring the schema structure on wrds. change accordingly
p_path=Path(r'D:\WorkDatasets\wrds')
#wrds username, change accordingly
v_username="user"
v_chunksize=500000 #rows held in memory at a time. smaller = less memory
v_compression='zstd' #files are 20-30% smaller than snappy (the pandas default) at similar speed. change to 'snappy' if you need compatibility with old tools

# %%
#tables to download: change accordingly (Ex2_99_wrds_libraries lists the schema.table you have access to)
df_dl_list = pd.DataFrame({
    'schema': ['crsp_a_ccm', 'crsp_a_stock',],
    'table': ['ccmxpf_lnkhist', 'stocknames_v2',],
})

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
#streams each table straight to parquet, one chunk at a time, so memory never holds the whole table
#chunks go through the same raw_sql conversions as a normal download (nullable dtypes, dates), so the file matches df.to_parquet(index=False)
#the file is written as .part and renamed only when complete, so an interrupted download never looks finished
for v_schema, v_table in df_dl_list[['schema', 'table']].itertuples(index=False):
    p_out = p_path / v_schema / f"{v_table}.parquet"
    p_part = p_out.with_name(p_out.name + '.part')
    p_out.parent.mkdir(parents=True, exist_ok=True)

    #date columns come from the table definition
    df_cols = conn.raw_sql(f"SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = '{v_schema}' AND table_name = '{v_table}'")
    l_date_cols = df_cols.loc[df_cols['data_type'].str.contains('date|timestamp', case=False, na=False), 'column_name'].tolist()

    #server-side cursor: wrds sends the rows in chunks instead of all at once. postgres only allows it inside a transaction, so autocommit is switched off meanwhile
    conn.connection.rollback()
    conn.connection.execution_options(isolation_level="READ COMMITTED", stream_results=True)
    it_chunks = conn.raw_sql(f"SELECT * FROM {v_schema}.{v_table}", date_cols=l_date_cols, chunksize=v_chunksize, return_iter=True)

    writer = None
    v_rows = 0
    for df_chunk in it_chunks:
        t_chunk = pa.Table.from_pandas(df_chunk, preserve_index=False)
        if writer is None:
            writer = pq.ParquetWriter(p_part, t_chunk.schema, compression=v_compression)
        writer.write_table(t_chunk)
        v_rows += len(df_chunk)
    conn.connection.rollback()
    conn.connection.execution_options(isolation_level="AUTOCOMMIT", stream_results=False)

    if writer is None:
        print(f"{v_schema}.{v_table}: no rows, nothing saved")
        continue
    writer.close()
    p_part.replace(p_out)
    print(f"{v_schema}.{v_table}: {v_rows} rows -> {p_out}")

# %%
conn.close()
