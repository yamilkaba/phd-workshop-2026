# %%
import pandas as pd
from pathlib import Path

# %%
#path where the files were downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex2')

# %%
df_ff3 = pd.read_parquet(f"{p_path}/df_ff3.parquet")
df_ff5 = pd.read_parquet(f"{p_path}/df_ff5.parquet")

# %%
#joining - some columns have same name. suffixes adds a suffix to the column names from the second table if the name is also on the first table
df_ffs1 = pd.merge(df_ff3, df_ff5, how='inner', left_on=['date'], right_on=['date'], suffixes=('', '_5'))
print(f"ff3: {df_ff3.shape} | ff5: {df_ff5.shape} | merged: {df_ffs1.shape}")

# %%
#describe gets summary stats
df_stats1 = df_ffs1[['smb', 'smb_5']].describe()
print(df_stats1)

# %%
#helper function: one row per variable, columns are obs, mean, std, min, p01, p05, p25, p50, p75, p95, p99, max
def desc_stats(df, cols):
    l_q = [0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99]
    df_q = df[cols].quantile(l_q).T
    df_q.columns = ['p01', 'p05', 'p25', 'p50', 'p75', 'p95', 'p99']
    df_out = pd.DataFrame({'obs': df[cols].count(), 'mean': df[cols].mean(), 'std': df[cols].std(), 'min': df[cols].min()})
    df_out = df_out.join(df_q)
    df_out['max'] = df[cols].max()
    return df_out

# %%
#custom summary stats: obs, mean, std, min, 1/5/25/50/75/95/99 percentiles, max
df_stats2 = desc_stats(df_ffs1, ['smb', 'smb_5'])
print(df_stats2)

# %%
df_corr1 = df_ffs1[['smb', 'smb_5']].corr()
print(df_corr1)
