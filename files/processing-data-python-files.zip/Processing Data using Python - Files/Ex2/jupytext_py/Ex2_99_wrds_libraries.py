# %%
import pandas as pd
from pathlib import Path

# %%
#path where the files will be downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex2')
#wrds username, change accordingly
v_username="user"

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
#list_libraries only returns the schemas your institution is subscribed to (comp_snapshot for example is not in it)
l_libraries = conn.list_libraries()
l_libraries_sql = ", ".join(f"'{v_lib}'" for v_lib in l_libraries)

#one query for all schemas instead of one list_tables call per library: tables, views, materialized views, foreign tables
df_wrds_tables1 = conn.raw_sql(f"""
    SELECT n.nspname AS schema, c.relname AS table
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relkind IN ('r', 'v', 'm', 'f', 'p')
      AND n.nspname IN ({l_libraries_sql})
    ORDER BY n.nspname, c.relname
""")
df_wrds_tables1['schema_table'] = df_wrds_tables1['schema'] + '.' + df_wrds_tables1['table']
print(f"libraries: {len(l_libraries)} | schema.table rows: {df_wrds_tables1.shape[0]}")
df_wrds_tables1.head()

# %%
conn.close()

# %%
#search for something, e.g. any table containing 'dsf' or 'msf'
df_wrds_tables_search = df_wrds_tables1[df_wrds_tables1['table'].str.contains('dsf', case=False)]
print(df_wrds_tables_search)

# %%
df_wrds_tables1.to_parquet(f"{p_path}/df_wrds_tables.parquet", index=False)
