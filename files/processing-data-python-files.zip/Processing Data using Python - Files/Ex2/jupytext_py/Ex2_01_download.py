# %%
import pandas as pd
from pathlib import Path

# %%
#path where the files will be downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex2')
#wrds username, change accordingly
v_username="user"

# %%
#initialize connection
import wrds       #if you don't have it: !pip install --no-deps wrds
conn = wrds.Connection(wrds_username=v_username) #say yes to pgpass file and it will remember your password if you pass the username

# %%
df_ff3 = conn.raw_sql(
    """
    select date, rf, mktrf, smb, hml, umd
    from ff_all.factors_monthly
    order by date
    """,
    date_cols=['date']
)
df_ff3.head()

# %%
df_ff5 = conn.raw_sql(
    """
    select *
    from ff_all.fivefactors_monthly
    order by date
    """,
    date_cols=['date']
)
df_ff5.head()

# %%
conn.close()

# %%
df_ff3.to_parquet(f"{p_path}/df_ff3.parquet", index=False)

# %%
df_ff5.to_parquet(f"{p_path}/df_ff5.parquet", index=False)
