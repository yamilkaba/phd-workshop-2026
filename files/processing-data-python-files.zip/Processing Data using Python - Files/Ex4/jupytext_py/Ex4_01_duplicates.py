# %%
import pandas as pd
from pathlib import Path

# %%
#path where the Ex3 file was downloaded to: change accordingly
p_path=Path(r'D:\WorkDatasets\ProgramDatasets\workshop\2026\Empirical Research Pipeline\Ex3')

# %%
df_comp1 = pd.read_parquet(f"{p_path}/df_comp1.parquet")

# %%
#returns all the rows that share the same key, sorted by the key
def dups(df, subset, sort_cols=None):
    df_d = df[df.duplicated(subset=subset, keep=False)]
    return df_d.sort_values(subset + (sort_cols or []))

# %%
#dup diagnostics at fiscal year: a firm should have one row per fyear
df_dups_gvkey_fyear = dups(df_comp1, ['gvkey', 'fyear'], ['datadate'])
print(f"rows sharing a gvkey and fyear: {len(df_dups_gvkey_fyear)}")
df_dups_gvkey_fyear.head(10)

# %%
#calendar year of the fiscal year end
df_comp2 = df_comp1.copy()
df_comp2['cyear'] = df_comp2['datadate'].dt.year

# %%
#dup diagnostics at calendar year: a firm that changes its fiscal year end has two datadates in the same calendar year
df_dups_gvkey_cyear = dups(df_comp2, ['gvkey', 'cyear'], ['datadate'])
print(f"rows sharing a gvkey and calendar year: {len(df_dups_gvkey_cyear)} | gvkey-year pairs: {df_dups_gvkey_cyear.groupby(['gvkey', 'cyear']).ngroups}")
df_dups_gvkey_cyear.head(10)

# %%
#rule 1: keep the row with the highest assets in each gvkey and calendar year. missing assets lose, ties go to the later datadate. rk = 1 is the row chosen
df_comp3 = df_comp2.sort_values(['gvkey', 'cyear', 'at', 'datadate'], na_position='first')
df_comp3['rk_at_per_gvkeycyear'] = df_comp3.groupby(['gvkey', 'cyear']).cumcount(ascending=False) + 1
df_comp3['f_at_gvkeycyear'] = (df_comp3['rk_at_per_gvkeycyear'] == 1).astype(int)

# %%
df_comp4 = df_comp3[df_comp3['f_at_gvkeycyear'].eq(1)].copy()
print(f"in: {df_comp3.shape} | out: {df_comp4.shape}")

# %%
#rule 2: keep the row with the latest datadate in each gvkey and calendar year
df_comp5 = df_comp2.sort_values(['gvkey', 'cyear', 'datadate'])
df_comp5['rk_datadate_per_gvkeycyear'] = df_comp5.groupby(['gvkey', 'cyear']).cumcount(ascending=False) + 1
df_comp5['f_datadate_gvkeycyear'] = (df_comp5['rk_datadate_per_gvkeycyear'] == 1).astype(int)

# %%
df_comp6 = df_comp5[df_comp5['f_datadate_gvkeycyear'].eq(1)].copy()
print(f"in: {df_comp5.shape} | out: {df_comp6.shape}")

# %%
#diagnostics: both rules leave one row per gvkey and calendar year - should output 0 rows
print(len(dups(df_comp4, ['gvkey', 'cyear'])), len(dups(df_comp6, ['gvkey', 'cyear'])))

# %%
#do the two rules choose the same row? one row per gvkey and calendar year from each rule, same_row = 1 if the datadate chosen is the same
df_chk_choice1 = pd.merge(df_comp4[['gvkey', 'cyear', 'datadate', 'at']], df_comp6[['gvkey', 'cyear', 'datadate', 'at']], how='outer', on=['gvkey', 'cyear'], suffixes=('_rule1', '_rule2'), indicator=True)
df_chk_choice1['same_row'] = (df_chk_choice1['datadate_rule1'] == df_chk_choice1['datadate_rule2']).astype(int)
print(df_chk_choice1['_merge'].value_counts())

# %%
#agree vs disagree: all gvkey-years first, then only the gvkey-years that had duplicates (the others have one row, so the rules cannot differ)
print(f"all gvkey-years: {len(df_chk_choice1)}")
print(df_chk_choice1['same_row'].map({1: 'same row', 0: 'different row'}).value_counts())
df_pairs_dups = df_dups_gvkey_cyear[['gvkey', 'cyear']].drop_duplicates()
df_chk_choice2 = pd.merge(df_pairs_dups, df_chk_choice1, how='left', on=['gvkey', 'cyear'])
print(f"gvkey-years with duplicates: {len(df_chk_choice2)}")
print(df_chk_choice2['same_row'].map({1: 'same row', 0: 'different row'}).value_counts())
df_chk_choice2[df_chk_choice2['same_row'].eq(0)].head(10)
